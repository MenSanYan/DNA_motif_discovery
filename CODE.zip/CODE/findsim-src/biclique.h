//
// BICLIQUE.H
// Biclique-based procedures for finding simulation of low dimension
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __BICLIQUE_H
#define __BICLIQUE_H

#include "vector.h"

typedef unsigned int Word;

inline unsigned int expand(Word w, unsigned int size, 
			   unsigned int *indices)
			   
{
  unsigned int nIndices = 0;
  for (unsigned int j = 0; j < size; j++)
    {
      if (w & (1U << j))
	indices[nIndices++] = j;
    }
  
  return nIndices;
}

inline bool testBit(Word w, unsigned int j)
{ return ( (w & (1U << j)) != 0); }

inline Word setBit(Word w, unsigned int j)
{ return (w | (1U << j)); }

inline Word clearBit(Word w, unsigned int j)
{ return (w & ~(1U << j)); }

inline Word popCount(Word w)
{
  w -= ( w >> 1 & 0x55555555 );
  w  = (w & 0x33333333) + ( w >> 2 & 0x33333333 );
  w  = w + (w >> 4) & 0x0F0F0F0F;
  
  // w = (w * 0x001010101) >> 24;
  
  w += (w >> 8);
  return ( w + (w >> 16) & 0x3F );
}


// Return true iff there are no 1 bits strictly to left of bit b
inline bool emptyToLeft(Word w, unsigned int b)
{
  Word mask = (1U << b) - 1U;
  return !(w & mask);
}

// Return true iff there are no 1 bits strictly to right of bit b
inline bool emptyToRight(Word w, unsigned int b)
{
  Word mask = ~( (1U << (b+1)) - 1U );
  return !(w & mask);
}

struct Biclique {
  unsigned int size;
  Word left, right;
};

typedef Vector<Biclique> BicliqueVector;

BicliqueVector findBicliques(const Word *adj, unsigned int nv, 
			     bool forceSymmetry, bool rearrange);

#endif
