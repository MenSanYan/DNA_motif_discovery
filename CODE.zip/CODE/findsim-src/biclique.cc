//
// BICLIQUE.H
// Biclique-based procedures for finding simulation of low dimension
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>

#include "biclique.h"

using namespace std;


static Biclique findLargestBiclique(const Word *adj, unsigned int nVertices,
				    Word excludedLeft, Word excludedRight,
				    bool forceSymmetry);

static BicliqueVector rearrange(const Word *adj, unsigned int nVertices,
				BicliqueVector v);

BicliqueVector findBicliques(const Word *adj, unsigned int nVertices,
			     bool forceSymmetry, bool doRearrange)
{
  Word excludedLeft = 0, excludedRight = 0;
  BicliqueVector v;
  
  for (;;)
    {
      Biclique C = 
	findLargestBiclique(adj, nVertices, 
			    excludedLeft, excludedRight, 
			    forceSymmetry);
      
      if (C.size == 0)
	break;
      
      v.add(C);
      excludedLeft  |= C.left;
      excludedRight |= C.right;
      
      //
      // If biclique is in strict upper or lower triangle of score
      // matrix, then the corresponding biclique from the other triangle
      // also exists.
      //
      if (forceSymmetry && C.left != C.right)
	{
	  Biclique C2;
	  C2.size  = C.size;
	  C2.right = C.left;
	  C2.left  = C.right;
	  
	  v.add(C2);
	  excludedLeft  |= C2.left;
	  excludedRight |= C2.right;
	}
    }
  
  if (doRearrange && !forceSymmetry && !v.isEmpty())
    v = rearrange(adj, nVertices, v);
  
  return v;
}


static Biclique findLargestBiclique(const Word *adj, 
				    unsigned int nVertices,
				    Word excludedLeft, 
				    Word excludedRight,
				    bool forceSymmetry)
					  
{
  unsigned int leftVertices[8 * sizeof(Word)];
  unsigned int maxSize;
  Biclique C;
  
  C.size  = 0;
  C.left  = 0;
  C.right = 0;
  maxSize = 0;
  
  for (Word wLeft = 1; wLeft < (1U << nVertices); wLeft++)
    {
      // Skip candidates w/any excluded left-hand vertex.
      if (wLeft & excludedLeft) continue;
      
      // Get the indices of all left-hand vertices.
      unsigned int nLeftVertices = expand(wLeft, nVertices, leftVertices);
      
      // Find all (non-excluded) right-hand vertices that connect
      // to every left-hand vertex in wLeft.  If the right-hand
      // side becomes empty, halt and continue with next left-hand side.
      Word wRight = (adj[leftVertices[0]]  & ~excludedRight);
      for (unsigned int j = 1; j < nLeftVertices; j++)
	{
	  wRight &= adj[leftVertices[j]];
	  if (!wRight) goto emptyRightSide;
	}
      
      
      //
      // If symmetry is forced on, accept only cliques that are
      // symmetric (left and right sides the same) or that are
      // entirely contained in the strict upper or lower triangle
      // of the score matrix.
      //
      if (!forceSymmetry ||
	  wLeft == wRight ||
	  ((wLeft & wRight) == 0 &&
	   (emptyToRight(wRight, leftVertices[0]) ||
	    emptyToLeft(wRight,  leftVertices[nLeftVertices - 1]))))
	{
	  unsigned int nRightVertices = popCount(wRight);
	  unsigned int bicliqueSize = nLeftVertices * nRightVertices;
	  
	  if (bicliqueSize > maxSize)
	    {
	      C.size  = bicliqueSize;
	      C.left  = wLeft;
	      C.right = wRight;
	      
	      maxSize = bicliqueSize;
	    }
	}
      
    emptyRightSide:
      continue;
    }
  
  return C;
}

// sort in DESCENDING order by size of LHS
static int lhscmp(const void *p1, const void *p2)
{
  const Biclique *c1 = (const Biclique *) p1;
  const Biclique *c2 = (const Biclique *) p2;
  
  unsigned int s1 = popCount(c1->left);
  unsigned int s2 = popCount(c2->left);
  
  if (s1 > s2)
    return -1;
  else
    return (s1 < s2);
}


static BicliqueVector rearrange(const Word *adj, unsigned int nVertices,
				BicliqueVector v)
{
  unsigned int leftVertices[8 * sizeof(Word)];
  unsigned int rightVertices[8 * sizeof(Word)];
  qsort(v.elements(), v.length(), sizeof(Biclique), lhscmp);

  for (unsigned int i = v.length() - 1; i > 0; i--)
    {
      Biclique &src = v[i];
      
      unsigned int srcLeftSize = popCount(src.left);
      
      unsigned int nRightVertices = 
	expand(src.right, nVertices, rightVertices);
      
      for (unsigned int j = 0; j < i; j++)
	{
	  Biclique &dst = v[j];
	  
	  if (popCount(dst.left) > srcLeftSize)
	    {
	      unsigned int nLeftVertices = 
		expand(dst.left, nVertices, leftVertices);
	      
	      // Find all RHS vertices adjacent to the LHS vertices
	      // of biclique dst (i.e., all the vertices that could
	      // be in a clique with the LHS if not for exclusions).
	      //
	      Word cliqueAdj = adj[leftVertices[0]];
	      for (unsigned int k = 1; k < nLeftVertices; k++)
		cliqueAdj &= adj[leftVertices[k]];
	      
	      // Move any RHS vertices from src to dst if possible.
	      // dst has a larger LHS, so the number of covered edges
	      // will increase.
	      //
	      for (unsigned int k = 0; k < nRightVertices; k++)
		{
		  unsigned int vr = rightVertices[k];
		  
		  if (testBit(cliqueAdj, vr))
		    {
		      cerr << "Moving RHS vertex " << vr 
			   << " from clique " << i+1 
			   << " to clique " << j+1 << '\n';
		      
		      dst.right = setBit(dst.right, vr);
		      src.right = clearBit(src.right, vr);
		    }
		}
	    }
	}
    }
  
  BicliqueVector v2;
  
  for (unsigned int i = 0; i < v.length(); i++)
    {
      if (v[i].right != 0)
	v2.add(v[i]);
    }
  
  return v2;
}
