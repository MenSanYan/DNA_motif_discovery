//
// BPGRAPH.H
// Bipartite graph structure
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// In this implementation, a bipartite graph of "size" N has
// 2N vertices, N each on the left and right.  The left-hand
// vertices are numbered 0..N-1, while the right-hand vertices
// are N..2N-1.  Keep this distinction in mind when accessing
// edges -- to access the edge between the 5th vertex on the left
// and the 12th on the right, you want to say G.E[5][12+N].
//

#ifndef __BPGRAPH_H
#define __BPGRAPH_H

#include "scorefunction.h"

class BPGraph {
public:
  class EdgeMatrix {
  public:
    
    EdgeMatrix(const ScoreMatrix &M)
    {
      _size = M.alphabet()->nRealResidues();
      
      weights = new ScoreT [_size * _size];
      
      for (Residue i = 1; i <= _size; i++)
	for (Residue j = 1; j <= _size; j++)
	  weights[(i-1) * _size + (j-1)] = M[i][j];
    }
    
    ~EdgeMatrix(void)
    {
      delete [] weights;
    }
    
    // returns the ith row of the matrix
    ScoreT *operator[](unsigned int i) 
    { return (&weights[i * _size]) - _size; }
    
    unsigned int size(void) const { return _size; }
    
  private:
    unsigned int _size;
    ScoreT *weights;
  };
  
  struct Vertex {
    int visited;  // integer-valued for generation number
    int prev;     // integer-valued so negative can mean "none"
  };
  
  enum { NONE = -1 };
  
  Vertex *V;
  EdgeMatrix E;
  
  BPGraph(const ScoreMatrix &M)
    : E(M)
  {
    V = new Vertex [2 * size()];
    
    for (unsigned int j = 0; j < 2 * size(); j++)
      V[j].visited = NONE;
  }
  
  ~BPGraph(void)
  {
    delete [] V;
  }
  
  unsigned int size(void) const { return E.size(); }
};

#endif
