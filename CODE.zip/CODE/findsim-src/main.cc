//
// MAIN.CC
// Main program for simulation finder
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>

#include <unistd.h> // for getopt()

#include "scorefunction.h"
#include "fileops.h"
#include "bpgraph.h"
#include "biclique.h"
#include "version.h"

using namespace std;


const char *allOptions = "-srF:h";

//
// local prototypes
//
static unsigned int computeSimulation(const ScoreMatrix &S, 
				      bool forceSymmetry,
				      bool rearrange);
static void printUsage(void);

int main(int argc, char *argv[])
{
  const char *scoreFunctionName = NULL;
  const ScoreFunction *SCORE;
  bool forceSymmetry = false;
  bool rearrange = false;
  int optchar;
  
  while ((optchar = getopt(argc, argv, allOptions)) >= 0)
    {
      switch(optchar)
	{
	case 'r':
	  rearrange = true;
	  break;
	  
	case 's':
	  forceSymmetry = true;
	  break;
	  
	case 'F':
	case 1:
	  scoreFunctionName = optarg;
	  break;
	  
	case '?':
	  cerr << "Error: unknown or incomplete option '-"
	       << char(optchar) << "'\n";
	  printUsage();
	  exit(1);
	  
	case 'h':
	default:
	  printUsage();
	  exit(1);
	}
    }
  
  if (rearrange && forceSymmetry)
    {
      cerr << "Error: cannot specify both -r and -s\n";
      printUsage();
      exit(1);
    }
	
  if (scoreFunctionName == NULL)
    {
      cerr << "Error: must specify a score function\n";
      printUsage();
      exit(1);
    }
  
  {
    char *scoreFileName = computeFullScorePath(scoreFunctionName);
    
    const Alphabet *a = new Alphabet(scoreFileName);
    if (!a->isValid())
      exit(1);
    
    SCORE = new ScoreFunction(a, scoreFileName);
    if (!SCORE->isValid())
      exit(1);
    
    delete [] scoreFileName;
  }
  
  unsigned int dimension = 
    computeSimulation(SCORE->subs(), forceSymmetry, rearrange);
    
  cerr << "** " << SCORE->name() << ' ' << dimension << '\n';
  return 0;
}


static void printUsage(void)
{
  printVersion();
  
  cerr << "Syntax: findsim [-r] [-s] <scorefcn>\n";
  cerr << "   -s -- assume a symmetric score function\n";
  cerr << "   -r -- attempt to rearrange each dimension to increase\n"
       << "         coverage (incompatible with -s)\n";
  cerr << '\n';
}


static unsigned int computeSimulation(const ScoreMatrix &S, 
				      bool forceSymmetry,
				      bool rearrange)
{
  unsigned int dimension = 0, origDimension = 0;
  ScoreT lbDimension = 0;
  const Alphabet *a = S.alphabet();
  BPGraph G(S);
  
  //
  // Find the least value 'offset' such that adding -offset to every
  // element of S will make it non-negative.
  //
  ScoreT offset = 0;
  for (unsigned int i = 0; i < G.size(); i++)
    for (unsigned int j = G.size(); j < 2 * G.size(); j++)
      {
	ScoreT wij = G.E[i][j];
	
	if (wij < offset)
	  offset = wij;
      }
  
  cout << offset << '\n';
  
  for (unsigned int i = 0; i < G.size(); i++)
    for (unsigned int j = G.size(); j < 2 * G.size(); j++)
      {
	G.E[i][j] -= offset;
	origDimension += G.E[i][j];
	
	if (lbDimension < G.E[i][j])
	  lbDimension = G.E[i][j];
      }
  
  cerr << "orig dimension: " << origDimension 
       << "; lower bound: "  << lbDimension << '\n';
  
  unsigned int *leftVertices = new unsigned int [G.size()];
  unsigned int *rightVertices = new unsigned int [G.size()];
  unsigned int nLeftVertices, nRightVertices;
  Word *adj = new Word [G.size()];
  
  //
  // Keep producing dimensions until all the weight of G is accounted for.
  //
  for (;;)
    {
      //
      // Build adjacency vector for each left-hand vertex in G
      //
      for (unsigned int i = 0; i < G.size(); i++)
	{
	  Word w = 0;
	  
	  for (unsigned int j = 0; j < G.size(); j++)
	    {
	      if (G.E[i][j + G.size()] > 0)
		w = setBit(w, j);
	    }
	  
	  adj[i] = w;
	}
      
      
      //
      // Compute a collection of bicliques for next weighted dimension.
      //
      BicliqueVector v = findBicliques(adj, G.size(), 
				       forceSymmetry, rearrange);
      if (v.length() == 0) // no bicliques found
	{
	  if (forceSymmetry) // sanity: make sure the sim is really complete
	    {
	      forceSymmetry = false;
	      continue;
	    }
	  else
	    break; // no nonzero edges left in G
	}
      
      
      //
      // Compute the smallest weight of any edge in any biclique in v.
      //
      ScoreT minWeight = INFTY;
      for (unsigned int c = 0; c < v.length(); c++)
	{
	  const Biclique &C = v[c];
	  
	  nLeftVertices  = expand(C.left, G.size(), leftVertices);
	  nRightVertices = expand(C.right, G.size(), rightVertices);
	  
	  for (unsigned int i = 0; i < nLeftVertices; i++)
	    for (unsigned int j = 0; j < nRightVertices; j++)
	      {
		ScoreT wij = G.E[leftVertices[i]][rightVertices[j] + G.size()];
		if (wij < minWeight)
		  minWeight = wij;
	      }
	}
      
      dimension += minWeight;
      cout << minWeight;
      
      
      //
      // Print all the biclques for this dimension.
      //
      for (unsigned int c = 0; c < v.length(); c++)
	{
	  const Biclique &C = v[c];
	  
	  nLeftVertices  = expand(C.left, G.size(), leftVertices);
	  nRightVertices = expand(C.right, G.size(), rightVertices);
	  
	  cout << " (";
	  for (unsigned int i = 0; i < nLeftVertices; i++)
	    cout << a->toChar(leftVertices[i]+1);
	  cout << ',';
	  for (unsigned int i = 0; i < nRightVertices; i++)
	    cout << a->toChar(rightVertices[i]+1);
	  cout << ')';
	  
	  for (unsigned int i = 0; i < nLeftVertices; i++)
	    for (unsigned int j = 0; j < nRightVertices; j++)
	      G.E[leftVertices[i]][rightVertices[j] + G.size()] -= minWeight;
	}
      
      cout << '\n';
    }
  
  delete [] leftVertices;
  delete [] rightVertices;
  delete [] adj;
  
  return dimension;
}
