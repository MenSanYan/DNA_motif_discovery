//
// MAIN.CC
// Main program for LSH string matcher
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>

#include "loadsequences.h"
#include "fileops.h"
#include "random.h"
#include "version.h"

#include "global.h"
#include "lsh.h"
#include "output.h"

using namespace std;


const SeqLength     DefaultMatchLength = 69;
const ScoreT        DefaultMinScore    = 23;
const SeqNumber     DefaultPartition   = 1;

//
// global variables
//
const Alphabet *InputAlphabet;
const ScoreFunction *SCORE;
const Simulation *SIM = NULL;
bool CountingMismatches = false;

bool FixedParams = false;
unsigned int FixedNIterations = 0;
SeqLength    FixedNPositions = 0;


//
// file-scope variables (for arguments read by getopt())
//
static SeqLength MatchLength = DefaultMatchLength;
static ScoreT    MinScore    = DefaultMinScore;
static SeqNumber Partition   = DefaultPartition;

static long RandSeed = -1; // choose seed from system time
static const char *ScoreFunctionName = NULL;


//
// local prototypes
//
static void printUsage(void);


int main(int argc, char *argv[])
{
  bool duplicateSeqs = false;
  
  SeqVector sequences = loadSequences(argc, argv, "C:d:k:l:m:S:F:P:Rh", false);
  
  if (sequences.isEmpty())
    {
      cerr << "Error: need at least one sequence of length at least "
	   << MatchLength << '\n';
      printUsage();
      exit(1);
    }
  else if (sequences.length() == 1 && Partition == DefaultPartition)
    {
      Partition = 0; // indicates self-comparison
    }
  else if (Partition > sequences.length())
    {
      cerr << "Error: partition must be <= # of input sequences\n";
      exit(1);
    }
  
  InputAlphabet = sequences[0].alphabet;
  if (outputForwardStrand && !InputAlphabet->isDNA())
    {
      cerr << "Warning: ignoring -R for non-DNA sequences\n";
      outputForwardStrand = false;
    }
  
  {
    CountingMismatches = (ScoreFunctionName == NULL);
    
    if (CountingMismatches)
      {
	ScoreFunctionName = (InputAlphabet->isDNA() 
			     ? "MISMATCHES-D"
			     : "MISMATCHES-P");
      }
    
    char *scoreFileName = computeFullScorePath(ScoreFunctionName);
    SCORE = new ScoreFunction(InputAlphabet, scoreFileName);
    if (!SCORE->isValid())
      exit(1);
    
    if (!CountingMismatches)
      {
	strcat(scoreFileName, ".sim");
	SIM = new Simulation(InputAlphabet, scoreFileName);
	
	if (!SIM->isValid() || !SIM->sanityCheck(SCORE->subs()))
	  exit(1);
      }
    
    delete [] scoreFileName;
  }
  
  cerr << "*** PARAMS: l = " << MatchLength
       << ", d = "           << MinScore;
  
  if (FixedParams)
    {
      cerr << ", k = " << FixedNPositions
	   << ", m = " << FixedNIterations;
    }
  
  cerr << ", P = " << Partition;
  
  if (sequences[0].isDNA() && outputForwardStrand)
    cerr << " [positions w/r to fwd strand]";
  
  cerr << " ***\n\n";
  
  if (CountingMismatches)
    {
      // TEMPORARY HACK: if we're just counting mismatches, -d specifies
      // the number of MISMATCHES, not the number of matches.  This is
      // for historical compatibility and should eventually be removed.
      //
      MinScore = MatchLength - MinScore;
    }
  else
    {
      cerr << "*** Score Function: " << SCORE->name() << '\n';
      
      if (Partition == 0)
	{
	  duplicateSeqs = true;
	  
	  unsigned int origLength = sequences.length();
	  for (unsigned int j = 0; j < origLength; j++)
	    {
	      SeqInfo s = sequences[j];
	      s.seqNum += origLength;
	      sequences.add(s);
	    }
	  
	  Partition = origLength;
	}
    }
  
  ////////////////////////////////////////////////////////////////////
  
  seedPRNG(RandSeed);
  
  installCheckpointHandlers();
  
  MatchVector ms = computeMatches(sequences, Partition,
				  MatchLength, MinScore,
				  duplicateSeqs);
  
  printAllMatches(cout, ms, sequences);
  
  return 0;
}


//
// handleArgument()
// Pass-through argument handler for options not captured by
// loadSequences().
//
void handleArgument(int optchar, const char *optarg)
{
  switch (optchar)
    {
    case 1:   // a file argument? WTF?
      cerr << "File argument " << optarg << " not understood\n";
      exit(1);
      
    case 'C': // checkpoint file
      checkpointFileName = optarg;
      break;
      
    case 'l': // match length
      {
	MatchLength = SeqLength( strtoul(optarg, NULL, 10) );
	if (MatchLength == 0)
	  {
	    cerr << "Error: match length must be > 0\n";
	    exit(1);
	  }
      }
      break;
      
    case 'd': // minimum score threshold
      MinScore = SeqLength( strtoul(optarg, NULL, 10 ) );
      break;
      
    case 'm': // number of iterations
      FixedNIterations = (unsigned int) strtoul(optarg, NULL, 10); 
      FixedParams = true;
      break;
      
    case 'k': // number of hash posns/iteration
      {
	FixedNPositions = SeqLength( strtoul(optarg, NULL, 10) );
	if (FixedNPositions == 0)
	  {
	    cerr << "Error: number of hash posns must be > 0\n";
	    exit(1);
	  }
	FixedParams = true;
      }
      break;
      
    case 'P': // partitioning point
      Partition = SeqNumber( strtoul(optarg, NULL, 10) );
      break;
      
    case 'R': // force output indices to be printed w/r to forward strand
      outputForwardStrand = true;
      break;
      
    case 'S': // random seed
      RandSeed = (unsigned int) strtoul(optarg, NULL, 10);
      break;
      
    case 'F': // score function
      ScoreFunctionName = optarg;
      break;
      
    case 'h': // usage or unknown
    default:
      printUsage();
      exit(1);
    }
}

//
// printUsage()
// Print a summary of the input options.
//
static void printUsage(void)
{
  printVersion();
  
  cerr << "Syntax: lsh [sequence options] [-l #] [-d #] [-P #]\n"
       << "            [-S #] [-C file] [-R] [-F <scorefcn>]\n"
       << "            [-k #] [-m #]\n";
  cerr << '\n';
  cerr << "   -C file       -- use 'file' to write checkpoints (default "
       << "stdout)\n";
  cerr << "   -l #          -- length of match (default " 
       << DefaultMatchLength << ")\n";
  cerr << "   -d #          -- minimum score threshold (default "
       << DefaultMinScore << ")\n";
  cerr << "   -P #          -- last sequence before partition (default "
       << DefaultPartition << ")\n";
  cerr << "   -R            -- force output sequence posns to be w/r to"
       << " forward strand\n";
  cerr << "   -S #          -- seed value for PRNG (default from sys time)\n";
  cerr << "   -F <scorefcn> -- name of score function to use\n"
       << "                    (default: *at most* d mismatches)\n";
  cerr << "   -k #          -- number of projected positions (optional)\n";
  cerr << "   -m #          -- number of projections (optional)\n";
  
  cerr << '\n';
  
  printSequenceUsage();
  
  cerr << '\n';
  cerr << "CHECKPOINTING: \n";
  cerr << "  Send SIGUSR1 to write checkpoint file, SIGHUP to write\n"
       << "  file and quit.  Checkpoint happens at end of current\n"
       << "  iteration.\n";
}
