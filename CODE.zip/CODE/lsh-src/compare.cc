//
// COMPARE.CC
// Comparisons between Records
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// Perform pairwise comparisons on all the records in a bucket.
// Return a vector of Match structures containing all the pairs
// which are approximate matches.
//

#include "compare.h"

#include "global.h"

// counter for number of pairwise comparisons performed by checking code
unsigned long long nPairwiseComps = 0;

//
// local prototypes
//
static bool compareSeqsByMismatches(const SeqInfo &, const SeqInfo &,
				    SeqPosn *, SeqPosn *,
				    SeqLength, SeqLength);

static bool compareSeqsByScore(const SeqInfo &, const SeqInfo &,
			       SeqPosn *, SeqPosn *,
			       SeqLength, ScoreT, const ScoreMatrix &);


// Switch a comparison on whether we're doing mismatch
// counting or score thresholding.
inline bool compareSeqs(const SeqInfo &seq1, const SeqInfo &seq2,
			SeqPosn *start1, SeqPosn *start2,
			SeqLength length, ScoreT minScore)
{
  if (CountingMismatches)
    {
      return compareSeqsByMismatches(seq1, seq2, start1, start2, length, 
				     length - minScore);
    }
  else
    {
      return compareSeqsByScore(seq1, seq2, start1, start2, length, 
				minScore, SCORE->subs());
    }
}


//
// compareBucketOneSequence()
// Compare all pairs of records in a bucket of size bucketSize.
// Assume that all the the records come from a single sequence 'seq'.
//
// NOTE: this code is only ever called for mismatch counting; score
// thresholding must duplicate a single sequence so that general
// simulation works correctly.
//
// RETURNS: vector of matching pairs
//
MatchVector 
compareBucketOneSequence(const Record *bucket,
			 SeqLength bucketSize,
			 SeqLength matchLength,
			 ScoreT minScore,
			 const SeqInfo &seq)
{
  SeqNumber seqNum = seq.seqNum;
  MatchVector ms;
  
  // Check all pairs.
  //
  for (SeqPosn firstPtr = 0; firstPtr < bucketSize; firstPtr++)
    for (SeqPosn secondPtr = firstPtr + 1; secondPtr < bucketSize; secondPtr++)
      {
	SeqPosn firstPosn  = bucket[firstPtr ].position();
	SeqPosn secondPosn = bucket[secondPtr].position();
	
	if (compareSeqs(seq, seq,
			&firstPosn, &secondPosn,
			matchLength, minScore))
	  {
	    // remove trivial redundancy by canonically ordering matches
	    if (firstPosn > secondPosn)
	      {
		SeqPosn tmp = firstPosn;
		firstPosn   = secondPosn;
		secondPosn = tmp;
	      }
	    
	    Match match(seqNum, firstPosn, seqNum, secondPosn, matchLength);
	    ms.add(match);
	  }
      }
  
  return ms;
}


//
// compareBucketMultipleSequences()
// Compare all pairs of records from distinct sequences in a bucket of
// size bucketSize.
//
// NOTE: this code is only ever called for mismatch counting; score
// thresholding must duplicate the inputs so that simulation works 
// correctly.
//
// RETURNS: vector of matching pairs
//
MatchVector 
compareBucketMultipleSequences(const Record *bucket,
			       SeqLength bucketSize,
			       SeqLength matchLength,
			       ScoreT minScore,
			       const SeqInfo *seqs)
{
  SeqNumber lastSeqNum = bucket[bucketSize - 1].seqNum();
  MatchVector ms;
  
  SeqPosn firstPtr = 0;
  
  // firstPtr proceeds in order through all sequences.  Every time
  // we start a new sequence's records, we compute the start of the
  // next sequence's records and compare from there.  We stop
  // when we reach the begining of the records for the last sequence.
  //
  do
    {
      SeqNumber firstSeqNum   = bucket[firstPtr].seqNum();
      const SeqInfo &firstSeq = seqs[firstSeqNum];
      
      // Find the beginning of the records for the next sequence.
      //
      SeqPosn secondStart = firstPtr;
      do
	secondStart++;
      while (bucket[secondStart].seqNum() == firstSeqNum);
      
      // Process all sequences after the current first one.
      //
      for (; firstPtr < secondStart; firstPtr++)
	{
	  for (SeqPosn secondPtr = secondStart; 
	       secondPtr < bucketSize; 
	       secondPtr++)
	    {
	      SeqNumber secondSeqNum = bucket[secondPtr].seqNum();
	      const SeqInfo &secondSeq = seqs[secondSeqNum];
	      
	      SeqPosn firstPosn  = bucket[firstPtr ].position();
	      SeqPosn secondPosn = bucket[secondPtr].position();
	      
	      if (compareSeqs(firstSeq, secondSeq,
			      &firstPosn, &secondPosn,
			      matchLength, minScore))
		{
		  Match match(firstSeqNum, firstPosn,
			      secondSeqNum, secondPosn,
			      matchLength);
		  ms.add(match);
		}
	    }
	}
    }
  while (bucket[firstPtr].seqNum() != lastSeqNum);
  
  return ms;
}


//
// compareBucketPartitioned()
// Compare all pairs of records from opposite sides of a partition in
// a bucket of size bucketSize.  The partition occurs between
// sequences less than firstSeqAfterPartition and those greater than
// or equal to it.
//
// RETURNS: vector of matching pairs
//
MatchVector
compareBucketPartitioned(const Record *bucket,
			 SeqLength bucketSize,
			 SeqLength matchLength,
			 ScoreT minScore,
			 const SeqInfo *seqs,
			 SeqNumber firstSeqAfterPartition,
			 bool duplicateSeqs)
{
  SeqPosn secondStart = 1;
  MatchVector ms;
  
  // Find the partition point.
  //
  while (bucket[secondStart].seqNum() < firstSeqAfterPartition) 
    secondStart++;
  
  for (SeqPosn firstPtr = 0; firstPtr < secondStart; firstPtr++)
    {
      SeqNumber firstSeqNum = bucket[firstPtr].seqNum();
      SeqPosn firstPosn     = bucket[firstPtr].position();
      const SeqInfo &firstSeq = seqs[firstSeqNum];
      
      for (SeqPosn secondPtr = secondStart; 
	   secondPtr < bucketSize; 
	   secondPtr++)
	{
	  SeqNumber secondSeqNum = bucket[secondPtr].seqNum();
	  SeqPosn secondPosn     = bucket[secondPtr].position();
	  
	  // When using a simulation requiring duplication of
	  // input seqs, store the "real" seq numbers in the Match.
	  if (duplicateSeqs) 
	    {
	      secondSeqNum -= firstSeqAfterPartition;
	      
	      // FIXME: for now, only permit comparisons between sequences in
	      // canonical order.  In principle, we shouldn't eliminate any 
	      // matches except those with seq1 == seq2 and posn1 == posn2.
	      //
	      if (secondSeqNum < firstSeqNum || 
		  (secondSeqNum == firstSeqNum && secondPosn <= firstPosn))
		continue;
	    }
	  
	  const SeqInfo &secondSeq = seqs[secondSeqNum];
	  
	  if (compareSeqs(firstSeq, secondSeq,
			  &firstPosn, &secondPosn,
			  matchLength, minScore))
	    {
	      Match match;
	      
	      if (duplicateSeqs)
		{
		  // To eliminate redundancy, store each Match in
		  // canonical form: lowest numbered seq first, and
		  // lowest posn first when both seqs are identical.
		  //
		  if (firstSeqNum > secondSeqNum)
		    {
		      match.setSeq(0, secondSeqNum);
		      match.setSeq(1, firstSeqNum);
		      match.setLow(0, secondPosn);
		      match.setLow(1, firstPosn);
		    }
		  else
		    {
		      match.setSeq(0, firstSeqNum);
		      match.setSeq(1, secondSeqNum);
		      
		      if (firstSeqNum == secondSeqNum &&
			  firstPosn > secondPosn)
			{
			  match.setLow(0, secondPosn);
			  match.setLow(1, firstPosn);
			}
		      else
			{
			  match.setLow(0, firstPosn);
			  match.setLow(1, secondPosn);
			}
		    }
		}
	      else
		{
		  match.setSeq(0, firstSeqNum);
		  match.setSeq(1, secondSeqNum);
		  match.setLow(0, firstPosn);
		  match.setLow(1, secondPosn);
		}
	      
	      match.setLength(matchLength);
	      ms.add(match);
	    }
	}
    }
  
  return ms;
}

////////////////////////////////////////////////////////////////////////////

//
// compareSeqsByMismatches()
// Compare two sequences, starting at positions *start0/*start1, for
// up to matchLength residues.  If the sequences contain at most
// nMismatches mismatches in this interval, return true; else, 
// return false.
//
// NOTE: We are allowed to move the starts slightly if it could improve the
// chances of getting a match, and to make the match "canonical".
// In particular, unless the match occurs at the beginning or end of
// one of the strings, it will always start with a pair of matching
// residues preceded by a mismatched pair.
//
// RETURNS: true iff the sequence at *start0/*start1 (after moving)
//          has at most nMismatches mismatches over matchLength residues.
//
static bool compareSeqsByMismatches(const SeqInfo &seqInfo0,
				    const SeqInfo &seqInfo1,
				    SeqPosn *start0, SeqPosn *start1,
				    SeqLength matchLength, 
				    SeqLength nMismatches)
{
  const Residue *seq0 = seqInfo0.data;
  const Residue *seq1 = seqInfo1.data;
  SeqPosn s0 = *start0, s1 = *start1;
  SeqLength delta = 0;
  
  nPairwiseComps++;
  
  // If the starting positions are preceded by additional matching characters,
  // it never hurts to move back to the first such match.  Similarly,
  // if the starting positions are mismatched characters, it never hurts
  // to move forward to the first match.
  //
  if (Alphabet::isMatch(seq0[s0], seq1[s1]))             // move back
    {
      delta = 1;
      
      while (s0 > 0 && s1 > 0)
	{
	  if (Alphabet::isMatch(seq0[s0 - 1], seq1[s1 - 1]))
	    { 
	      s0--; s1--; delta++;
	    }
	  else
	    break;
	}
    }
  else                                           // move forward
    {
      while (s0 < seqInfo0.length - matchLength &&
	     s1 < seqInfo1.length - matchLength)
	{
	  if (Alphabet::isMatch(seq0[s0], seq1[s1]))
	    {
	      delta = 1;
	      break;
	    }
	  else
	    {
	      s0++; s1++;
	    }
	}
    }
  
  *start0 = s0;
  *start1 = s1;
  
  SeqLength nmms = 0;
  
  for (SeqPosn j = delta; j < matchLength; j++)
    {
      if (Alphabet::isMismatch(seq0[s0 + j], seq1[s1 + j]))
	{
	  if (++nmms > nMismatches)
	    return false;
	}
    }
  
  return true;
}


//
// compareSeqsByScore()
// Compare two sequences, starting at positions *start0/*start1, for
// up to matchLength residues.  If the sequences score at least minScore
// under the substitution score matrix M, return true; else, 
// return false.
//
// NOTE: We are allowed to move the starts slightly if it could improve the
// score of the match.  We move the starts backward by default; if that
// doesn't improve the score, we move them forwards.  This is a weighted
// generalization of the "canonicalization" operation in unweighted
// matching.
//
// RETURNS: true iff the sequence at *start0/*start1 (after moving)
//          has score at least minScore over matchLength residues.
//
static bool compareSeqsByScore(const SeqInfo &seqInfo0, 
			       const SeqInfo &seqInfo1,
			       SeqPosn *start0, SeqPosn *start1,
			       SeqLength matchLength, ScoreT minScore,
			       const ScoreMatrix &M)
{
  const Residue *seq0 = seqInfo0.data;
  const Residue *seq1 = seqInfo1.data;
  SeqPosn s0 = *start0, s1 = *start1;
  SeqPosn delta = 0;
  ScoreT score = 0;
  
  nPairwiseComps++;
  
  // Move the starts backwards while doing so would not decrease
  // the score of the match.
  //
  while (s0 > 0 && s1 > 0)
    {
      ScoreT sPrev = M[ seq0[s0 - 1] ][ seq1[s1 - 1] ];
      
      if (sPrev >=
	  M[ seq0[s0 - 1 + matchLength] ][ seq1[s1 - 1 + matchLength] ])
	{ 
	  s0--; s1--; 
	  delta = 1; score = sPrev;
	}
      else
	break;
    }
  
  if (delta == 0)
    {
      // Move the starts forwards while doing so would not decrease
      // the score of the match.
      //
      while (s0 < seqInfo0.length - matchLength &&
	     s1 < seqInfo1.length - matchLength)
	{
	  ScoreT sCurr = M[ seq0[s0] ][ seq1[s1] ];
	  if (M[ seq0[s0 + matchLength] ][ seq1[s1 + matchLength] ] >= sCurr)
	    {
	      s0++; s1++;
	    }
	  else
	    {
	      delta = 1; score = sCurr;
	      break;
	    }
	}
    }
  
  *start0 = s0;
  *start1 = s1;
  
  for (SeqPosn j = delta; j < matchLength; j++)
    score += M[seq0[s0 + j]][seq1[s1 + j]];
  
  return (score >= minScore);
}
