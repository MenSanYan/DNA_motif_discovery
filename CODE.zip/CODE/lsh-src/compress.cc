//
// COMPRESS.CC
// Compress an array containing Records sorted primarily by LSH value and
// with that by sequence number.  Each run of records with identical LSH
// values is considered a "bucket".
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// In the compression procedures, we
//
//  * throw out buckets which have no pairs that can be compared,
//
//  * shrink buckets bigger than MAX_BUCKET_SIZE (defined below) by
//    sampling only MAX_BUCKET_SIZE records (at random),
// 
//  * overwrite the LSH value of the first Record in each bucket
//    with the bucket's size.
//
// We compress the array in place, removing any Records that should
// not be used, and return the new array length.
//
// FIXME: the LSH value may only be 32 bits, but the bucket size
// could be as large as 64 bits.  Sigh.
//

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cassert>

#include "compress.h"
#include "random.h"
#include "randomprimes.h"

using namespace std;


#define AVOID_PATHOLOGY

//#define DEBUG_PATHOLOGY

////////////////////////////////////////////////////////////////////////
// PATHOLOGY AVOIDANCE
// For any bucket larger than this size, randomly choose this many
// Records (without replacement, of course) to keep.
////////////////////////////////////////////////////////////////////////

const SeqLength MAX_BUCKET_SIZE = 256;

//
// local prototypes
//
static void randomizedSelect(Record *, SeqLength);
static void selectExpensively(SeqPosn *, SeqLength);
static int cmpSeqPosns(const void *, const void *);


//
// compressBucketsOneSequence()
//
// Compress buckets assuming that all records in each bucket will
// be from a single sequence.  We must keep any bucket with more
// than a single record for comparisons.
//
SeqLength compressBucketsOneSequence(Record *records, SeqLength nRecords)
{
  SeqPosn srcIdx = 0, destIdx = 0;
#ifdef DEBUG_PATHOLOGY
  SeqLength nBuckets = 0;
  unsigned long nComps = 0;
#endif

  // Set sentinel record so we don't have to keep checking
  // for end of records.
  //
  records[nRecords].setKey( ~(records[nRecords - 1].key()) );
  
  while (srcIdx < nRecords)
    {
      SeqPosn startIdx = srcIdx;
      LSHValue currKey = records[startIdx].key();
      
      do
	srcIdx++;
      while (records[srcIdx].key() == currKey);
      
      // Criterion for keeping: bucket contains at least two records.
      //
      if (srcIdx - startIdx >= 2)
	{
	  SeqLength bucketSize = srcIdx - startIdx;

#ifdef AVOID_PATHOLOGY
	  if (bucketSize > MAX_BUCKET_SIZE)
	    {
	      randomizedSelect(&records[startIdx], bucketSize);
	      bucketSize = MAX_BUCKET_SIZE;
	    }
#endif	  
	  records[startIdx].setKey(bucketSize);
	  
	  memmove(&records[destIdx], &records[startIdx],
		  bucketSize * sizeof(Record));
	  
	  destIdx += bucketSize;
#ifdef DEBUG_PATHOLOGY
	  nBuckets++;
	  nComps += bucketSize * (bucketSize - 1) / 2;
#endif
	}
    }

#ifdef DEBUG_PATHOLOGY  
  cerr << "Compress: " << nBuckets << " buckets (average size = "
       << SeqLength(double(destIdx) / double(nBuckets) + 0.5) << ")\n";
  cerr << "Number of comparisons: " << nComps << '\n';
#endif

  return destIdx;
}


//
// compressBucketsMultipleSequences()
// Compress buckets assuming that we are doing pairwise comparisons
// only on records from different sequences.  Only keep buckets
// with records from more than one sequence.
//
SeqLength compressBucketsMultipleSequences(Record *records, SeqLength nRecords)
{
  SeqPosn srcIdx = 0, destIdx = 0;
#ifdef DEBUG_PATHOLOGY
  SeqLength nBuckets = 0;
  unsigned long nComps = 0;
#endif
  
  // Set sentinel record so we don't have to keep checking
  // for end of records.
  //
  records[nRecords].setKey( ~(records[nRecords - 1].key()) );
  
  while (srcIdx < nRecords)
    {
      SeqPosn startIdx = srcIdx;
      LSHValue currKey = records[startIdx].key();
      
      do
	srcIdx++;
      while (records[srcIdx].key() == currKey); // skip to end of bucket
      
      // Criterion for keeping: bucket contains records from at
      // least two different sequences.
      //
      if (records[startIdx].seqNum() != records[srcIdx - 1].seqNum())
	{
	  SeqLength bucketSize = srcIdx - startIdx;
	  
#ifdef AVOID_PATHOLOGY
	  if (bucketSize > MAX_BUCKET_SIZE)
	    {
	      randomizedSelect(&records[startIdx], bucketSize);
	      bucketSize = MAX_BUCKET_SIZE;
	      
	      // Make sure we didn't undo the keep criterion.
	      if (records[startIdx].seqNum() == 
		  records[startIdx + bucketSize - 1].seqNum())
		continue;
	    }
#endif	  
	  records[startIdx].setKey(bucketSize);
	  
	  memmove(&records[destIdx], &records[startIdx],
		  bucketSize * sizeof(Record));
	  
	  destIdx += bucketSize;
#ifdef DEBUG_PATHOLOGY
	  nBuckets++;
	  nComps += bucketSize * (bucketSize - 1) / 2;
#endif
	}
    }

#ifdef DEBUG_PATHOLOGY  
  cerr << "Compress: " << nBuckets << " buckets (average size = "
       << SeqLength(double(destIdx) / double(nBuckets) + 0.5) << ")\n";
  cerr << "Number of comparisons: " << nComps << '\n';
#endif
  
  return destIdx;
}


//
// compressBucketsPartitioned()
//
// Compress buckets assuming that comparisons will be performed only on
// records from sequences on different sides of a partition. Keep buckets
// only if they contain records from both sides of the partition.
//
SeqLength compressBucketsPartitioned(Record *records, SeqLength nRecords,
				     SeqNumber firstSeqAfterPartition)
{
  SeqPosn srcIdx = 0, destIdx = 0;
#ifdef DEBUG_PATHOLOGY
  SeqLength nBuckets = 0;
  unsigned long nComps = 0;
#endif
  
  // Set sentinel record so we don't have to keep checking
  // for end of records.
  //
  records[nRecords].setKey( ~(records[nRecords - 1].key()) );
  
  while (srcIdx < nRecords)
    {
      SeqPosn startIdx = srcIdx;
      LSHValue currKey = records[startIdx].key();
      
      do
	srcIdx++;
      while (records[srcIdx].key() == currKey);
            
      // Criterion for keeping: bucket contains records from
      // sequences on both sides of the partition.
      //
      if (records[startIdx  ].seqNum() <  firstSeqAfterPartition &&
	  records[srcIdx - 1].seqNum() >= firstSeqAfterPartition)
	{
	  SeqLength bucketSize = srcIdx - startIdx;
	  
#ifdef AVOID_PATHOLOGY
	  if (bucketSize > MAX_BUCKET_SIZE)
	    {
	      randomizedSelect(&records[startIdx], bucketSize);
	      bucketSize = MAX_BUCKET_SIZE;
	      
	      // Make sure we didn't undo the keep criterion.
	      if ((records[startIdx                 ].seqNum() >= 
		   firstSeqAfterPartition) ||
		  (records[startIdx + bucketSize - 1].seqNum() <
		   firstSeqAfterPartition))
		continue;
	    }
#endif	  	  
	  records[startIdx].setKey(bucketSize);
	  
	  memmove(&records[destIdx], &records[startIdx],
		  bucketSize * sizeof(Record));
	  
	  destIdx += bucketSize;
#ifdef DEBUG_PATHOLOGY
	  nBuckets++;
	  nComps += bucketSize * (bucketSize - 1) / 2;
#endif
	}
    }

#ifdef DEBUG_PATHOLOGY  
  cerr << "Compress: " << nBuckets << " buckets (average size = "
       << SeqLength(double(destIdx) / double(nBuckets) + 0.5) << ")\n";
  cerr << "Number of comparisons: " << nComps << '\n';
#endif
  
  return destIdx;
}

///////////////////////////////////////////////////////////////////////////

//
// randomizedSelect()
// Select MAX_BUCKET_SIZE records "at random" from a bucket,
// and overwrite the first MAX_BUCKET_SIZE records with them.
// The new records will remain sorted.
//
// To select records efficiently, we first pick a large prime increment
// at random from a good-sized list of such numbers.  We then
// step through the bucket, each time setting the source index to
// (source index + increment) % bucketSize.  Because the increment
// is prime, we never choose the same record twice if the bucket
// is larger than MAX_BUCKET_SIZE.
//
static void randomizedSelect(Record *bucket, SeqLength bucketSize)
{
  static Record newBucket[MAX_BUCKET_SIZE];
  static SeqPosn indices[MAX_BUCKET_SIZE];
  SeqPosn incr = getRandomPrime();
  SeqPosn srcIdx = 0;

#ifdef DEBUG_PATHOLOGY
  cerr << "*** Sampling from bucket of size " << bucketSize
       << " using prime " << incr << '\n';
#endif
  
  if (incr <= bucketSize) // This should never, EVER happen in practice...
    {
      cerr << "* Warning: encountered HUGE bucket (size = " 
	   << bucketSize << ")\n";
      
      selectExpensively(indices, bucketSize);
    }
  else
    {
      // Choose MAX_BUCKET_SIZE records from the bucket *without*
      // replacement. incr is a prime greater than bucketSize, so it 
      // will be relatively prime to the bucketSize.
      //
      for (SeqPosn j = 0; j < MAX_BUCKET_SIZE; j++)
	{
	  srcIdx = (srcIdx + incr) % bucketSize;
	  indices[j] = srcIdx;
	}
    }
  
  // Make sure the selected records remain sorted!
  //
  qsort(indices, MAX_BUCKET_SIZE, sizeof(SeqPosn), cmpSeqPosns);
  
  for (SeqPosn destIdx = 0; destIdx < MAX_BUCKET_SIZE; destIdx++)
    newBucket[destIdx] = bucket[indices[destIdx]];
  
  memcpy(bucket, newBucket, MAX_BUCKET_SIZE * sizeof(Record));
}


//
// selectExpensively()
// Select MAX_BUCKET_SIZE indices at random from the interval
// 0 .. bucketSize - 1.  Store the result in the array
// indices[].
//
// This procedure is expensive because it doesn't use random primes,
// but it works even if the bucket size is bigger than any random prime
// in our list.
//
static void selectExpensively(SeqPosn *indices, SeqLength bucketSize)
{
  // Choose MAX_BUCKET_SIZE random indices without replacement from
  // 0.. bucketSize - 1.
  //
  SeqPosn nRands = 0;
  do
    {
      SeqPosn randValue = randVal(bucketSize);
      bool repeat = false;
      
      for (SeqPosn j = 0; j < nRands; j++)
	{
	  if (indices[j] == randValue)
	    {
	      repeat = true;
	      break;
	    }
	}
      
      if (!repeat)
	indices[nRands++] = randValue;
    }
  while (nRands < MAX_BUCKET_SIZE);
}


//
// comparator for qsort()
//
static int cmpSeqPosns(const void *p1, const void *p2)
{
  SeqPosn v1 = *((const SeqPosn *) p1);
  SeqPosn v2 = *((const SeqPosn *) p2);
  
  if (v1 >= v2)
    return (v1 > v2);
  else
    return -1;
}
