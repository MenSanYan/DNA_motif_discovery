//
// PICKLD.CC
// Provide support for choosing good parameters -l and -d for lsh.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>
#include <cmath>

#include "loadsequences.h"
#include "estparams.h"
#include "fileops.h"

#include "global.h"
#include "version.h"

using namespace std;

struct ProblemParams {
  SeqLength matchLength;
  ScoreT    minScore;
  double    fpRate;
};

//
// Default values for input arguments
//
const double DefaultDNAFPRate       = 50.0;   // more relaxed than previously.
const double DefaultProteinFPRate   = 1.0e+4; // compromise cost/results
const double DefaultIdentity        = 0.70;
const SeqLength DefaultProteinMatchLength = 10;

const SeqNumber     DefaultPartition = 1;
const char *DefaultScoreFunctionName = NULL; // specifies mismatch ctr

//
// global variables
//
const Alphabet *InputAlphabet;   // alphabet of input seqs
const Simulation *SIM = NULL;    // required only to compile estparams.cc

//
// file-scope variables (for arguments read by getopt())
//
static const char *scoreFunctionName = DefaultScoreFunctionName;
static SeqNumber   Partition         = DefaultPartition;

static SeqLength   InputMatchLength  = 0;
static ScoreT      InputMinScore     = INFTY;
static double      InputFPRate       = 0.0;
static double      InputIdentity     = 0.0;

//
// file-scope variables that I'm too lazy to pass around
//

static SeqPairDistn aggDistn;             // aggregate residue distns of input
static const ScoreDistn *sd0;             // score distn of input seqs

//
// local prototypes
//
static void printUsage(void);


//
// Given the distribution of scores for matches of length matchLength,
// compute expected number of matches with score at least threshold
// occurring by chance in in the input.
//
static double computeFPRate(SeqLength matchLength, ScoreT threshold,
			    double problemSize, const ScoreDistn *sd)
{
  double fpRate = 0.0;
  
  for (ScoreT score = sd->high(); score >= threshold; score--)
    fpRate += (*sd)[score];
  
  return fpRate * problemSize;
}


//
// Compute the expected score for a match of length matchLength and
// specified identity under M.
//
static ScoreT computeEqvScore(SeqLength matchLength, double identity, 
			      const ScoreMatrix &M)
{
  double eMatchScore = 0.0, eMismatchScore = 0.0;
  
  double pMatch = 0.0;
  for (Residue j = 1; j <= InputAlphabet->nRealResidues(); j++)
    pMatch += aggDistn.freqs1[j] * aggDistn.freqs2[j];
  
  for (Residue i = 1; i <= InputAlphabet->nRealResidues(); i++)
    for (Residue j = 1; j <= InputAlphabet->nRealResidues(); j++)
      {
	double pPair = aggDistn.freqs1[i] * aggDistn.freqs2[j];
	      
	if (i == j)
	  eMatchScore    += pPair/pMatch * M[i][j];
	else
	  eMismatchScore += pPair/(1.0 - pMatch) * M[i][j];
      }
  
  ScoreT nMismatches = ScoreT(rint(matchLength * (1.0 - identity)));
  
  return 
    ScoreT( eMatchScore * (matchLength - nMismatches) +
	    eMismatchScore * nMismatches );
  //  return 
  //    ScoreT( (eMatchScore * identity + eMismatchScore * (1.0 - identity)) * 
  //	    matchLength );
  
}


//
// inferParamsForDNA()
// Infer appropriate values of l (if needed) and d assuming that
// we're comparing DNA sequences.
//
static ProblemParams 
inferParamsForDNA(SeqLength matchLength, double identity, double fpRate,
		  const ScoreMatrix &M)
{
  ProblemParams params;
  ScoreT score;
  double E;
  
  if (matchLength > 0) // -l specified; can fit either -i or -E
    {
      double problemSize = computeProblemSize(aggDistn, matchLength);
      ScoreDistn *sd     = sd0->computeSumDistn(matchLength);
      
      if (identity == 0.0)  // no -i specified; try to fit -E
	{
	  if (fpRate == 0.0) // -E not specified either
	    fpRate = DefaultDNAFPRate;
	  
	  cerr << "* Finding threshold d to achieve E = " << fpRate
	       << " for l = " << matchLength << '\n'; 
	  
	  //
	  // Find the highest score for which the total false positive
	  // rate for the problem doesn't exceed the specified value.
	  //
	  double threshold = fpRate / problemSize;
	  
	  E = 0.0;
	  score = sd->high() + 1;
	  while (E < threshold && score > sd->low())
	    {
	      score--;
	      E += (*sd)[score];
	    }
	  E -= (*sd)[score];
	  score++;
	  
	  if (score > sd->high())
	    {
	      score = sd->high();
	      E     = (*sd)[score];
	      
	      cerr << "** Warning: false positive rate (E = " << fpRate 
		   << ") cannot be achieved\n"
		   << "            for specified l; setting "
		   << "most stringent threshold possible\n";
	    }
	  
	  E *= problemSize;
	}
      else // -i specified; ignore -E
	{
	  cerr << "* Finding threshold d corresponding to identity i = "
	       <<    identity << " for l = " << matchLength << '\n';
	  
	  score = computeEqvScore(matchLength, identity, M);
	  E = computeFPRate(matchLength, score, problemSize, sd);
	}
      
      delete sd;
      
      params.matchLength = matchLength;
      params.minScore    = score;
      params.fpRate      = E;
    }
  else // -l not specified
    {
      SeqLength lLo, lHi;
      
      // Set defaults for -i and -E if needed
      if (identity == 0.0) identity = DefaultIdentity;
      if (fpRate == 0.0)   fpRate = DefaultDNAFPRate;
	        
      cerr << "* Finding good l/d combo for E = " << fpRate
	   << ", i = " << identity << " ...";
      
      //
      // First, find an interval [lLo, lHi] s.t. the false positive
      // rate is <= fpRate at lLo and > fpRate at lHi.
      //
      for (lHi = 1; /* forever */ ; lHi *=2)
	{
	  ScoreT score = computeEqvScore(lHi, identity, M);

	  double problemSize = computeProblemSize(aggDistn, lHi);
	  ScoreDistn *sd     = sd0->computeSumDistn(lHi);
	  double eHi = computeFPRate(lHi, score, problemSize, sd);
	  cerr << '.';
	  
	  delete sd;
	  
	  if (eHi <= fpRate)
	    break;
	}
      
      lLo = lHi/2;
      
      //
      // Second, use binary search to find the smallest l for which
      // the false positive rate is <= fpRate.
      //
      SeqLength lMin = 0;
      ScoreT    sMin = INFTY;
      double    eMin = 0.0;
      
      do
	{
	  SeqLength l  = (lLo + lHi)/2;
	  ScoreT score = computeEqvScore(l, identity, M);
	  
	  double problemSize = computeProblemSize(aggDistn, l);
	  ScoreDistn *sd     = sd0->computeSumDistn(l);
	  cerr << '.';
	  
	  double E = computeFPRate(l, score, problemSize, sd);
	  delete sd;
	  
	  if (E <= fpRate)
	    {
	      lMin = l;
	      sMin = score;
	      eMin = E;
	      
	      lHi = l;
	    }
	  else
	    {
	      lLo = l + 1;
	    }
	}
      while (lLo < lHi);
      
      cerr << '\n';      
	    
      params.matchLength = lMin;
      params.minScore    = sMin;
      params.fpRate      = eMin;
      
      // Warn user if requring insanely large match length.
      if (params.matchLength > 100)
	{
	  cerr << "* Warning: -E/-i values require l > 100, which is\n"
	       << "           probably not what you want; consider\n"
	       << "           increasing identity threshold and/or\n"
	       << "           allowable false positive rate\n";
	}
    }
  
  
  return params;
}


//
// inferParamsForProtein()
// Infer appropriate values of l (if needed) and d assuming that
// we're comparing protein sequences.
//
static ProblemParams 
inferParamsForProtein(SeqLength matchLength, double fpRate)
{
  ProblemParams params;

  // Use defaults if -l or -E not specified
  if (matchLength == 0) matchLength = DefaultProteinMatchLength;
  if (fpRate == 0.0) fpRate = DefaultProteinFPRate;

  cerr << "* Finding threshold d to achieve E = " << fpRate
       << " for l = " << matchLength << '\n'; 
  
  double problemSize = computeProblemSize(aggDistn, matchLength);
  ScoreDistn *sd     = sd0->computeSumDistn(matchLength);
  
  //
  // Find the highest score for which the total false positive
  // rate for the problem doesn't exceed the specified value.
  //
  double threshold = fpRate / problemSize;
  double E = 0.0;
  
  ScoreT score = sd->high() + 1;
  while (E < threshold && score > sd->low())
    {
      score--;
      E += (*sd)[score];
    }
  E -= (*sd)[score];
  score++;
  
  if (score > sd->high())
    {
      score = sd->high();
      E     = (*sd)[score];

      cerr << "** Warning: false positive rate (E = " << fpRate 
	   << ") cannot be acheived\n"
	   << "            for specified l; setting "
	   << "most stringent threshold possible\n";
    }
  
  delete sd;

  params.matchLength = matchLength;
  params.minScore    = score;
  params.fpRate      = E * problemSize;
  
  return params;
}


int main(int argc, char *argv[])
{
  SeqVector sequences = loadSequences(argc, argv, "l:d:i:E:F:P:h", false);
  const ScoreFunction *scoreFunction;
  bool countingMismatches;
  
  if (sequences.isEmpty())
    {
      cerr << "Error: need at least one sequence!\n";
      printUsage();
      exit(1);
    }
  else if (sequences.length() == 1)
    {
      Partition = 0; // indicates self-comparison
    }
  
  InputAlphabet = sequences[0].alphabet;
  
  // set the input score fcn
  {
    countingMismatches = (scoreFunctionName == NULL);
    
    if (countingMismatches)
      {
        scoreFunctionName = (InputAlphabet->isDNA() 
                             ? "MISMATCHES-D"
                             : "MISMATCHES-P");
	
	// Assume user specified -d as a substitution count.
	if (InputMinScore != INFTY) // assumes InputMatchLength nonzero!
	  InputMinScore = InputMatchLength - InputMinScore;
      }
    
    char *scoreFileName = computeFullScorePath(scoreFunctionName);
    scoreFunction = new ScoreFunction(InputAlphabet, scoreFileName);
    if (!scoreFunction->isValid())
      exit(1);
    
    delete [] scoreFileName;
  }
  
  computeAggregateDistn(sequences, Partition, InputAlphabet, aggDistn);
  sd0 = new ScoreDistn(aggDistn.freqs1, aggDistn.freqs2, 
		       scoreFunction->subs());
  
  ProblemParams params;
  
  if (InputMatchLength != 0 && 
      InputMinScore != INFTY) // params -l, -d already specified
    {
      params.matchLength = InputMatchLength;
      params.minScore    = InputMinScore;
      
      double problemSize = computeProblemSize(aggDistn, InputMatchLength);
      ScoreDistn *sd     = sd0->computeSumDistn(InputMatchLength);
      params.fpRate      = 
	computeFPRate(InputMatchLength, InputMinScore, problemSize, sd);
      delete sd;
    }
  else if (InputAlphabet->isDNA())
    {
      if (InputMatchLength != 0 && InputIdentity != 0.0 && InputFPRate != 0.0)
	{
	  cerr << "** Warning: only two of -E, -i, and -l can be fit at "
	       << "once!\n"
	       << "            (trying to fit -l and -i)\n";
	}
      
      params = inferParamsForDNA(InputMatchLength, InputIdentity,
				 InputFPRate, scoreFunction->subs());
    }
  else // protein
    {
      params = inferParamsForProtein(InputMatchLength, InputFPRate);
    }
  
  if (countingMismatches)
    {
      // Assume user wants d as a substitution count.
      params.minScore = params.matchLength - params.minScore;
    }
  
  cout << "** Recommended parameters: ";
  cout << "l = " << params.matchLength << ", d = " << params.minScore << '\n'; 
  cout << "Expected false positive rate = " << params.fpRate << '\n';
  
  return 0;
}


void handleArgument(int optchar, const char *optarg)
{
  switch (optchar)
    {
    case 1:
      cerr << "File argument " << optarg << " not understood\n";
      exit(1);
      
    case 'l':
      InputMatchLength = strtoul(optarg, NULL, 10);
      break;
      
    case 'd':
      InputMinScore = strtoul(optarg, NULL, 10);
      break;
      
    case 'i':
      InputIdentity = strtod(optarg, NULL);
      if (InputIdentity <= 0.0 || InputIdentity > 1.0)
	{
	  cerr << "Error: identity must be fraction between 0 and 1\n";
	  exit(1);
	}
      break;
      
    case 'E':
      InputFPRate = strtod(optarg, NULL);
      if (InputFPRate <= 0.0)
	{
	  cerr << "Error: expected false positive rate must be positive\n";
	  exit(1);
	}
      break;
      
    case 'P':
      Partition = SeqNumber( strtoul(optarg, NULL, 10) );
      break;
      
    case 'F':
      scoreFunctionName = optarg;
      break;
      
    case 'h':
    default:
      printUsage();
      exit(1);
    }
}


static void printUsage(void)
{
  printVersion();
  
  cerr << "Syntax: pickld [sequence options] [-P #] [-F <scorefcn>]\n"
       << "               [-E #] [-i #] [-l #] [-d #]\n";
  
  cerr << "   -P # -- partition point for input seqs\n";  
  cerr << "   -F <score> -- name of score function to use\n";  
  cerr << "   -E # -- target for expected number of false positives\n";
  cerr << "   -i # -- equivalent ungapped identity (between 0 and 1;\n";
  cerr << "           used for DNA only)\n";
  cerr << "   -l # -- length of similarity\n";
  cerr << "   -d # -- minimum score (# mismatches if no score given)\n";
  cerr << '\n';
  
  printSequenceUsage();
}
