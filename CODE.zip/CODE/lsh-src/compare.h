//
// COMPARE.H
// Procedures for performing pairwise comparisons on all the
// records in a bucket.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __COMPARE_H
#define __COMPARE_H

#include "record.h"
#include "seqinfo.h"
#include "match.h"
#include "scorefunction.h"

// counter for number of pairwise comparisons performed by checking code
extern unsigned long long nPairwiseComps;

MatchVector compareBucketOneSequence(const Record *bucket,
				     SeqLength bucketSize,
				     SeqLength matchLength,
				     ScoreT minScore,
				     const SeqInfo &seq);


MatchVector compareBucketMultipleSequences(const Record *bucket,
					   SeqLength bucketSize,
					   SeqLength matchLength,
					   ScoreT minScore,
					   const SeqInfo *seqs);

MatchVector compareBucketPartitioned(const Record *bucket,
				     SeqLength bucketSize,
				     SeqLength matchLength,
				     ScoreT minScore,
				     const SeqInfo *seqs,
				     SeqNumber firstSeqAfterPartition,
				     bool duplicatedSeqs);

#endif
