//
// OUTPUT.H
// Printing and checkpoint support
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __OUTPUT_H
#define __OUTPUT_H

#include <iostream>

#include "match.h"
#include "seqinfo.h"

extern bool outputForwardStrand; // print all match indices w/r to fwd strand

void printAllMatches(std::ostream &os, const MatchVector ms, 
		     const SeqVector sequences);


//////////////////////////////////
// CHECKPOINT SUPPORT
//////////////////////////////////

extern bool needCheckpoint;
extern bool haltAfterCheckpoint;

extern const char *checkpointFileName;

void installCheckpointHandlers(void);
void checkpoint(const MatchVector ms, const SeqVector sequences);


#endif
