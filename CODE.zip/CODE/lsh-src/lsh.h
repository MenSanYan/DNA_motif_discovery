//
// LSH.H
// interface to the locality-sensitive hashing implementation
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __LSH_H
#define __LSH_H

#include "scorefunction.h"
#include "seqinfo.h"
#include "match.h"

MatchVector computeMatches(const SeqVector, SeqNumber,
			   SeqLength, ScoreT, bool);


#endif
