//
// GLOBAL.H
// Global variables shared across the lsh program
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __GLOBAL_H
#define __GLOBAL_H

#include "scorefunction.h"
#include "simulation.h"

extern const Alphabet *InputAlphabet; // the input sequence alphabet
extern const ScoreFunction *SCORE;    // the input score function
extern const Simulation *SIM;         // simulation for input score function
extern bool CountingMismatches;       // are we just counting mismatches?

extern bool FixedParams;              // did user specify -m and -k?
extern SeqLength FixedNPositions;     // fixed m
extern unsigned int FixedNIterations; // fixed k

#endif
