//
// LSH.CC
// LSH pairwise comparison implementation, based on sorting
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>

#include "lsh.h"

#include "global.h"

#include "matchutil.h"
#include "timer.h"

#include "lshcommon.h"
#include "lshfunction.h"
#include "estparams.h"

#include "compress.h"
#include "compare.h"
#include "output.h"

using namespace std;


// Reductions of the output reduce overlapping matches to a
// series of nonoverlapping intervals on each diagonal.  If
// neither reduction is defined, only exact duplicates are removed.
//
// MERGE_OVERLAPS  -- merge any overlapping matches into one
//                   long region
// REMOVE_OVERLAPS -- remove matches that overlap another match to
//                    the left
//
//#define MERGE_OVERLAPS
#define REMOVE_OVERLAPS

// Compress the list of matched pairs to remove duplicates whenever
// we've added this many new matches since the last compression.
//
const unsigned int MatchCompressionThreshold = (1024 * 1024);

//
// local prototypes
//
static MatchVector cleanupMatches(MatchVector ms, const SeqVector sequences);

//
// Choose the type of reduction to be performed when the output
// space gets too big.
//
inline MatchVector reduceMatches(MatchVector ms)
{
#ifdef MERGE_OVERLAPS
  return mergeOverlappingMatches(ms);
#else
#ifdef REMOVE_OVERLAPS
  return removeOverlappingMatches(ms);
#else
  return removeDuplicateMatches(ms);
#endif
#endif
}

//
// maxAllowedXs()
// Compute the largest number of X's permitted in a sequence of length
// matchLength such that it could still match some other sequence with
// score at least minScore.
//
// ASSUMPTIONS:
//  The score function SCORE has SCORE(r, X) equal for any residue r,
//  and that common score is nonpositive and less than the maximum
//  residue-pair score in the matrix.
//
SeqLength maxAllowedXs(SeqLength matchLength, ScoreT minScore)
{
  const ScoreMatrix &M = SCORE->subs();
  
  ScoreT maxScore = M.maxScore(); // largest residue-pair score
  ScoreT xScore   = M.xScore();
  
  return (matchLength * maxScore - minScore) / (maxScore - xScore);
}


//
// computeMatches()
// Run the LSH algorithm for nIterations iterations (l), choosing nPositions
// hash positions each time (k).
//
// RETURNS: all detected sequences of length at least matchLength with
// score at least minScore.
//
MatchVector computeMatches(const SeqVector sequences, SeqNumber partition,
			   SeqLength matchLength, ScoreT minScore,
			   bool duplicateSeqs)
{
  double constructionTime = 0.0, checkingTime = 0.0, outputTime = 0.0;
  unsigned long long nCanonicalPairs = 0;
  unsigned int nIterations;
  SeqLength nPositions;
  SeqLength estnRecords;
  LSHParams params;
  Record *records;
  MatchVector ms;
  
  SeqLength maxXs = maxAllowedXs(matchLength, minScore);
  
  records = allocRecords(sequences, matchLength, maxXs, &estnRecords);
  if (!records) // error -- could not allocate space
    return ms;
  
  if (FixedParams)
    {
      nPositions  = FixedNPositions;
      nIterations = FixedNIterations;
    }
  else
    {
      params.minScore = minScore;
      params.matchLength = matchLength;
      params.falseNegativeBound = FALSE_NEGATIVE_BOUND;
      
      computeAggregateDistn(sequences, partition, SCORE->subs().alphabet(),
			    params.aggDistn);
      
      params.problemSize = 
	computeProblemSize(params.aggDistn, matchLength);
      
      {
	ScoreDistn sd(params.aggDistn.freqs1, 
		      params.aggDistn.freqs2,
		      SCORE->subs());
	
	if (CountingMismatches)
	  params.pMatch = sd[1];
	else
	  params.scoreDistn = sd.computeSumDistn(matchLength);
      }
      
      guessCosts(params, estnRecords);
      
      chooseKM(params, &nPositions, &nIterations);
      
#ifdef VERBOSE
      cerr << "*** Initial parameters: k = " << nPositions
	   << ", m = " << nIterations << '\n';
#endif
      
      if (nPositions == 0 || nIterations == 0)
	{
	  cerr << "*** Error: could not generate reasonable k,m for "
	       << "this problem!\n";
	  exit(1);
	}
    }
  
  // These values record the number of iters and construction time
  // since they were last reset by the parameter selection code.
  //
  unsigned int tmpNIters = 0;
  double       tmpConstructionTime = 0.0;
  
  SeqLength prevMatchThreshold = 0;
  for (unsigned int iter = 1; iter <= nIterations; iter++)
    {
      SeqLength nRecords, nRecordsToCheck;
      LSHFunction *hasher;
      
#ifdef VERBOSE      
      cerr << "** Hashing sequences for pass " << iter << '/' 
	   << nIterations << '\n';
#endif
      
      startTimer();
      
      if (SIM != NULL)
	hasher = new GeneralLSHFunction(matchLength, nPositions, *SIM);
      else
	hasher = new SimpleLSHFunction(matchLength, nPositions);
      
      nRecords = computeProjections(sequences, hasher, maxXs, records,
				    partition);
      
      delete hasher;
      
#ifdef VERBOSE
      cerr << "** Compressing buckets\n";
	  
      cerr << nRecords << " records before compression\n";
#endif
      
      // Remove useless records.
      //
      if (partition > 0)
	{
	  nRecordsToCheck = 
	    compressBucketsPartitioned(records, nRecords, partition);
	}
      else
	{
	  nRecordsToCheck = 
	    (sequences.length() == 1
	     ? compressBucketsOneSequence(records, nRecords)
	     : compressBucketsMultipleSequences(records, nRecords));
	}
      
      tmpConstructionTime += stopTimer();
      
#ifdef VERBOSE
      cerr << nRecordsToCheck << " records after compression\n";
#endif
      
#ifdef VERBOSE
      cerr << "** Checking potential matches\n";
#endif
      
      startTimer();
      
      const SeqInfo *seqs = sequences.elements();
      Record *bucket = records;
      
      // Do pairwise comparisons for each bucket.  Yow!
      //
      while (SeqLength(bucket - records) < nRecordsToCheck)
	{
	  SeqPosn bucketSize = bucket[0].key(); // hack -- see compress.cc
	  MatchVector msCurrent;
	  
	  if (partition > 0)
	    {
	      msCurrent = compareBucketPartitioned(bucket, bucketSize,
						   matchLength, minScore,
						   seqs, partition,
						   duplicateSeqs);
	    }
	  else
	    {
	      msCurrent =
		(sequences.length() == 1
		 ? compareBucketOneSequence(bucket, bucketSize,
					    matchLength, minScore,
					    seqs[0])
		 : compareBucketMultipleSequences(bucket, bucketSize, 
						  matchLength, minScore,
						  seqs));
	    }
	  
	  nCanonicalPairs += msCurrent.length();
	  ms.concat(msCurrent);
	  msCurrent.truncate(); // recover some memory
	  
	  bucket += bucketSize;
	  
	  // If we've grown the vector of matches enough since the
	  // last time we removed duplicates, remove them again.
	  //
	  if (ms.length() - prevMatchThreshold > MatchCompressionThreshold)
	    {
	      checkingTime += stopTimer();
	      
#ifdef VERBOSE
	      cerr << "** Cleaning up matched pairs\n";
#endif
	      startTimer();
	      
	      ms = reduceMatches(ms);
	      prevMatchThreshold = ms.length();
	      
	      outputTime += stopTimer();
	      
#ifdef VERBOSE
	      cerr << "**  (" << prevMatchThreshold << " regions remain)\n";
#endif
	      
	      startTimer();
	    }
	}
      
      checkingTime += stopTimer();
	  
      
      // If we must checkpoint, do it now.
      //
      if (needCheckpoint)
	{
	  cerr << "*** CHECKPOINT REQUESTED AFTER "
	       << iter << " ITERATIONS\n";

#ifdef VERBOSE
	      cerr << "** Cleaning up matched pairs\n";
#endif
	  
	  startTimer();
	    
	  MatchVector ms2 = ms.copy();
	  
	  ms2 = cleanupMatches(ms2, sequences);
	  
	  outputTime += stopTimer();
	  
	  if (haltAfterCheckpoint)
	    {
	      constructionTime += tmpConstructionTime;
	      
	      cerr << "*** Will stop after checkpointing.\n";
	      cerr << "** Construction time: " << constructionTime << '\n';
	      cerr << "** Checking time:     " << checkingTime     << '\n';
	      cerr << "** Output time:       " << outputTime       << '\n';
	      cerr << "* " << nPairwiseComps  << " pairwise comparisons\n";
	      cerr << "* " << nCanonicalPairs 
		   << " canonical matched pairs found\n";
	      cerr << "* " << ms2.length() << " total regions\n"; 
	    }
	  
	  checkpoint(ms2, sequences);
	}
      
      tmpNIters++;
      if (!FixedParams)
	{
	  if (iter == 2 || iter == 6 || iter == 10)
	    {
	      computeCosts(params, 
			   tmpNIters, tmpConstructionTime, 
			   nPairwiseComps, checkingTime);
	      
	      constructionTime += tmpConstructionTime;
	      tmpConstructionTime = 0.0;
	      tmpNIters = 0;
	      
	      double cost = chooseKM(params, &nPositions, &nIterations);
	  
#ifdef VERBOSE
	  cerr << "*** Re-estimating parameters after " << iter
	       << " iterations: k = " << nPositions 
	       << ", m = " << nIterations 
	       << ", t = " << cost << '\n';
#endif
	    }
	  else if (iter == 1)
	    {
	      // First iteration's projection  is performed with a cold 
	      // cache and therefore takes longer than other iters.
	      constructionTime += tmpConstructionTime;
	      tmpConstructionTime = 0.0;
	      tmpNIters = 0;
	    }
	}
    }
  
#ifdef VERBOSE
  cerr << "** Cleaning up matched pairs...\n";
#endif
  
  startTimer();
  
  ms = cleanupMatches(ms, sequences);
  
  outputTime += stopTimer();
  constructionTime += tmpConstructionTime;
  
  cerr << "** Final parameters: k = " << nPositions 
       << ", m = " << nIterations << '\n';
  cerr << "** Construction time: " << constructionTime << '\n';
  cerr << "** Checking time:     " << checkingTime     << '\n';
  cerr << "** Output time:       " << outputTime       << '\n';
  cerr << "* " << nPairwiseComps  << " pairwise comparisons\n";
  cerr << "* " << nCanonicalPairs << " canonical matched pairs found\n";
  cerr << "* " << ms.length() << " total regions\n";
  
  delete [] records;
  return ms;
}


//
// cleanupMatches()
// Clean up a vector of Matches to remove duplications.
//
//  1. Trim any residue pairs with nonpositive score off the left and
//     right ends of each Match. (ASSUMPTION: there is at least one
//     residue pair with a positive score in there somewhere!).
// 
//  2. Remove any matches that are strictly contained in others,
//     as well as any exact duplicates.
//
static MatchVector cleanupMatches(MatchVector ms, const SeqVector seqs)
{
  const ScoreMatrix &M = SCORE->subs();
  
  // Trim nonpositive-scoring residue pairs off each Match.
  //
  for (unsigned int j = 0; j < ms.length(); j++)
    {
      const Residue *s0 = seqs[ms[j].seq(0)].data;
      const Residue *s1 = seqs[ms[j].seq(1)].data;
      
      // trim leading residues
      {
	const Residue *p0 = s0 + ms[j].low(0);
	const Residue *p1 = s1 + ms[j].low(1);
	
	SeqPosn delta;
	for (delta = 0; M[*p0][*p1] <= 0; delta++, p0++, p1++);
	
	if (delta > 0)
	  {
	    ms[j].setLength(ms[j].length() - delta);
	    ms[j].setLow(0, ms[j].low(0) + delta);
	    ms[j].setLow(1, ms[j].low(1) + delta);
	  }
      }
      
      // trim trailing residues
      {
	const Residue *p0 = s0 + ms[j].low(0) + ms[j].length() - 1;
	const Residue *p1 = s1 + ms[j].low(1) + ms[j].length() - 1;
	
	SeqPosn delta;
	for (delta = 0; M[*p0][*p1] <= 0; delta++, p0--, p1--);
	
	if (delta > 0)
	  ms[j].setLength(ms[j].length() - delta);
      }
      
    }
  
#if defined(MERGE_OVERLAPS) || defined(REMOVE_OVERLAPS)
  
  // Merging or overlap removal will take care of removing
  // any redundancies created by trimming, and is needed in
  // any case because ms may be unreduced.
  //
  return reduceMatches(ms);
  
#else
  // FIXME: I don't trust the following code just yet.
  return reduceMatches(ms);
  
  // If we are doing only strict duplicate removal, we need
  // to remove *both* duplicates and matches that, after
  // trimming, are contained within other matches.
  //
  if (ms.isEmpty())
    return ms;
  
  qsort(ms.elements(), ms.length(), sizeof(Match), cmpMatchesByFrame);
  
  Match *mPrev = &(ms[0]);
  SeqDiffT prevFrame = mPrev->frame();
  
  for (unsigned int currIdx = 1; currIdx < ms.length(); currIdx++)
    {
      const Match *mCurr = &(ms[currIdx]);
      SeqDiffT currFrame = mCurr->frame();
      
      // Don't try to remove matches from different sequences or
      // within different frames of the same pair of sequences.
      // Leave overlaps but remove any match that is contained
      // within another.
      //
      if (mCurr->seq(0) != mPrev->seq(0)  || 
	  mCurr->seq(1) != mPrev->seq(1)  || 
	  currFrame     != prevFrame      ||
	  mCurr->low(0)  > mPrev->high(0) ||
	  mCurr->high(0) < mPrev->high(0))
	{
	  *(++mPrev) = *mCurr;
	  prevFrame = currFrame;
	}
    }
  
  unsigned int oldLength = ms.length();
  ms.truncate(mPrev - &(ms[0]) + 1);
  
  // Should we try to save memory?
  if (ms.length() <= oldLength / 2)
    return ms.copy();
  else
    return ms;

#endif
}
