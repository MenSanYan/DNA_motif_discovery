//
// RANDOMPRIMES.H
// Interface for getting a "random" big prime
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// The numbers returned aren't truly random (they're listed in a big
// table), but they are definitely prime and fairly big (> a billion).
// This is good enough for the pathology avoidance code.
//

#ifndef __RANDOMPRIMES_H
#define __RANDOMPRIMES_H

#include "random.h"

extern const unsigned int randomPrimes[];
extern const unsigned int nRandomPrimes;  // a power of two

inline unsigned int getRandomPrime(void)
{ return randomPrimes[randUInt() & (nRandomPrimes - 1)]; }

#endif
