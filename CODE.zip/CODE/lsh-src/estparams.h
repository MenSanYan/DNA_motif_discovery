//
// ESTPARAMS.H
// Estimate optimal parameters k and m for LSH.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2002 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __ESTPARAMS_H
#define __ESTPARAMS_H

#include "scorefunction.h"
#include "scoredistn.h"
#include "seqinfo.h"
#include "seqops.h"

const double FALSE_NEGATIVE_BOUND = 0.05;

struct LSHParams {
  ScoreT minScore;
  SeqLength matchLength;
  double falseNegativeBound;
  
  double iterCost;
  double cmpCost;
  
  SeqPairDistn aggDistn;
  
  double problemSize;
  
  // for mismatch counting only
  double pMatch;
  
  // for score counting only
  ScoreDistn *scoreDistn;
};

double computeProblemSize(const SeqPairDistn &aggDistn, SeqLength matchLength);

void guessCosts(LSHParams &p, SeqLength nRecords);

void computeCosts(LSHParams &p, 
		  unsigned int, double, 
		  unsigned long long, double);

double chooseKM(const LSHParams &p, SeqLength *, unsigned int *);

#endif
