//
// OUTPUT.CC
// Printing and checkpoint support
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <cstdlib>

#include <csignal>

#include "output.h"

using namespace std;


bool outputForwardStrand = false;

// Print all the matches in the input vector in the form
// <seq number 1> <str1> <start1> <seq number 2> <str2> <start2> <length>
// where 
// <seq number #> is the number of the 1st/2nd sequence in the match
// <str#>         is the strand ('f' for forward, 'r' for 
//                reverse-complement) of the match in each sequence
// <start#>       is the starting index of the match
// <length>       is the match length
//
// If we chose reverse-complemented printing of the output, matches on the
// R-C strand ('r') will have their starting points specified w/r to the 
// forward strand; otherwise,  they will be specified w/r to their native 
// strand.
//
void printAllMatches(ostream &os, const MatchVector ms, 
		     const SeqVector sequences)
{
  for (unsigned int j = 0; j < ms.length(); j++)
    {
      const Match &m = ms[j];
      
      for (int k = 0; k < 2; k++)
	{
	  SeqNumber seqNum = m.seq(k);
	  const SeqInfo &seq = sequences[seqNum];
	  
	  os << seqNum + 1 << ' ';
	  
	  // Which strand are we on?
	  //
	  os << (seq.complement ? 'r' : 'f') << ' ';
	  
	  // Should we print indices w/r to forward or native strand?
	  //
	  if (outputForwardStrand && seq.complement)
	    {
	      os << seq.length - m.high(k);
	    }
	  else
	    {
	      os << m.low(k) + 1;
	    }
	  
	  os << ' ';
	}
      
      os << m.length() << '\n';
    }
}


//////////////////////////////////////////////////
// CHECKPOINT SIGNALS AND HANDLERS
//////////////////////////////////////////////////

const int SIGCHECKPOINT = SIGUSR1;
const int SIGHALT       = SIGHUP;

static void checkpointHandler(int)
{
  needCheckpoint = true;
}

static void haltHandler(int)
{
  needCheckpoint      = true;
  haltAfterCheckpoint = true;
}

///////////////////////////////////////////////////

bool needCheckpoint            = false;
bool haltAfterCheckpoint       = false;
const char *checkpointFileName = NULL;

//
// Install signal handlers for checkpointing code.
//
void installCheckpointHandlers(void)
{
  struct sigaction sa;
  
  // Make life easy -- don't make me think about failing syscalls
  // or one-shot handlers.
  //
  sa.sa_flags   = SA_RESTART;
  sigemptyset(&sa.sa_mask);
  
  sa.sa_handler = &checkpointHandler;
  if (sigaction(SIGCHECKPOINT, &sa, NULL) < 0)
    {
      cerr << "*** WARNING: could not install checkpoint handler!\n"
	   << "    Attempting to checkpoint will terminate program.\n";
    }
  
  sa.sa_handler = &haltHandler;
  if (sigaction(SIGHALT, &sa, NULL) < 0)
    {
      cerr << "*** WARNING: could not install checkpoint+halt handler!\n"
	   << "    Attempting to checkpoint will terminate program.\n";
    }
}

#include <stdio.h> // for sprintf()
#include <unistd.h> // for getpid()

//
// checkpoint()
// Write a checkpoint with the current output to a file, or to stdout
// if no file was specified on the command line.
//
void checkpoint(const MatchVector ms, const SeqVector sequences)
{
  needCheckpoint = false;
  
  if (checkpointFileName == NULL)
    {
      char *cfName = new char [256];
      sprintf(cfName, "lsh-%d.chk", getpid());
      checkpointFileName = cfName;
    }
  
  ofstream ofs(checkpointFileName, ios::out | ios::trunc);
  if (!ofs)
    cerr << "Could not open checkpoint file " 
	 << checkpointFileName << endl;
  else
    printAllMatches(ofs, ms, sequences);
  
  if (haltAfterCheckpoint)
    exit(1);
}
