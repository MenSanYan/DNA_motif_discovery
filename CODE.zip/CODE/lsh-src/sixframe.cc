//
// SIXFRAME.CC
// Quick hack to generate six-frame translation of a sequence.  Any
// codon containing an X, and any stop codon, are translated to 'X'.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>

#include "loadsequences.h"
#include "seqops.h"
#include "minmax.h"

using namespace std;


const unsigned int LINELENGTH = 60;

static void printSequence(const SeqInfo &s, int frame);


int main(int argc, char *argv[])
{
  SeqVector sequences = loadSequences(argc, argv, "", false);
  SeqVector translatedSeqs;
  
  if (sequences.length() > 0)
    {
      if (!sequences[0].alphabet->isDNA())
	{
	  cerr << "Error: input sequences must come from DNA alphabet!\n";
	  exit(1);
	}
    }
  
  Alphabet *ProteinAlphabet = 
    new Alphabet(Alphabet::PROTEIN, "acdefghiklmnpqrstvwy", "x");
  
  for (int frame = -3; frame <= 3; frame++)
    {
      if (frame == 0) continue;
      
      for (unsigned int j = 0; j < sequences.length(); j++)
	{
	  const SeqInfo &s = 
	    computeTranslation(sequences[j], frame, ProteinAlphabet);
	  printSequence(s, frame);
	}
    }
  
  return 0;
}


void handleArgument(int optchar, const char *optarg)
{
}


static void printSequence(const SeqInfo &s, int frame)
{
  cout << '>' << s.title << " [frame " << frame << "]\n";
  
  unsigned int residuesLeft = s.length;
  unsigned int seqPtr = 0;
  while (residuesLeft > 0)
    {
      unsigned int lineLength = MIN(residuesLeft, LINELENGTH);
      
      s.alphabet->printSeq(s.data + seqPtr, lineLength, cout);
      cout << '\n';
      
      residuesLeft -= lineLength;
      seqPtr += lineLength;
    }
}

