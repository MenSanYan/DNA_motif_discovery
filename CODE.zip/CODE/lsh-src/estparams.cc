//
// ESTPARAMS.CC
// Estimate optimal parameters k and m for LSH.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2002 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// Herein is a mostly automated procedure for choosing an appropriate
// projection size and number of iterations for the LSH-ALL-PAIRS algorithm.
// The basic theory is as follows:
//
//   The inputs to LSH-ALL-PAIRS are
//      - a collection of one or more sequences,
//      - a desired match length l
//      - a minimum allowed score s (or max allowed number of 
//        substitutions d)
//      - a bound T on the algorithm's expected false negative rate
//        (this last is set to the FALSE_NEGATIVE_BOUND in estparams.h
//         at compile time)
//
//   From the input sequences, we first estimate the effective problem
//   size (total number of possible l-mer pairs in the comparison).
//   For mismatch counting, we estimate the probability pMatch that any 
//   two randomly-chosen bases in the comparison will match, while
//   for general score functions, we estimate the score distribution of 
//   background l-mer pairs.
//
//   The above information is sufficient to determine, for every
//   projection size k, the smallest number of iterations m such
//   that the expected false negative rate for discovering l-mer
//   pairs with score at least s is at most T.  General scores
//   must be first mapped to the core mismatch-counting problem using
//   a simulation; see [Buhler 2001 PhD thesis, chapter 2] for the 
//   computation in the case of mismatch counting, implemented in 
//   the function minIters() below.
//
//   For any m and k, we can also determine the expected number
//   of false positives (l-mer pairs that hash together but are
//   insufficiently similar); the procedures falsePositiveRateMatches()
//   implements this computation for mismatch counting.  The
//   falsePositiveRateScore() procedure additionally performs the
//   mapping from scores to mismatch counting.
//
//   Finally, we must find the k and m that minimize the *actual*
//   cost of the algorithm.  The minimum is determined not only
//   by the number of false positives but also by the relative
//   time costs of performing each projection and each l-mer
//   comparison.  These costs must be measured empirically
//   using either rough guesses (see guessCosts()) or data from
//   the execution of the algorithm (see computeCosts()).
//   The procedure chooseKM() actually computes the values for k and m.
//

#include <cstdlib>
#include <cmath>

#include "estparams.h"

#include "global.h"
#include "distrib.h"

using namespace std;

// Enable to see the various choices considered for k and m w/running times
// #define DEBUG_KMCHOICE

const SeqLength MAX_PROJ_SIZE = 6 * sizeof(LSHValue);


/////////////////////////////////////////////////////////////////////////
// 1. PROBLEM SIZE
/////////////////////////////////////////////////////////////////////////

//
// computeProblemSize()
// Compute the effective size of an alignment problem, i.e. the number
// of pairs of substrings of length matchLength to be compared.
//
double computeProblemSize(const SeqPairDistn &aggDistn, SeqLength matchLength)
{
  if (aggDistn.partition > 0)
    {
      // Compare one set of sequences to another, disjoint set
      
      double n1 = aggDistn.length1 - aggDistn.partition * (matchLength - 1);
      double n2 = aggDistn.length2  - 
	(aggDistn.nSeqs - aggDistn.partition) * (matchLength - 1);
      
      return n1 * n2;
    }
  else
    {
      // Compare a set of sequences to itself
      
      double n = aggDistn.length1 - 
	aggDistn.nSeqs * (matchLength - 1);
      
      return 0.5 * n * (n-1);
    }
}

/////////////////////////////////////////////////////////////////////////
// 2. PROBLEM-DEPENDENT FALSE POSITIVE AND FALSE NEGATIVE RATES
/////////////////////////////////////////////////////////////////////////


// log(m choose n)
inline double lcomb(int m, int n)
{
  if (m == n)
    return 0.0;
  else
    return lfact(m) - lfact(n) - lfact(m - n);
}


//
// pSameProjection()
// Compute the probability that two sequences of length matchLength
// that differ in exactly nMismatches positions will have the same
// projection value under a projection of size projSize.
//
// (Two cases here: one if we choose positions with replacement,
//  one if we don't).
//
static double pSameProjection(SeqLength nMismatches,
                              SeqLength matchLength,
                              SeqLength projSize)
{
  if (nMismatches == 0) // needed to prevent wierd results with --fast-math
    {
      return 1.0;
    }
  else
    {
      SeqLength nMatches = matchLength - nMismatches;
      
#ifdef HASH_UNIQUE_POSITIONS
      double ltop = lcomb(nMatches, projSize);
      double lbot = lcomb(matchLength, projSize);
      
      return exp(ltop - lbot);
#else
      return pow(double(nMatches) / double(matchLength), projSize);
#endif
    }
}


//
// minIters()
// Compute the minimum number of iterations m such that the probability
// of missing a given pair of sequences of length matchLength with
// at most nMismatches substitutions in m trials with random projections
// of size projSize is at most falseNegativeBound.
//
static unsigned int minIters(SeqLength nMismatches,
                             SeqLength matchLength,
                             SeqLength projSize,
                             double falseNegativeBound)
{
  double prob = pSameProjection(nMismatches, matchLength, projSize); 
  
  if (prob == 1.0) // projections always match -> one iteration suffices
    {
      return 1;
    }
  else
    {
      double m = log(falseNegativeBound) / log(1.0 - prob);
      return (unsigned int) ceil(m);
    }
}


// probability that two random l-mers mismatch in exactly nMismatches 
// out of matchLength positions (from binomial density)
//
inline double pRandomMatch(SeqLength nMismatches,
                             SeqLength matchLength,
                             double pMatch)
{
  return Dbinom(nMismatches, matchLength, 1.0 - pMatch);
}


// comparison fcn for qsort()
static int dCmp(const void *p1, const void *p2)
{
  double d1 = *((const double *) p1);
  double d2 = *((const double *) p2);
  
  return (d1 < d2 ? -1 : (d1 > d2));
}


//
// falsePositiveRateMatches()
// Compute the expected number of comparisons required between two
// background l-mers in a run of LSH-ALL-PAIRS with given problem
// parameters and a given projection size k, assuming an l-mer
// pair is considered uninteresting if it differs by more than
// nMismatches substitutions.
//
// SETS: *nIters to be the smallest m such that the false negative
// bound specified in params is achieved with projection size k.
//
static double falsePositiveRateMatches(const LSHParams &params,
				       SeqLength projSize,
				       unsigned int *nIters)
{
  SeqLength nMismatches = params.matchLength - params.minScore;
  SeqLength minMismatches = nMismatches + 1;
  
#ifdef HASH_UNIQUE_POSITIONS
  SeqLength maxMismatches = params.matchLength - projSize;
#else
  SeqLength maxMismatches = params.matchLength - 1; 
#endif
  
  if (maxMismatches < minMismatches)
    {
      *nIters = 0;
      return 0.0;
    }

  SeqLength nterms = maxMismatches - minMismatches + 1;
  double *fpRateTerms = new double [nterms];
  
  for (SeqLength d = minMismatches; d <= maxMismatches; d++)
    {
      fpRateTerms[d - minMismatches] = 
        pRandomMatch(d, params.matchLength, params.pMatch) *
        pSameProjection(d, params.matchLength, projSize);
    }
  
  // sort the individual terms of the sum to maximize numerical precision
  qsort(fpRateTerms, nterms, sizeof(double), dCmp);
  
  double fpRate = 0.0;
  for (SeqLength j = 0; j < nterms; j++)
    fpRate += fpRateTerms[j];
  delete [] fpRateTerms;
  
  *nIters = minIters(nMismatches, 
                     params.matchLength, 
                     projSize,
                     params.falseNegativeBound); 
  
  if (*nIters < 5)
    *nIters = 5;
  
  return (*nIters * fpRate);
}


//
// falsePositiveRateScore()
// Compute the expected number of comparisons required between two
// fixed background l-mers in a run of LSH-ALL-PAIRS with given problem
// parameters and a given projection size k, assuming that an
// l-mer pair is considered uninteresting if its pairwise
// score is less than minScore.
//
// We use the following facts about the simulation SIM:
//  - A string of length l expanded by the simulation produces
//    a vector of l * dim(simulation) positions.
//
//  - Let phi be SIM's embedding of l-mer strings into Hamming
//    distance for the score function sigma, and let
//    off = min_{x,y} sigma(x,y).  Then
//
//    H(phi(s), phi(t)) = sum_{i=1}{l} (dim(SIM) - (sigma(s_i,t_i) - off))
//
// Hence, for computing k and m, we effectively have
//  l' <- l * dim(simulation)
//  d' <- l' - (minScore - l * off)
//
// SETS: *nIters to be the smallest m such that the false negative
// bound specified in params is achieved with projection size k.
//
static double falsePositiveRateScore(const LSHParams &params,
				     SeqLength projSize,
				     unsigned int *nIters)
{
  SeqLength simMatchLength = params.matchLength * SIM->dimension();
  const ScoreDistn &sd = *(params.scoreDistn);

  // set lowestScore to guarantee that simNMatches never goes to 0
  // (for non-unique hashing) or < projSize (for unique hashing)
#ifdef HASH_UNIQUE_POSITIONS
  ScoreT lowestScore = projSize + params.matchLength * SIM->offset();
#else
  ScoreT lowestScore = sd.low() + 1;
#endif
  
  if (params.minScore < lowestScore)
    {
      *nIters = 0;
      return 0.0;
    }
  
  SeqLength nterms = params.minScore - lowestScore;
  double *fpRateTerms = new double [nterms];
  
  for (ScoreT s = lowestScore; s < params.minScore; s++)
    {
      SeqLength simNMatches = s - params.matchLength * SIM->offset();
      SeqLength simNMismatches = simMatchLength - simNMatches;
      
      fpRateTerms[s - lowestScore] = 
	sd[s] * pSameProjection(simNMismatches, simMatchLength, projSize);
    }
  
  // sort the individual terms of the sum to maximize numerical precision
  qsort(fpRateTerms, nterms, sizeof(double), dCmp);
  
  double fpRate = 0.0;
  for (SeqLength j = 0; j < nterms; j++)
    fpRate += fpRateTerms[j];
  
  delete [] fpRateTerms;
  
  SeqLength simNMismatches = simMatchLength - 
    params.minScore + params.matchLength * SIM->offset();
  
  *nIters = minIters(simNMismatches,
		     simMatchLength,
		     projSize,
		     params.falseNegativeBound); 

  if (*nIters < 5)
    *nIters = 5;
  
  return (*nIters * fpRate);
}


/////////////////////////////////////////////////////////////////////////
// 3. ESTIMATES OF COMPUTATIONAL COST
/////////////////////////////////////////////////////////////////////////

//
// guessCosts()
// Estimate the cost of each LSH iteration and each l-mer comparison, 
// so that we may pick initial values of k and m.
// 
// These guesses are based on very rough estimates of the
// cost of sorting the projections of each l-mer in the input
// and of doing an l-mer comparison.  They're probably wrong
// for your machine, but they're order-of-magnitude correct.
// 
// FIXME: Ideally, we should do some minimal measurements to
// come up with better initial estimates here.
//
// INPUTS: parameter structure to fill in, estimated # of
// records to be sorted in each iteration.
//
void guessCosts(LSHParams &params, SeqLength nRecords)
{
  const double ITER_COST_PER_RECORD = 1.26e-6;
  const double CMP_COST             = 1.4e-6;
  
  params.iterCost = nRecords * log(double(nRecords)) * ITER_COST_PER_RECORD;
  params.cmpCost  = CMP_COST;
}


//
// computeCosts()
// Estimate the cost of each LSH iteration and each l-mer comparison
// from timings of the LSH-ALL-PAIRS algorithm.
//
// FIXME: the iteration cost is pretty stable and fairly accurate
// so long as we discard the time of the first (cold-cache) iteration,
// but the comparison cost estimate is lousy.  The problem is that
// the cost is not strictly proportional to the number of comparisons:
// there is a substantial constant overhead that must be factored out.
// We should estimate this overhead given timings from a few iterations
// of the algorithm using linear regression.
//
void computeCosts(LSHParams &params,
		  unsigned int nIterations, double totalIterationTime,
		  unsigned long long nComparisons, double totalComparisonTime)
{
  params.iterCost = totalIterationTime / nIterations;
  params.cmpCost  = totalComparisonTime / nComparisons;
}


/////////////////////////////////////////////////////////////////////////
// 4. OPTIMAL PARAMETER SELECTION
/////////////////////////////////////////////////////////////////////////


//
// chooseKM()
// Given all problem parameters, find the optimal projection size
// and number of iterations for the algorithm.
//
// RETURNS: estimated cost (in seconds) for optimal parameterization
// SETS: *projSize and *nIters to the optimal parameters
//
double chooseKM(const LSHParams &params,
		SeqLength *projSize,
		unsigned int *inIters)
{
  double bestCost = 1e+100 / 10.0;
  SeqLength bestProjSize = 0;
  unsigned int bestIters = 0;
  
  for (SeqLength k = 1; k <= MAX_PROJ_SIZE; k++)
    {
      unsigned int nIters;
      
      double fpRate = 
	(SIM == NULL
	 ? falsePositiveRateMatches(params, k, &nIters)
	 : falsePositiveRateScore(params, k, &nIters));
      
      double cost = 
	params.iterCost * nIters + 
	params.cmpCost * fpRate * params.problemSize;

#ifdef DEBUG_KMCHOICE
      cerr << k << ' ' << nIters << ' ' << fpRate << ' ' 
	   << params.iterCost * nIters << ' '
	   << params.cmpCost * fpRate * params.problemSize << ' '
	   << cost << endl; 
#endif
 
      if (cost < bestCost)
	{
	  bestCost = cost;
	  bestProjSize = k;
	  bestIters = nIters;
	}
      else if (cost > 10.0 * bestCost)
      	break;
    }
  
  *projSize = bestProjSize;
  *inIters   = bestIters;
  
  return bestCost;
}
