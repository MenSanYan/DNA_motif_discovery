//
// COMPRESS.H
// Procedures to compress a list of records to remove unusable buckets
// and shrink very large buckets.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __COMPRESS_H
#define __COMPRESS_H

#include "record.h"
#include "seqinfo.h"

SeqLength
compressBucketsOneSequence(Record *records, SeqLength nRecords);

SeqLength
compressBucketsMultipleSequences(Record *records, SeqLength nRecords);

SeqLength
compressBucketsPartitioned(Record *records, SeqLength nRecords,
			   SeqNumber firstSeqAfterPartition);

#endif
