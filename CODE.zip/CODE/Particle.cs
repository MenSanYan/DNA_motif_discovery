using System;
using System.Collections.Generic;
namespace SeqAlign
{
	/// <summary>
	/// Summary description for Particle.
	/// </summary>
	public class Particle
	{
		private int[] myMotif;
        
		private double[] myVel;
		private int [] mySeqLength;
		private int[] myBestMotif;
		private double myBestScore;
		private int dim;
		private Random rand;
        private List<string>[] l1;
        public int[] canpos;
        private int i;
		public Particle()
		{
		}
		public Particle( List<string>[] list,int [] Position, double [] Velocity, int [] SequenceLength,int[] canpos1,int i1)
		{
            i = i1;
			dim = Position.Length;
            l1 = new List<string>[dim];
            l1 = list;
			myVel = new double[dim];
			myMotif = new int[dim];
			mySeqLength = new int[dim];
			myBestMotif = new int[dim];
            canpos = new int[dim];
			Velocity.CopyTo( myVel, 0);
            canpos1.CopyTo(myMotif, 0);
            canpos1.CopyTo(myBestMotif, 0);
            canpos1.CopyTo(canpos,0);
			SequenceLength.CopyTo( mySeqLength, 0);
			myBestScore = double.MinValue/2;
			rand = new Random();	// don't forget to change seed -------------------
		}

		public void updatePersonalBest( double fitness )
		{
			if (fitness > myBestScore)
			{
				myBestScore = fitness;
                myBestMotif.CopyTo(canpos, 0);
			}
		}
		public Particle Copy()
		{
			Particle aCopy =new Particle(l1,myMotif, myVel, mySeqLength,canpos,i);
			aCopy.myBestMotif = myBestMotif;
			aCopy.myBestScore = myBestScore;
			aCopy.dim = dim;
            
			return aCopy;
		}

		public void Fly( Swarm sw ,int times)
		{
			double iFactor, sFactor, pDelta, gDelta, delta;
			int nextPos;
            string s1 = "";
			for ( int d = 0; d < dim ; d++ )
			{
				iFactor = sw.iWt * rand.NextDouble() * (sw.IMax-sw.IMin) + sw.IMin;
				sFactor = sw.SWt * rand.NextDouble() * (sw.SMax-sw.SMin) + sw.SMin;
				pDelta = this.myBestMotif[d] - this.canpos[d];
				gDelta = sw.gBest.canpos[d] - this.canpos[d];
				delta = (iFactor * pDelta) + (sFactor * gDelta);
                delta = ((double)myVel[d]) + 1 * delta/times;
				// constrict movement

                if (delta > (l1[d].Count - 1) / 3) delta = (l1[d].Count - 1) / 3;
                if (delta < -((l1[d].Count - 1) / 3)) delta = -((l1[d].Count - 1) / 3);
				this.myVel[d] = delta;
                this.canpos[d] = this.canpos[d] + (int)delta;
                if (this.canpos[d] < 0) this.canpos[d] = 0;
                //int rightmostPos = this.mySeqLength[d] - sw.MotifLength - 1;
                if (this.canpos[d] > l1[d].Count - 1) this.canpos[d] = l1[d].Count - 1;
               s1 = l1[d][this.canpos[d]];
				nextPos = int.Parse(s1);
				// verify that position is feasible

              //  this.myMotif[d] = this.canpos[d];
			}
		}


		public int[] Motif
		{
			get 
			{
				return myMotif;
			}
		}

	

	}
}
