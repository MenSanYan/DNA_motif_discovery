using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
namespace SeqAlign
{
	public class Swarm
	{
		private Database myDB;
		private int qtyParticles;
		//private int maxIterations;
		private double deltaMin, deltaMax;
		private double iWeight, iMin, iMax;
		private double sWeight, sMin, sMax;
		private int dim;
		private int minSeqLength, maxSeqLength,numofcan;
		private double globalBestScore;
		private Particle globalBestParticle;
		private string[] mySeqs;
		private int myMotifLength;
		private Random rand;
		private Particle[] p;
        private Particle better;
		private int[] ResidueCount;
		private char [,] CharArray;
		private double [,] myFreqTable;
		private char [] myAlphabet;
		public string outputString;
        private List<string>[] l1;
        int times = 1;
        Particle p1;
		public Swarm()
		{
		}

		public Swarm(Database db,string projection ,int ParticleQty, int motifLength, double SocialFactor, double IndivFactor)
		{
			myDB = db;
			iWeight = IndivFactor;
			sWeight = SocialFactor;
			dim = myDB.SeqCount;
			myMotifLength = motifLength;
			mySeqs = new string[dim];
			qtyParticles = ParticleQty;
			minSeqLength = Int32.MaxValue/2;
			maxSeqLength = 0;
			for ( int i = 0; i < dim; i++)
			{
				mySeqs[i] = myDB.Sequences[i];
				if (mySeqs[i].Length < minSeqLength) minSeqLength = mySeqs[i].Length;
				if (mySeqs[i].Length > maxSeqLength) maxSeqLength = mySeqs[i].Length;
			}
			rand = new Random(); // don't forget to change seed -------------------------------
			myAlphabet = db.Alphabet;
            string[] projection1 = projection.Split(Environment.NewLine.ToCharArray());
            numofcan = projection1.Length - 1;
            l1 = new List<string>[dim];
            for (int i = 0; i < dim; i++) {
                l1[i] = new List<string>();
            }


                for (int i = 0; i < projection1.Length; i++)
                {
                    string[] projection2 = projection1[i].Split('\t');
                    //  List<string> list = new List<string>(projection2);
                    if (projection2.Length >=2)
                    {
                        for (int j = 0; j < dim; j++)
                        {
                            if (projection2[j].Length>=1)
                            l1[j].Add(projection2[j]);
                        }
                    }
                }

                // initialize particles and global best
                initializeControlVariables();
			initializeParticles(l1);
			initializeGlobalBest(p[0]);
			CharArray = initializeCharArray();
			ResidueCount = countCharacters();
			for (int i = 0; i < qtyParticles; i++)
			{
				double f = fitness(p[i]);
				p[i].updatePersonalBest(f);
				if ( f > this.globalBestScore )
				{
					this.globalBestScore = f;
					this.globalBestParticle = p[i].Copy();
				}
			}
			// run PSO ------------------------------------------
            FileStream fs = new FileStream("F:\\result\\m_ak.txt", FileMode.Create);


			int improveCycles = 0;
			int stopCycles = 1000;
            double d1 = 0;
			while (improveCycles < stopCycles)
			{
				for ( int i = 0 ; i < qtyParticles ; i++ )
				{
					p[i].Fly(this,times);
					double f = fitness(p[i]);
                    double best1 = f;
                    for (int d = 0; d < dim; d++)
                    {
                        for (int k = -100; k < 100; k++)
                        {
                             p1 = p[i].Copy();
                            if (p1.canpos[d] + k > l1[d].Count-1)
                                p1.canpos[d] = l1[d].Count - 2;
                            else if (p1.canpos[d] + k < 0)
                                p1.canpos[d] = 0;
                            else
                            {
                                p1.canpos[d] = p[i].canpos[d] + k;
                            }
                            double k1=fitness(p1);
                            if (best1 < k1) {
                                best1 = k1;
                                p[i] = p1.Copy();
                                
                            }
                        }
                    }
                    for (int k = -100; k < 100; k++)
                    {
                         p1 = p[i].Copy();
                    for (int d = 0; d < dim; d++)
                    {
                        
                            
                            if (p1.canpos[d] + k > l1[d].Count - 1)
                                p1.canpos[d] = (p1.canpos[d] + k)%(l1[d].Count - 2);
                            else if (p1.canpos[d] + k < 0)
                                p1.canpos[d] = p1.canpos[d] + k + l1[d].Count - 2-myMotifLength;
                            else
                            {
                                p1.canpos[d] = p[i].canpos[d] + k;
                            }
                           
                        }
                    double k1 = fitness(p1);

                    if (k1 > this.globalBestScore) {
                        k1 = fitness(p1);
                        better = p1.Copy();
                      //  for (int ij = 0; ij < dim; ij++)
                       // {
                         //   byte[] data = System.Text.Encoding.Default.GetBytes(p1.canpos[ij] + "  ");
                         //   fs.Write(data, 0, data.Length);
                            
                     //   }
                       // byte[] data1 = System.Text.Encoding.Default.GetBytes("\r\n ");
                        //fs.Write(data1, 0, data1.Length);
                    }
                    
                    if (best1 < k1)
                    {
                        best1 = k1;
                        p[i] = p1.Copy();
                        
                    }
                    }


                    f = best1;
                        p[i].updatePersonalBest(f);
                    if (f > this.globalBestScore)
                    {
                        d1 = f;
                        this.globalBestScore = f;
                        this.globalBestParticle = p[i].Copy();
                       // improveCycles = 0;		//reset cycle counter
                    }
                   
                  
				}
                if (d1 == this.globalBestScore)
                    times++;
                if (times == 100)
                {
                    initializeParticles(l1);
                    times = 1;
                }
				improveCycles++;
			}
			outputString = formatOutput(this.globalBestParticle);
            fs.Flush();
            fs.Close();
		}

		private string formatOutput(Particle p)
		{
			// print sequences
			string output = "SEQUENCES:\n";
			for (int r = 0; r < dim; r++)
			{
				for ( int c = 0; c < this.maxSeqLength; c++)
				{
					if (CharArray[r,c] == '\0') CharArray[r,c] = ' ';
					output += Char.ToString(CharArray[r,c]);
				}
				output += "\n";
			}
			output += "\n";
			// print motif starting positions
			output += "Motif = {";
			for ( int r = 0; r < dim; r++)
			{
				output += " " + better.canpos[r].ToString();
			}
			output += " }\n\n";
			// format sequence alignments
			int maxPos = 0;
			for (int d = 0; d < dim ; d++)
			{
				if (p.Motif[d] > maxPos) maxPos = p.Motif[d];
			}
			char[,] outArray = new char[dim, this.maxSeqLength + maxPos];
			for (int r = 0; r < dim; r++)
			{
				int rowOffset = maxPos - p.Motif[r];
				for (int c = 0; c < this.maxSeqLength ; c++)
				{
					outArray[r,c+rowOffset] = Char.ToLower(this.CharArray[r,c]);
				}
				for (int c = maxPos; c < maxPos + this.MotifLength; c++)
				{
					outArray[r,c] = Char.ToUpper(outArray[r,c]);
				}
			}
			// print alignment
			for ( int r = 0; r < dim; r++)
			{
				for ( int c = 0; c < this.maxSeqLength+maxPos; c++)
				{
					if (outArray[r,c] == '\0') outArray[r,c] = ' ';
					output += outArray[r,c].ToString();
				}
				output += "\n";
			}
			// print score
			output += this.globalBestScore.ToString("\n\nBest Score = ######.##\n\n");
			return output;
          
		}

		double fitness (Particle p) //need to complete the fitness function
		{
			myFreqTable = freqTable( p );
			double score = 0.0;
			score = Score(p);			
			return score;
		}

		double Score (Particle p)
		{
			double oddsRatio, logRatio;
			double sumLogRatio = 0;
            string s1 = "";
			for (int d = 0 ; d < dim ; d++)
			{
				double motif = 1.0;
				double backg = 1.0;
				for (int pos = 0 ; pos < myMotifLength ; pos++)
                {
                    s1 = l1[d][p.canpos[d]];
                    int location = pos + int.Parse(s1);
                    if (location > 8350)
                    {  //Խ�����
                        location=8350;
                    }
					for (int c = 0; c < myAlphabet.Length; c++)
					{
						if ( CharArray [d,location] == myAlphabet[c] )
						{
							char dummy = myAlphabet[c];
							motif *= myFreqTable[c,pos+1];
							backg *= myFreqTable[c,0];
							break;
						}
					}
				}
				oddsRatio = motif/backg;
				logRatio = Math.Log(oddsRatio,2.0);
				sumLogRatio += logRatio;
			}
			return sumLogRatio;
		}

		double [,] freqTable (Particle p) //ok
		{
			double [,] f = new double [ResidueCount.Length+1, myMotifLength+1];
			for (int a = 0; a < myAlphabet.Length; a++)
			{
				f[a,0] = ResidueCount[a];
			}

            string s1 = "";

			for (int d = 0; d < dim; d++)
			{
				for (int i = 0; i < myMotifLength; i++)
                {
                    s1 = l1[d][p.canpos[d]];
					int pos = i + int.Parse(s1);
                    if (pos > 8350) {  //Խ�����
                        pos=8350;
                    }
					for (int a = 0; a < myAlphabet.Length; a++)
					{
						if ( CharArray[d,pos] == myAlphabet[a] )
						{
							f[a, i+1]++;	// increment freq count table
							f[a, 0]--;		// decrement background
							break;
						}
					}
				}
				
			}
			for (int a = 0; a < myAlphabet.Length; a++)
			{
				for (int pos = 0; pos <= myMotifLength; pos++)
				{
					f[a,pos]++;			// add pseudo counts
					f[myAlphabet.Length, pos] += f[a,pos];	// sum columns
				}
			}
			for (int a = 0; a <= myAlphabet.Length; a++)
			{
				for (int pos = 0; pos <= myMotifLength; pos++)
				{
					f[a,pos] = (double)f[a,pos] / (double)f[myAlphabet.Length, pos];	// convert count to frequency
				}
			}
			return f;
		}

		private int[] countCharacters() //ok
		{
			char[] alphabet = new char[myDB.Alphabet.Length];
			myDB.Alphabet.CopyTo(alphabet,0);
			int [] count = new int[alphabet.Length];
			for (int d = 0; d < dim; d++)
			{
				for (int s = 0 ; s < maxSeqLength; s++ )
				{
					for (int a = 0; a < alphabet.Length; a++)
					{
						if ( CharArray[d,s] == alphabet[a] )
						{
							count[a] ++;
							break;
						}
					}
				}
			}
			return count;
		}

		private char[,] initializeCharArray() //ok
		{
			char[,] cArray = new char[dim,maxSeqLength];
			char[] temp;
			for (int d = 0; d < dim; d++)
			{
				temp = mySeqs[d].ToCharArray();
				for (int s = 0; s < temp.Length; s++)
				{
					cArray[d,s] = temp[s];
				}
			}
			return cArray;
		}

		private void initializeControlVariables() //ok
		{
			//maxIterations = 1000;
			iMin = 0.0;
			iMax = 1.0;
			sMin = 0.0;
			sMax = 1.0;
            deltaMax = numofcan / 100;
			deltaMin = -deltaMax;
		}

		private void initializeParticles(List<string>[] l1) //ok
		{
			int [] len = new int[dim];
			int [] pos = new int[dim];
            int[] can = new int[dim];
			double [] vel = new double[dim];
			p = new Particle[qtyParticles];
          
            
            

			for (int i = 0; i < qtyParticles; i++)
            {
                
				for (int d = 0; d < dim; d++)
				{
                    int canpos = rand.Next(0, l1[d].Count - 1);
                    //canpos = 1;
                    string s1 = l1[d][canpos];
					len[d] = myDB.Sequences[d].Length;
                    pos[d] = rand.Next(0, l1[d].Count - 1);
                    can[d] = canpos;
                    //System.Console.WriteLine(s1[d]);
                    deltaMax = (l1[d].Count - 1) / 3;
                    deltaMin = -deltaMax;
					vel[d] = rand.NextDouble() * (deltaMax-deltaMin) + deltaMin;
				}
             
				p[i] = new Particle(l1,pos,vel,len,can,i);
			}
           


		}

		private void initializeGlobalBest(Particle p)
		{
			this.globalBestParticle = p.Copy();
			this.globalBestScore = Double.MinValue/2;
		}

		public double IWt
		{
			get
			{
				return this.iWeight;
			}
		}
		public double IMin
		{
			get
			{
				return this.iMin;
			}
		}
		public double IMax
		{
			get
			{
				return this.iMax;
			}
		}
		public double SWt
		{
			get
			{
				return this.sWeight;
			}
		}
		public double SMin
		{
			get
			{
				return this.sMin;
			}
		}
		public double SMax
		{
			get
			{
				return this.sMax;
			}
		}
		public double iWt
		{
			get
			{
				return this.iWeight;
			}
		}
		public double DeltaMin
		{
			get
			{
				return this.deltaMin;
			}
		}
		
		public double DeltaMax
		{
			get
			{
				return this.deltaMax;
			}
		}
		public Particle gBest
		{
			get
			{
				return this.globalBestParticle;
			}
		}
		public int MotifLength
		{
			get
			{
				return this.myMotifLength;
			}
		}
	}
}
