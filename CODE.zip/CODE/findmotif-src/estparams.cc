//
// ESTPARAMS.CC
// Estimate good parameters for the PROJECTION motif finding algorithm.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.

#include <iostream>
#include <cstdlib>
#include <cmath>

#include "estparams.h"

#include "distrib.h"
#include "minmax.h"

using namespace std;


// Enable to see the various choices considered for k/m/s w/running times
// #define DEBUG_KMSCHOICE
  
// These costs (in seconds) reflect the running times of
// projection (per record) and checking (per candidate motif per 
// record) on a 1 GHz PIII.  No doubt these times are wrong for other
// architectures, but their relative magnitude gives a rough
// guide to how to trade off between k and m.
//
const double ITER_COST_PER_RECORD      =  7.0e-7;
const double CHECKING_COST_PER_RECORD  = 1.41e-6;

// Don't consider projections bigger than this.
//
const SeqLength MAX_PROJ_SIZE = 4 * sizeof(LSHValue);


// log(m choose n)
inline double lcomb(int m, int n)
{
  if (m == n)
    return 0.0;
  else
    return lfact(m) - lfact(n) - lfact(m - n);
}


//
// pSameProjection()
// Compute the probability that two sequences of length matchLength
// that differ in exactly nMismatches positions will have the same
// projection value under a projection of size projSize.
//
static double pSameProjection(SeqLength nMismatches,
                              SeqLength matchLength,
                              SeqLength projSize)
{
  if (nMismatches == 0) // needed to prevent wierd results with --fast-math
    {
      return 1.0;
    }
  else
    {
      SeqLength nMatches = matchLength - nMismatches;
      
      double ltop = lcomb(nMatches, projSize);
      double lbot = lcomb(matchLength, projSize);
      
      return exp(ltop - lbot);
    }
}


//
// minIters()
// Compute the minimum number of iterations m such that with probability
// at least 1 - falseNegativeBound, at least threshold motif instances
// hash together in at least one iteration.
//
static unsigned int minIters(const FinderParams &params,
			     SeqLength projSize,
                             unsigned int threshold)
{
  double prob = Pbinom(threshold - 1, params.nMotifInstances,
		       pSameProjection(params.nErrors, 
				       params.motifLength, 
				       projSize));
  
  if (prob == 0.0) // failure probability is 0 -> one iteration suffices
    return 1;
  else
    {
      double m = log(params.falseNegativeBound) / log(prob);
      
      return (unsigned int) ceil(m);
    }
}


//
// chooseKMS()
// Given natural parameters of the motif finding problem (params),
// Choose appropriate values for projection size k, number of iterations
// m, and bucket size threshold s.
//
// The optional parameter ignoreSignalLevel controls how aggressively
// chooseKMS() tries to set the threshold s to ignore buckets with
// more noise than signal. If 0, s must be at least twice the expected
// number of background l-mers per bucket; if 1, it must be equal to
// this expected number.  Setting ignoreSignalLevel = 2 disables
// any signal/noise considerations in setting s.
//
// (Note: if there are no feasible k/m/s combinations with a given value
// of ignoreSignalLevel, chooseKMS() will automatically retry with a less
// aggressive value.)
//
// RETURNS: estimated running time in seconds (for my machine, not yours).
//
double chooseKMS(const FinderParams &params,
		 SeqLength *iprojSize,
		 unsigned int *inIters,
		 unsigned int *ithreshold,
		 int ignoreSignalLevel)
{
  double bestCost            = 1e+100 / 10.0;
  SeqLength bestProjSize     = 0;
  unsigned int bestNIters    = 0;
  unsigned int bestThreshold = 0;
  
  for (SeqLength k = 3;
       k <= MIN(MAX_PROJ_SIZE, params.motifLength - params.nErrors); 
       k++)
    {
      double pow4k = pow(4.0, int(k));
      unsigned int threshold;
      
      unsigned int signalLevel;
      
      if (ignoreSignalLevel > 1) // COMPLETELY ignore s/n considerations
	{
	  signalLevel = 1;
	}
      else if (ignoreSignalLevel > 0) // allow very noisy signals
	{
	  signalLevel = 
	    (unsigned int) (ceil( params.totalInstances / pow4k));
	}
      else                             // default: require little noise
	{
	  signalLevel = 
	    (unsigned int) (ceil(2.0 * params.totalInstances / pow4k));
	}
      
      
      if (*ithreshold) // user specified a threshold
	threshold = MAX(*ithreshold, signalLevel);
      else
	threshold = MAX((params.nSeqs < 10 
			 ? MIN(params.nMotifInstances, 3U) 
			 : 4U),
			signalLevel);
      
      if (threshold > params.nMotifInstances)
	continue;
      
      
      unsigned int nIters = minIters(params, k, threshold);
      
      double nRefinements = nIters * pow4k *
	(1.0 - Pbinom(threshold - 1, params.totalInstances, 1.0/pow4k));
      
      double cost = params.totalInstances *
	(ITER_COST_PER_RECORD * nIters + 
	 CHECKING_COST_PER_RECORD * nRefinements);
      
#ifdef DEBUG_KMSCHOICE
      cerr << k << ' ' << threshold << ' ' << nIters << ' ' 
	   << nRefinements << ' ' << cost << endl;
#endif
      
      if (cost < bestCost)
	{
	  bestCost = cost;
	  bestProjSize = k;
	  bestNIters = nIters;
	  bestThreshold = threshold;
	}
      else if (cost > 10.0 * bestCost)
	break;
    }
  
  if (bestThreshold == 0) // uh-oh -- couldn't find small enough threshold
    {
      // Ack! Give up (user probably specified a bogus threshold value).
      if (ignoreSignalLevel == 2)
	{
	  cerr << "Error (chooseKMS): specified threshold = "
	       << *ithreshold << " is too large\n";
	  exit(1);
	}
      else
	return chooseKMS(params, iprojSize, inIters, ithreshold,
			 ignoreSignalLevel + 1);
    }
  else
    {
      *iprojSize  = bestProjSize;
      *inIters    = MAX(bestNIters, 10U); // paranoia -- allow law of
      *ithreshold = bestThreshold;        // large numbers to kick in
      
      return bestCost;
    }
}
