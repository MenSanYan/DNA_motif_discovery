//
// REFINE.H
// Motif refinement and scoring code
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __REFINE_H
#define __REFINE_H

#include "motif.h"

extern long NRefinements;  // global refinement counter

MotifVector refineMotifs(MotifVector, const SeqVector);

#endif
