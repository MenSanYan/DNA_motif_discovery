//
// EM.CC
// Perform EM motif refinement.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// We try to find the maximum likelihood motif model (given the data)
// in the neighborhood of an initial guess.  We use a simple
// 1-instance-per-seq model (the "oops" model of MEME).  It's not
// clear that running EM all the way to convergence is worth the cost
// of doing so; hence, we stop after a small fixed number of
// iterations.  This still gives us very good results on synthetic
// data and is not known to fail on real data.
// 

#include <cmath>

#include "global.h"
#include "em.h"

using namespace std;


// On Solaris, there is no exponentiation function specialized to
// single-precision floating-point.  the GNU and DEC math libraries 
// *do* have such a function, which is faster than normal exp().
//
#ifdef SOLARIS_MATH
#define expf exp
#endif

// Run EM for at most this many iterations.
// 
const int EM_MAXITERS = 300;


// a static array of arrays holding motif probabilities at each
// position of the input sequences
//
static float **ys = NULL;


//
// EstepOneSeq()
// Perform the E-step of EM on a single input sequence.  We compute
// the expected number of occurrences of the motif model given by
// the weight matrix "wmm" at each position j in the sequence.  This
// is simply the probability that the instance starting at position j
// is a true motif instance, normalized so that the motif must occur
// *somewhere* in the sequence with probability 1. 
//
// For efficiency, we zero out the probabilities associated with
// very low-probability instances rather than computing them (which
// would require an exponentiation).  This should have a minimal
// effect on the normalization constant.
//
// One other small hack: in principle, we should recompute the background
// residue distribution for each potential motif instance, exlcuding the
// residues in the motif.  In practice, motifs are short compared to
// background sequences, so we use the residue distribution of
// the entire input as an almost-correct, fixed background distribution.
// This usage is internal to the WMM class, but it's worth pointing out 
// the departure from the usual probability model here.
//
// INPUTS: * sequence to inspect
//         * current motif model (a weight matrix)
//         * a probability vector y[] (to be filled in)
// SETS:
//         * y[j] <- Pr[motif occurs at position j | sequence, model]
//                 = E[# of occurrences at position j | ", "]
//
static void EstepOneSeq(const SeqInfo &sequence, WMM &wmm, float *y)
{
  SeqLength nInstances = sequence.length - wmm.length() + 1;
  const Residue *s = sequence.data;
  double totalScore = 0.0;
  
  // Compute the log of the (unnormalized) probability for each seq position.
  // Remember the largest such score.
  //
  double maxLogScore = -1e+9;
  for (SeqPosn j = 0; j < nInstances; j++)
    {
      double logScore = wmm.scoreInstance(s + j);
      y[j] = logScore;
      
      if (maxLogScore < logScore)
	maxLogScore = logScore;
    }
  
  // We choose the threshold for ignoring low-probability instances
  // so that all the ignored instances *together* have probability
  // mass at most 1% that of the most probable instance (and therefore
  // at most 1% of the entire distribution).
  //
  double threshold = maxLogScore - log(100.0 * nInstances);
  
  // Compute properly normalized probabilities for each position j.
  //
  for (SeqPosn j = 0; j < nInstances; j++)
    {
      if (y[j] > threshold)
	{
	  double score = expf(y[j]);
	  totalScore  += score;
	  y[j] = score;
	}
      else
	y[j] = 0.0;
    }
  
  double iTotalScore = 1.0 / totalScore;
  
  for (SeqPosn j = 0; j < nInstances; j++)
    y[j] *= iTotalScore;
}


//
// MstepOneSeq()
// Perform the M-step of EM using data from a single input sequence.
// We call this procedure once for each input sequence.
//
// The probability that residue r occurs in position i of the motif model
// is proportional to the expected number of instances in the input
// with residue r in position i.  Essentially, we build a WMM out of every
// instance in the input, weighted according to how well it scored
// under the model from the previous iteration.
//
// INPUT: * sequence which was scored
//        * probabilities for each position in the sequence
//        * partially-computed weight matrix (will be updated
//          with info from this sequence)
//
static void MstepOneSeq(const SeqInfo &sequence, const float *y, WMM &wmm)
{
  const Residue *s = sequence.data;
  
  for (SeqPosn j = 0; j <= sequence.length - wmm.length(); j++)
    if (y[j] != 0.0)
      wmm.addInstance(s + j, y[j]);
}


//
// isConverged()
// Let P be the old WMM model, and let Q be the new WMM.  We declare
// convergence iff, for every coefficient (i,j),
//                   | P_ij - Q_ij | / P_ij < epsilon
// Note that the P_ij's and Q_ij's are probabilities which are never zero
// (because of the Laplace correction).
//
// Unfortunately, our WMM's contain log(P_ij/P0_i), not raw probabilities.
// However, it can be shown that the convergence criterion holds for (i,j)
// iff both the following conditions hold:
//    1. log(Q_ij) - log(P_ij) > log(1 - epsilon)
//    2. log(Q_ij) - log(P_ij) < log(1 + epsilon)
// This fact holds even if we divide each P_ij and Q_ij by a common P0_i.
//
static bool isConverged(WMM &oldWMM, WMM &newWMM)
{
  // const double EM_EPSILON  = 1.0e-3;
  const double LOG1_P_EPS  = +9.995003330834232e-4;  // log(1 + EM_EPSILON)
  const double LOG1_M_EPS  = -0.001000500333580e+0;  // log(1 - EM_EPSILON)
  
  for (SeqPosn j = 0; j < oldWMM.length(); j++)
    {
      const float *oldCol = oldWMM[j];
      const float *newCol = newWMM[j];
      
      for (unsigned int k = 1; k <= oldWMM.alphabet()->nRealResidues(); k++)
	{
	  double diff = newCol[k] - oldCol[k];
	  
	  if (diff <= LOG1_M_EPS | diff >= LOG1_P_EPS)
	    return false;
	}
    }
  
  return true;
}


//
// refineEM()
// Peform EM refinement on an initial weight matrix model given a
// collection of sequences.  After convergence or a fixed maximum
// number of EM iterations, return the final WMM.
//
// ASSUMPTION: the sequence vector remains fixed across multiple calls
// to EM, so we can allocate the array of arrays that hold the probabilities
// y[j] for each sequence only once.  Also, we never delete these arrays.
//
WMM refineEM(const SeqVector sequences, const double *bgDist, WMM &initialWMM)
{
  WMM currWMM = initialWMM;
  bool stop = false;
  
  if (ys == NULL) // haven't yet allocated the y vectors
    {
      ys = new float * [sequences.length()];
      
      for (SeqNumber i = 0; i < sequences.length(); i++)
	ys[i] = new float [sequences[i].length - currWMM.length() + 1];
    }
  
  // Run EM to convergence, or for at most EM_MAXITERS iterations.
  //
  for (int iter = 0; !stop && iter < EM_MAXITERS; iter++)
    {
      for (SeqNumber i = 0; i < sequences.length(); i++)
	EstepOneSeq(sequences[i], currWMM, ys[i]);
      
      WMM newWMM(currWMM.length(), currWMM.alphabet(), 1.0, bgDist);
      
      for (SeqNumber i = 0; i < sequences.length(); i++)
	MstepOneSeq(sequences[i], ys[i], newWMM);
      
      newWMM.force_seal();
            
      if (isConverged(currWMM, newWMM))   // further EM won't help
	stop = true;
      
      currWMM = newWMM;
    }
  
  return currWMM;
}
