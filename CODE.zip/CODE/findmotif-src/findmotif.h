//
// FINDMOTIF.H
// Find motif by LSH based on sorting
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __FINDMOTIF_H
#define __FINDMOTIF_H

#include "seqinfo.h"
#include "motif.h"

Motif findMotif(const SeqVector, const Residue *consensus = NULL);

#endif
