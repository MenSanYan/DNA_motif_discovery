//
// WMM.CC
// A weight matrix model for motifs
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <cstring>
#include <cmath>

#include "wmm.h"

using namespace std;


//
// WMM::initStructures()
// Allocate the space for a WMM's probability matrix and background 
// distribution, and initialize variables for accessing these
// structures. initStructures() also checks whether any existing
// structures are present and reallocates them if their size has
// changed.
//
// ASSUMPTIONS: if structures have not yet been allocated, the
// variables _alphabet, _bgDist, and cells must all be NULL.
//
void WMM::initStructures(SeqLength length, const Alphabet *alphabet)
{
  if (alphabet == NULL)
    {
      if (_bgDist != NULL) delete [] _bgDist;
      _bgDist = NULL;
      
      logLen = 0;
      
      if (cells != NULL) delete [] cells;
      cells = NULL;
      _length = 0;
      
      nRealResidues = 0;
    }
  else
    {
      unsigned int nResidues = alphabet->nResidues();
      
      if (_alphabet == NULL || nResidues != _alphabet->nResidues())
	{
	  if (_bgDist != NULL) delete [] _bgDist;
	  _bgDist = new double [nResidues];
	}
      
      if (length != _length || 
	  _alphabet == NULL ||
	  nResidues != _alphabet->nResidues())
	{
	  if (cells != NULL) delete [] cells;
	  
	  logLen = computeLogLen(nResidues);
	  
	  if (length > 0)
	    cells = new float [length << logLen];
	  else
	    cells = NULL;
	  
	  _length = length;
	}
      
      nRealResidues = alphabet->nRealResidues();
    }
  
  _alphabet = alphabet;
}


//
// WMM::init()
// Initialize a WMM to a specified size. To provide a Laplace correction,
// the specified prior weight (a number of instances, possibly fractional) 
// is distributed across each column of the WMM according to the background
// distribution (by default, uniformly).
//
void WMM::init(SeqLength length, const Alphabet *alphabet,
	       double priorWeight, const double *bgDist)
{
  initStructures(length, alphabet);
  
  if (_bgDist != NULL)
    {
      if (bgDist == NULL) // initialize with equal base freqs
	{
	  double bgfreq = 1.0 / double(nRealResidues);
	  
	  _bgDist[Alphabet::RESIDUE_X] = 0.0;
	  
	  for (Residue j = 1; j <= nRealResidues; j++)
	    _bgDist[j] = bgfreq;
	}
      else if (bgDist != _bgDist) // handle reinit from own bgDist
	{
	  memcpy(_bgDist, bgDist, _alphabet->nResidues() * sizeof(double));
	}
      
      // Distribute the prior weight among the residues of each column,
      // following the background distribution. (Note: this loop is
      // a no-op if length == 0).
      for (SeqPosn j = 0; j < _length; j++)
	{
	  (*this)[j][Alphabet::RESIDUE_X] = 0.0;
	  for (Residue k = 1; k <= nRealResidues; k++)
	    (*this)[j][k] = _bgDist[k] * priorWeight;
	}
    }
  
  _weight = priorWeight;
  _sealed = false;
}


//
// WMM::copy()
// Replace the contents of this WMM with a copy of another WMM.
//
void WMM::copy(const WMM &other)
{
  if (&other == this) // self-copy -- ignore
    return;
  
  initStructures(other._length, other._alphabet);
  
  if (_bgDist != NULL)
    memcpy(_bgDist, other._bgDist, _alphabet->nResidues() * sizeof(double));
  
  if (cells != NULL)
    memcpy(cells, other.cells, (_length << logLen) * sizeof(float));
  
  _weight = other._weight;
  _sealed = other._sealed;
}


////////////////////////////////////////////////////////////////////////////
// SEALING/UNSEALING
////////////////////////////////////////////////////////////////////////////


//
// WMM::seal()
// Seal a WMM by converting its counts to LLR values vs the background
// distribution.  A sealed WMM cannot have sequences added to it, but
// it can be used to score other sequences and compute information content.
//
// Note that we treat X residues as uninformative: they do not count when
// computing the residue distribution in each position.
//
void WMM::seal(void)
{
  for (SeqPosn j = 0; j < _length; j++)
    {
      double iweight = 1.0 / (_weight - (*this)[j][Alphabet::RESIDUE_X]);
      
      for (Residue k = 1; k <= nRealResidues; k++)
	{
	  double p = (*this)[j][k] * iweight;
	  (*this)[j][k] = log(p / _bgDist[k]);
	}
      
      (*this)[j][Alphabet::RESIDUE_X] = 0.0;
    }
  
  _sealed = true;
}


//
// WMM::unseal()
// Unseal a WMM by converting its LLR values back to raw counts.
// An unsealed WMM can have sequences added to it but cannot be
// used to score other sequences or to compute information content.
//
void WMM::unseal(void)
{
  for (SeqPosn j = 0; j < _length; j++)
    {
      for (Residue k = 1; k <= nRealResidues; k++)
	{
	  double p = exp((*this)[j][k]) * _bgDist[k];
	  (*this)[j][k] = p * _weight;
	}
    }
  
  _sealed = false;
}


//////////////////////////////////////////////////////////////////////////
// UNSEALED OPERATIONS
//////////////////////////////////////////////////////////////////////////


//
// WMM::computeConsensus()
// Compute the consensus sequence of a WMM and store it into the
// residue string provided.  The jth column of the consensus contains
// the most probable residue in column j; if multiple most-probable
// residues are equiprobable, we pick the first one.
//
// NOTE: for future, we might want to break ties between residues at
// random and provide a way to record that a consensus residue doesn't
// hold a majority in its column.
//
void WMM::computeConsensus(Residue *output)
{
  force_unseal();
  
  for (SeqPosn j = 0; j < _length; j++)
    {
      double maxWeight = (*this)[j][1];
      Residue maxResidue = 1;
      
      for (Residue k = 2; k <= nRealResidues; k++)
	{
	  if ((*this)[j][k] > maxWeight)
	    {
	      maxWeight = (*this)[j][k];
	      maxResidue = k;
	    }
	}
      
      output[j] = maxResidue;
    }
}


////////////////////////////////////////////////////////////////////////////
// SEALED OPERATIONS
////////////////////////////////////////////////////////////////////////////


//
// WMM::scoreInstance(')
// Return the LLR score of an instance using only SPECIFIED positions. 
//
double WMM::scoreInstance(const Residue *instance, 
			  const SeqPosn *posns, SeqLength nPosns)
{
  force_seal();
  
  double score = 0.0;
  
  for (SeqPosn j = 0; j < nPosns; j++)
    {
      SeqPosn p = posns[j];
      
      score += (*this)[p][instance[p]];
    }
  
  return score;
}


//
// WMM::infoContent()
// The information content of a column is defined to be
//     Sum p_i log(p_i / p_0)
// which is the average log likelihood ratio score of a
// residue from that column compared to the background distribution.
//
// The info content of a WMM is the sum of its column infos.
//
double WMM::infoContent(void)
{
  force_seal();
  
  double info = 0.0;
  
  for (SeqPosn j = 0; j < _length; j++)
    {
      for (Residue k = 1; k <= nRealResidues; k++)
	{
	  double p = exp((*this)[j][k]) * _bgDist[k];
	  info += p * (*this)[j][k];
	}
    }
  
  return info;
}


//
// WMM::infoContent(const SeqPosn *, SeqLength)
// Compute the information content as above for a specified
// *subset* of motif positions.
//
double WMM::infoContent(const SeqPosn *posns, SeqLength nPosns)
{
  force_seal();
  
  double info = 0.0;
  
  for (SeqPosn j = 0; j < nPosns; j++)
    for (Residue k = 1; k <= nRealResidues; k++)
      {
	double p = exp((*this)[posns[j]][k]) * _bgDist[k];
	info += p * (*this)[posns[j]][k];
      }
  
  return info;
}

/////////////////////////////////////////////////////////////////////

//
// Printing a WMM prints its consensus string but does not
// change its sealed/unsealed status.
//
ostream &operator<<(ostream &os, const WMM &wmm)
{
  WMM wmm2 = wmm;
  wmm2.force_unseal();
  
  Residue *consensus = new Residue [wmm2.length()];
  wmm2.computeConsensus(consensus);

#if 0
  // Only print the consensus residue if it is in the majority;
  // otherwise, print an 'x'.
  double mweight = 0.5 * wmm2.weight();
  
  for (SeqPosn j = 0; j < wmm2.length(); j++)
    {

      bool majority = false;
      
      for (Residue k = 1; k <= wmm2.alphabet()->nRealResidues(); k++)
	{
	  if (wmm2[j][k] > mweight)
	    {
	      majority = true;
	      break;
	    }
	}
      
      if (majority)
	wmm2.alphabet()->print(consensus[j], os);
      else
	os << 'x';
    }
#else
  wmm2.alphabet()->printSeq(consensus, wmm2.length(), os);
#endif

  delete [] consensus;
  
  return os;
}
