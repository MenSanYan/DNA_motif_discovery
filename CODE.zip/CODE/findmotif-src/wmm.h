//
// WMM.H
// A weight matrix model for motifs
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// A weight matrix model describes a sequence motif composed of N
// positions.  In each position, the distribution of residues is given
// by a multinomial distribution over the sequence alphabet.  The
// residues are chosen independently in each position.  The model also
// includes a "background" distribution over residues not in the
// motif, which is supplied by the user at the time the WMM is created
// and is subsequently used as the null model when computing
// likelihood ratios.  If no background is specified, a uniform
// distribution is assumed.
//
// This implementation of the WMM supports the following operations:
//
//   * TRAINING: residue frequencies can be inferred empirically from
//     a (weighted) set of motif instances.  Each instance is added
//     to the model using the addInstance() method.  To avoid
//     zero residue frequencies, a WMM is created with a prior
//     weight (ie a Laplace correction), which by default is
//     equivalent to a single instance.
//
//   * INFERENCE: compute the log likelihood ratio (LLR) of an instance
//     under the WMM vs the background distribution, via scoreInstance()
//
//   * INSPECTION: return any of the following info:
//       + the WMM's information content vs the background model (in nats)
//       + its individual residue frequencies 
//       + the total weight of its instances
//       + its consensus sequence (the most frequent residue in each posn)
//
// The individual weights may be accessed with operator[]; wmm[j][k]
// references the kth residue of column j (according to the numeric
// equivalences defined in shared-src/alphabet.cc).  For efficiency,
// the weights can be stored in either of two modes:
//
//   UNSEALED MODE - posn i of column j contains the total weight
//     of all added instances (plus any prior weight) that contain
//     residue i in posn j.  This mode is used when training the model
//     or computing the consensus sequence.
//
//   SEALED MODE - posn i of column j contains the log ratio of probabilities
//     that an instance contains residue i in posn j, under the WMM vs the
//     background model.  This mode is used for info content and LLR
//     computations.
//
// You can switch between modes when using operator[] by calling the 
// force_seal() and force_unseal() functions.  Other operations
// on the WMM automatically switch it into the appropriate mode.
//

#ifndef __WMM_H
#define __WMM_H

#include <iostream>

#include "seqinfo.h"

class WMM {
public:
  void force_seal(void)   { if (!_sealed) seal(); }
  void force_unseal(void) { if (_sealed) unseal(); }
  
public:
  WMM(void)
    : cells(0), _length(0), _bgDist(0), _alphabet(0) {}
   
  // Constructor with no initial motif instances
  WMM(SeqLength length, const Alphabet *alphabet,
      double priorWeight = 1.0, const double *bgDist = 0)
    : cells(0), _length(0), _bgDist(0), _alphabet(0)
  { init(length, alphabet, priorWeight, bgDist); }
  
  // Copy constructor
  WMM(const WMM &other)
    : cells(0), _length(0), _bgDist(0), _alphabet(0)
  { copy(other); }
  
  WMM &operator=(const WMM &other)
  { copy(other); return *this; }
  
  // for initialization after the constructor is called
  void init(SeqLength, const Alphabet *, double, const double *);
  
  ~WMM(void) 
  { 
    if (_bgDist != 0) delete [] _bgDist;
    if (cells != 0) delete [] cells; 
  }
  
  //
  // Data inspectors
  //
  
  SeqLength     length(void) const { return _length; }
  double        weight(void) const { return _weight; }
  bool          sealed(void) const { return _sealed; }
  const double *bgDist(void) const { return _bgDist; }
  const Alphabet *alphabet(void) const { return _alphabet; }
  
  // return the cell vector for the jth column
  float *operator[](SeqPosn j) const { return &(cells[j << logLen]); }
  
  //
  // Sealed operations
  //

  //
  // WMM::scoreInstance()
  // Return the LLR score of an instance vs the WMM.
  // Inlined for speed -- this routine accounts for most
  // of the cost of execution.
  //
  double scoreInstance(const Residue *instance)
  {
    force_seal();
    
    double score = 0.0;
    
    for (SeqPosn j = 0; j < _length; j++)
      score += (*this)[j][instance[j]];
    
    return score;
  }
  
  double infoContent(void);
  
  
  // These operations are like the above two but are only
  // computed w/r to a subset of the WMM's positions.
  double scoreInstance(const Residue *instance,
		       const SeqPosn *posns, SeqLength nPosns);
  
  double infoContent(const SeqPosn *posns, SeqLength nPosns);
  
  
  //
  // Unsealed operations
  //
  
  //
  // WMM::addInstance()
  // Add a single instance to the WMM, adjusting the counts and total weight
  // appropriately.
  //
  void addInstance(const Residue *instance, double weight = 1.0)
  {
    force_unseal();
    
    for (SeqPosn j = 0; j < _length; j++)
      (*this)[j][instance[j]] += weight;
        
    _weight += weight;
  }
  
  void computeConsensus(Residue *output);  
  
private:
  float *cells;               // _length * 2^logLen matrix of counts or 
                              // LLR values
  
  SeqLength _length;          // length of motif
  
  unsigned int logLen;        // log(least power of 2 >= alphabet's nResidues)
  
  unsigned int nRealResidues; // # of non-X residues in alphabet (cached)
  
  double _weight;             // total weight of instances in WMM
  
  bool _sealed;               // seal status (true -> cells contains LLR's,
                              //   false -> cells contain weighted counts)
  
  double *_bgDist;            // background residue distribution
  const Alphabet *_alphabet;  // sequence alphabet for motif
  
  void initStructures(SeqLength, const Alphabet *);
  void copy(const WMM &);
  
  //
  // Sealing operations
  //
  
  void seal(void);
  void unseal(void);
  
  // compute log of next power of 2 >= vIn.
  unsigned int computeLogLen(unsigned int vIn)
  {
    unsigned int vLog = (unsigned int) -1;
    for (unsigned int v = vIn; v != 0; v >>= 1, vLog++);
    return ((1U << vLog) == vIn ? vLog : vLog + 1);
  }
};


//
// print the WMM (shows the consensus string) 
//
std::ostream &operator<<(std::ostream &os, const WMM &);

#endif
