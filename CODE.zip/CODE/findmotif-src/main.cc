//
// MAIN.CC
// Main program for PROJECTION motif finder
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2002 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>
#include <cmath>

#include "global.h"
#include "version.h"
#include "loadsequences.h"
#include "random.h"

#include "findmotif.h"
#include "refine.h"

using namespace std;


const double NATS_2_BITS = 1.442695;  // ==  1 / ln(2)

const SeqLength DefaultMotifLength     = 15;
const SeqLength DefaultNErrors         = 4;
const SeqLength DefaultNMotifInstances = 0;

//
// Global vars holding input parameters (declared in global.h)
//
SeqLength MotifLength     = DefaultMotifLength;
SeqLength NErrors         = DefaultNErrors;
SeqLength NMotifInstances = DefaultNMotifInstances;
SeqLength    FixedNPositions    = 0;
unsigned int FixedNIterations   = 0;
unsigned int FixedMinBucketSize = 0;

const Alphabet *InputAlphabet;
double *BgDist, *LogBgDist;
SeqLength TotalNInstances;

#ifdef SYNTHETIC
const SeqPosn *TruePosns;
#endif


//
// File-scope variables
//
static long randSeed            = -1;
static unsigned int nMotifs     =  1;
static bool         permute     = false;


//
// local prototypes
//
static void printUsage(void);
static void computeBgDist(const SeqVector);
static void eraseMotif(const Motif &, SeqVector);
static void permuteSeq(Residue *, SeqLength, int);
static Motif trimMotif(Motif &, unsigned int);

#ifdef SYNTHETIC
static Motif computeTrueMotif(const SeqVector);
static double perfC(const Motif &, const Motif &);
#endif


int main(int argc, char *argv[])
{
  SeqVector sequences = loadSequences(argc, argv, "l:d:M:S:N:k:m:t:h", false);
  
  if (sequences.length() < 1)
    {
      cerr << "Error: need at least one sequence of length at least "
	   << MotifLength << '\n';
      printUsage();
      exit(1);
    }
  
  cout << "*** PARAMS: l = " << MotifLength 
       << ", d = "           << NErrors;
  
  if (NMotifInstances)
    cout << ", M = "         << NMotifInstances;
  
  cout << ", N = "           << nMotifs
       << " ***\n\n";
  
  if (NMotifInstances > sequences.length())
    {
      cerr << "Warning: only returning one motif instance per sequence\n";
      NMotifInstances = 0;
    }

  if (permute)
    cout << "*** PERMUTATION TEST ***\n";
  
  InputAlphabet = sequences[0].alphabet;
  
  computeBgDist(sequences);
  
  ////////////////////////////////////////////////////////////////////
  
  seedPRNG(randSeed);

  for (unsigned int trial = 0; trial < nMotifs; trial++)
    {
      if (permute)
	{
	  for (SeqNumber i = 0; i < sequences.length(); i++)
	    permuteSeq(sequences[i].data, sequences[i].length, 2);
	}
      
#ifdef SYNTHETIC
      Motif trueMotif = computeTrueMotif(sequences);
      cerr << "[planted motif is ";
      InputAlphabet->printSeq(trueMotif.consensus(), 
			      trueMotif.length(), cerr);
      cerr << "]\n";
#endif
      
      Motif motif = findMotif(sequences, 
#ifdef SYNTHETIC
			      trueMotif.consensus()
#else
			      NULL
#endif
			      );
      
      if (NMotifInstances && NMotifInstances < sequences.length())
	motif = trimMotif(motif, NMotifInstances);
      
#ifdef SYNTHETIC  
      {
	cout << "True motif:\n";
	cout << trueMotif;
	
	cout << '\n' << "CONSENSUS: ";
	InputAlphabet->printSeq(trueMotif.consensus(), 
				trueMotif.length(), cout);
	cout << ' ' << trueMotif.nClose(NErrors) << '\n';
      }
      
      cout << "***\n";
#endif
      
      // Print the sequences in the motif
      //
      if (motif.nInstances() == 0)
	{
	  cout << "NO MOTIF FOUND\n";
	  break;
	}
      else
	{
	  if (nMotifs > 1)
	    cout << "** PASS # " << trial + 1 << '\n';
	  
	  cout << motif;
	  
	  cout << '\n' << "CONSENSUS: ";
	  InputAlphabet->printSeq(motif.consensus(), 
				  motif.length(), cout);
	  cout << '\n';
	  cout << "Info: " 
	       << motif.wmm().infoContent() * NATS_2_BITS << " bits"
	       << '\n';
	}
      
#ifdef SYNTHETIC
      cout << "***\n";
      cout << "Performance: " << perfC(motif, trueMotif) << '\n';
#endif
      
      if (trial < nMotifs - 1)
	{
	  cout << '\n' << '\n';
	  if (!permute)
	    eraseMotif(motif, sequences);
	}
    }
  
  return 0;
}


//
// handleArgument()
// Pass-through argument handler for options not captured by
// loadSequences().
//
void handleArgument(int optchar, const char *optarg)
  {
  switch (optchar)
    {
    case 1:   // a file argument? WTF?
      cerr << "File argument " << optarg << " not understood\n";
      exit(1);
      
    case 'l': // motif length
      {
	MotifLength = SeqLength( strtoul(optarg, NULL, 10) );
	if (MotifLength == 0)
	  {
	    cerr << "Error: motif length must be > 0\n";
	    exit(1);
	  }
      }
      break;
      
    case 'd': // number of allowed errors
      NErrors = SeqLength( strtoul(optarg, NULL, 10) );
      break;
      
    case 'M': // number of motif instances in input
      NMotifInstances = SeqLength( strtoul(optarg, NULL, 10) );
      break;
      
    case 'm': // number of iterations
      FixedNIterations = (unsigned int) strtoul(optarg, NULL, 10); 
      break;
      
    case 'k': // number of hash posns/iteration
      {
	FixedNPositions = SeqLength( strtoul(optarg, NULL, 10) );
	if (FixedNPositions == 0)
	  {
	    cerr << "Error: number of hash posns must be > 0\n";
	    exit(1);
	  }
      }
      break;
      
    case 't': // size threshold for bucket selection
      FixedMinBucketSize = SeqLength( strtoul(optarg, NULL, 10) );
      break;
      
    case 'N':
      nMotifs = strtoul(optarg, NULL, 10);
      break;
      
    case 'S': // random seed
      randSeed = (unsigned int) strtoul(optarg, NULL, 10);
      break;
      
    case 'P':
      permute = true;
      break;
      
    case 'h': // usage or unknown
    default:
      printUsage();
      exit(1);
    }
}


//
// printUsage()
// Print a brief description of the input arguments.
//
static void printUsage(void)
{
  printVersion();
  
  cerr << "Syntax: findmotif [sequence options] [-l #] [-d #] [-M #] [-S #]\n"
       << "                  [-N #] [-k #] [-m #] [-t #]\n";
  cerr << '\n';
  
  cerr << "   -l #          -- length of motif (default " 
       << DefaultMotifLength << ")\n";
  cerr << "   -d #          -- max # of errors per instance (default "
       << DefaultNErrors << ")\n";
  cerr << "   -M #          -- number of motif instances in input\n";
  cerr << "   -S #          -- seed value for PRNG (default from sys time)\n";
  cerr << "   -N #          -- number of distinct motifs to return\n"
       << "                    (default 1)\n";
  cerr << "   -k #          -- number of LSH positions\n";
  cerr << "   -m #          -- number of LSH iterations\n";
  cerr << "   -t #          -- minimum bucket size for refinement\n";
  
  cerr << '\n';
  
  printSequenceUsage();
}


//
// computeBgDist()
// Compute the background residue distribution for the input
// sequences.  Sets the following globals:
//
// BgDist          - the distribution
// LogBgDist       - log of each probability in the distribution
// TotalNInstances - the total # of MotifLength-mers in the input 
//
// We use a Laplace correction equal to the # of residues to
// prevent getting any zero probabilities.
//
static void computeBgDist(const SeqVector sequences)
{
  unsigned int nRealResidues = InputAlphabet->nRealResidues();
  SeqLength totalLength = nRealResidues;
  
  BgDist = new double [nRealResidues + 1];
  for (Residue r = 1; r <= nRealResidues; r++)
    BgDist[r] = 1.0;
  
  TotalNInstances = 0;
  
  for (SeqNumber j = 0; j < sequences.length(); j++)
    {
      const double *freqs      = sequences[j].freqs;
      SeqLength unmaskedLength = sequences[j].unmaskedLength;
      
      for (Residue r = 1; r <= nRealResidues; r++)
	BgDist[r] += freqs[r] * unmaskedLength;
      
      totalLength += unmaskedLength;
      
      TotalNInstances += unmaskedLength - MotifLength + 1;
    }
  
  LogBgDist = new double [nRealResidues + 1];
  
  for (Residue j = 1; j <= nRealResidues; j++)
    {
      BgDist[j] /= double(totalLength);
      LogBgDist[j] = log(BgDist[j]);
    }
  
  BgDist[Alphabet::RESIDUE_X]    = 0.0;
  LogBgDist[Alphabet::RESIDUE_X] = 0.0;
  
  //
  // The rest is just printing FYI.
  //
  
  cerr << "BgDist:";
  for (Residue j = 1; j <= nRealResidues; j++)
    {
      cerr << ' ' << BgDist[j];
    }
  cerr << '\n';
  cerr << "Bg Length = " << totalLength << '\n';
}


//
// eraseMotif()
// Remove the residues corresponding to a Motif from the input sequences,
// converting them to RESIDUE_X's.
//
static void eraseMotif(const Motif &motif, SeqVector sequences)
{
  for (unsigned int j = 0; j < motif.nInstances(); j++)
    {
      const MotifInstance &instance = motif.instances()[j];
      Residue *seq = sequences[instance.seqNum].data + instance.position;
      
      for (SeqPosn k = 0; k < motif.length(); k++)
	seq[k] = Alphabet::RESIDUE_X;
    }
}

///////////////////////////////////////////////////////////////////
// PERMUTATION CODE FOR SEQUENCES 

static int eltCmp(const void *p1, const void *p2)
{
  long e1 = **((const long **) p1);
  long e2 = **((const long **) p2);
  
  if (e1 < e2)
    return -1;
  else
    return (e1 > e2);
}

static void genPermutation(long *elts, int nElts)
{
  long **ranks = new long * [nElts];
  
  for (int j = 0; j < nElts; j++)
    {
      elts[j] = randInt();
      ranks[j] = &(elts[j]);
    }
  
  qsort(ranks, nElts, sizeof(long *), eltCmp);
  
  for (int j = 0; j < nElts; j++)
    *(ranks[j]) = j;
  
  delete [] ranks;
}

static void permuteSeq(Residue *seq, SeqLength length, int blockSize)
{
  SeqLength nBlocks = length / blockSize;
  
  long *perm = new long [nBlocks];
  genPermutation(perm, nBlocks);
  
  Residue *newseq = new Residue [length];
  
  for (SeqPosn block = 0; block < nBlocks; block++)
    {
      memcpy(&newseq[block * blockSize], 
	     &seq[perm[block] * blockSize], 
	     blockSize * sizeof(Residue));
    }
  
  memcpy(seq, newseq, nBlocks * blockSize * sizeof(Residue));
}

#ifdef SYNTHETIC

///////////////////////////////////////////////////////////////////
// CHECKING CODE WHEN THE MOTIF IS KNOWN IN ADVANCE 
// (IE FOR SYNTHETIC DATASETS)

#include <stdio.h> // for sscanf()

//
// computeTrueMotif()
// Read the true motif from a specification in the FASTA titles of the
// input sequences.  Each input sequence has a title of the form 
// "> Seq <num> <posn>", where <num> is the number of the input sequence
// and <posn> is the position where the motif begins in that sequence.
// Both values are assumed to be 1-based.
//
// We use this information to construct and return the true motif.  Also,
// we set the global variable TruePosns to the list of starting positions
// of the true motif in each input sequence.
//
static Motif computeTrueMotif(const SeqVector sequences)
{
  Motif trueMotif(MotifLength, InputAlphabet, BgDist);
  SeqPosn *truePosns = new SeqPosn [sequences.length()];
  
  for (SeqNumber j = 0; j < sequences.length(); j++)
    {
      SeqNumber num;
      SeqPosn posn;

      if (sscanf(sequences[j].title, " Seq %u %u", &num, &posn) == 2)
	{
	  Residue *instance = sequences[num - 1].data + posn - 1;
	  trueMotif.addInstance(num - 1, posn - 1, instance);
	  truePosns[j] = posn - 1;
	}
    }
  
  trueMotif.setScore(trueMotif.nClose(NErrors));
  
  TruePosns = truePosns;
  return trueMotif;
}


//
// perfC()
// Compute the program's performance coefficient in finding a known
// planted motif.  Let S be the set of all input residues
// included in any instance of the program's motif, and let T be the
// corresponding set of residues covered by the true motif.  Then
// the program's performance coefficient is |S ^ T| / |S U T|.
//
// The performance coefficient is defined in [Pevzner and Sze, ISMB 2000].
//
static double perfC(const Motif &motif, const Motif &trueMotif)
{
  SeqLength intersection = 0, _union = 0;
  
  for (unsigned int j = 0; j < motif.nInstances(); j++)
    {
      const MotifInstance &i = motif.instances()[j];
      
      if (i.seqNum >= trueMotif.nInstances())
	{
	  _union += motif.length();
	  continue;
	}
      
      const MotifInstance &ti = trueMotif.instances()[i.seqNum];
      
      if (i.position <= ti.position)
        {
          intersection += 
            MAX(0, 
                int(i.position)  + int(motif.length()) - int(ti.position));
          _union       += 
            MIN(2 * int(motif.length()), 
                int(ti.position) + int(motif.length()) - int(i.position));
        }
      else
        {
          intersection += 
            MAX(0, 
                int(ti.position) + int(motif.length()) - int(i.position));
          _union       +=
            MIN(2 * int(motif.length()), 
                int(i.position)  + int(motif.length()) - int(ti.position));
        }
    }
  
  // If we miss any instances entirely, account for their positions here
  if (motif.nInstances() < trueMotif.nInstances())
    _union += (trueMotif.nInstances() - motif.nInstances()) * motif.length();
  
  return double(intersection) / double(_union);
}

#endif // SYNTHETIC


////////////////////////////////////////////////////////////////////////
// Motif Trimming
// Given a motif with M instances that we want to turn into a motif with
// N < M instances, extract the N instances that score highest versus
// the model and create a new motif from them.
//

struct MotifScore {
  unsigned int inum;
  double score;
};

// sort in descending order by score
static int scoreCmp(const void *a, const void *b)
{
  const MotifScore *ma = (const MotifScore *) a;
  const MotifScore *mb = (const MotifScore *) b;
  
  if (ma->score > mb->score)
    return -1;
  else return (ma->score != mb->score);
}

// sort in ascending order by instance number
static int posnCmp(const void *a, const void *b)
{
  const MotifScore *ma = (const MotifScore *) a;
  const MotifScore *mb = (const MotifScore *) b;
  
  if (ma->inum < mb->inum)
    return -1;
  else return (ma->inum != mb->inum);
}


//
// trimMotif()
// Reduce the input motif m to one with only outputInstances instances.
//
static Motif trimMotif(Motif &m, unsigned int outputInstances)
{
  MotifScore *scores = new MotifScore [m.nInstances()];
  
  for (unsigned int j = 0; j < m.nInstances(); j++)
    {
      const MotifInstance &ins = m.instances()[j];
      
      scores[j].inum   = j;
      scores[j].score  = m.wmm().scoreInstance(ins.data);
    }
  
  // sort so that highest scores go first
  qsort(scores, m.nInstances(), sizeof(MotifInstance), scoreCmp);
  
  // among highest scores, re-sort into original motif order
  qsort(scores, outputInstances, sizeof(MotifInstance), posnCmp);
  
  //
  // Now create the new motif
  //
  Motif newMotif(m.length(), InputAlphabet, BgDist);
  
  for (unsigned int j = 0; j < outputInstances; j++)
    newMotif.addInstance(m.instances()[scores[j].inum]);
  
  newMotif.setScore(newMotif.computeLLRScore());
  
  delete [] scores;
  return newMotif;
}
