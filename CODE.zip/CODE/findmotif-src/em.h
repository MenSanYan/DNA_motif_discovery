//
// EM.H
// Perform EM motif refinement.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __EM_H
#define __EM_H

#include "seqinfo.h"
#include "wmm.h"

WMM refineEM(const SeqVector sequences, const double *bgDist, WMM &initialWMM);

#endif
