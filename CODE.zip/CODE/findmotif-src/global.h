//
// GLOBAL.H
// Input parameters shared across the entire program
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __GLOBAL_H
#define __GLOBAL_H

#include "datatypes.h"
#include "alphabet.h"

extern SeqLength MotifLength;         // length of motif to find
extern SeqLength NErrors;             // max # of diffs allowed from consensus
extern const Alphabet *InputAlphabet; // common alphabet of all input seqs

extern double *BgDist, *LogBgDist;    // background residue distn
extern SeqLength TotalNInstances;     // # of MotifLength-mers in input
extern SeqLength NMotifInstances;     // # of motif instances in input

// Fixed parameter values specified by user (0 if unset).
extern SeqLength FixedNPositions;     // # of hash positions (k)
extern SeqLength FixedNIterations;    // # of iterations (m)
extern SeqLength FixedMinBucketSize;  // bucket size threshold (s)

#ifdef SYNTHETIC
extern const SeqPosn *TruePosns;      // locations of true motif instances
#endif

#endif
