//
// MOTIF.H
// Implementation of a WMM-based sequence motif
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// The Motif describes a set of explicit instances.  Adding instances
// to the motif both records where they occur in the input and adds
// them to an internally maintained WMM, available via the wmm() method.
//
// For convenience, the Motif supports the following additional items:
//  * OPERATIONS:
//     + compute the aggregate log likelihood ratio of all instances
//       in the motif under its WMM vs the background distribution
//       via computeLLRScore()
//     + count the number of instances within a specified number of
//       substitutions of the motif's consensus sequence via nClose()
//
//  * EXTRA FIELDS:
//     + consensus() -- the motif's consensus, cached for efficiency
//     + score() and tag() -- two fields - one double, one integer - that
//       may be set arbitrarily by the user.  By default, both are zero.
//
// printing a Motif prints some summary statistics for it,
// followed by a list of its instances.
//

#ifndef __MOTIF_H
#define __MOTIF_H

#include <iostream>

#include "seqinfo.h"
#include "vector.h"
#include "wmm.h"


// Descriptor for a single instance of a motif.  Store a pointer
// to the instance locally so that we don't have to pass around
// the Sequences vector.
//
struct MotifInstance {
  const Residue *data;     // pointer to instance string
  SeqNumber seqNum;        // seq # of instance
  SeqPosn   position;      // starting posn of instance
  
  MotifInstance(void) {}
  
  MotifInstance(const Residue *idata, SeqNumber iseqNum, SeqPosn iposition)
    : data(idata), seqNum(iseqNum), position(iposition) {}
};


class Motif {
public:
  Motif(void) 
    : _length(0), _consensus(NULL) {}
  
  Motif(SeqPosn length, const Alphabet *alphabet, const double *bgDist = NULL)
    : _length(length), _wmm(length, alphabet, 1.0, bgDist),
      _consensus(NULL), _score(0.0), _tag(0)
  {}
  
  Motif(const WMM &wmm)
    : _length(wmm.length()), _wmm(wmm),
      _consensus(NULL), _score(0.0), _tag(0)
  {}
  
  Motif(const Motif &other)
    : _length(0), _consensus(NULL)
  { copy(other); }
  
  Motif &operator=(const Motif &other) 
  { copy(other); return *this; }
  
  virtual ~Motif(void) 
  { 
    if (_consensus) delete [] _consensus; 
  }
  
  void init(SeqLength length, const Alphabet *alphabet, 
	    const double *bgDist = NULL);
  
  //////////////////////////////////////////////////////////////
  // Data Inspectors
  
  SeqLength length(void) const { return _length; }
  
  unsigned int nInstances(void) const { return _instances.length(); }
  
  const Vector<MotifInstance> &instances(void) const { return _instances; }
  
  WMM &wmm(void) { return _wmm; }
  
  const Residue *consensus(void)
  {
    if (!_consensus)
      _consensus = computeConsensus();
    
    return _consensus;
  }
  
  double score(void) const { return _score; }
  int      tag(void) const { return _tag; }
  
  //////////////////////////////////////////////////////////////
  // Data mutators
  
  void addInstance(SeqNumber seqNum, SeqPosn posn, const Residue *residues);
  
  void addInstance(const MotifInstance &instance)
  { addInstance(instance.seqNum, instance.position, instance.data); }
  
  void setScore(double v) { _score = v; }
  void   setTag(int tag)  { _tag = tag; }
  
  //////////////////////////////////////////////////////////////
  // Derived computations
  
  double computeLLRScore(void);
  double computeLLRScore(const SeqPosn *posns, SeqPosn nPosns);
  
  unsigned int nClose(SeqLength bound);
  
public:
  
  SeqLength _length;                // length of motif
  WMM _wmm;                         // WMM describing motif
  Vector<MotifInstance> _instances; // instances of motif
  
  
  Residue *_consensus;  // cached consensus sequence
  double   _score;      // score of motif (set by user, default 0.0)
  int      _tag;        // tag for motif (set by user, default 0)
  
  void init(SeqLength length);
  void copy(const Motif &other);
  
  Residue *computeConsensus(void);
};


typedef Vector<Motif> MotifVector;

//
// Display function
//
std::ostream &operator<<(std::ostream &os, Motif &);

#endif
