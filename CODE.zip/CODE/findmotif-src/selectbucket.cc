//
// SELECTBUCKET.CC
// Given a list of records sorted into buckets, return a list of motifs
// created from only those buckets which are significantly unlike the
// background sequence.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// Motifs which pass this stage are used as starting points for
// iterative refinement.  It is expected that, if we project enough
// times, any real motifs will be found.
//

#include <cmath>

#include "global.h"
#include "selectbucket.h"

#include "motif.h"
#include "minmax.h"
#include "distrib.h"

using namespace std;


//
// local prototypes
//
#ifdef SYNTHETIC
static void annotateTrueMotifs(Motif *, 
			       const SimpleLSHFunction &, 
			       const Residue *);
#endif

///////////////////////////////////////////////////////////////////////
// BUCKET SIZE THRESHOLD DETERMINATION
//
// We set a minimum size threshold independently for each bucket.
// The goal is to pick a threshold t small enough that we're likely
// to see t examples of the motif at least once during the run, but
// large enough to avoid testing many potential motifs of size t 
// composed entirely of background instances.
//
// A bucket's threshold is the maximum of two values: a threshold
// chosen by the user (or automated parameter picker) and an estimate
// related to the expected size of the bucket.  In particular, we assume that
// the number of background instances in a bucket is approximately
// Poisson with mean equal to the bucket's expected size.  The threshold
// is then set to the 90th %ile of this distribution.
//
// Unlike the user's threshold, the Poisson-based calculation is actually
// sensitive to the distribution of the input, so we use it to ignore
// really huge buc meaningless buckets when the background distribution is 
// huge.
//


// Compute a Possion quantile by binary search.
//
static unsigned int qPoisBSearch(double p, double mean)
{
  unsigned int qHigh = 1;
  
  while (Ppoisson(qHigh, mean) < p) qHigh *= 2;
  
  unsigned int qLow = qHigh / 2;
  
  // binary search to find the smallest quantile >= p
  do
    {
      unsigned int q = (qLow + qHigh) / 2;
      
      if (Ppoisson(q, mean) >= p)
	{
	  qHigh = q;
	}
      else
	{
	  qLow = q+1;
	}
    }
  while (qLow < qHigh);
  
  return qHigh;
}


// Compute a Poisson quantile directly if it's small, else
// by binary search.
//
static unsigned int qPois(double p, double mean)
{
  unsigned int q;
  
  if (mean < 100.0)
    {
      double pq = exp(-mean);
      double pCum = pq;
      
      q = 0;
      while (pCum < p)
	{
	  q++;
	  pq *= mean / q;
	  pCum += pq;
	}
    }
  else
    q = qPoisBSearch(p, mean);
  
  return q;
}


// Compute the min bucket size for the bucket defined by the given projection.
static unsigned int minBucketSize(const Residue *instance,
				  const SimpleLSHFunction &projection,
				  unsigned int userThreshold)
{
  double bucketEValue = TotalNInstances;
  const SeqPosn *hashPosns = projection.hashPosns();
  
  for (SeqPosn j = 0; j < projection.nHashPosns(); j++)
    {
      Residue r = instance[hashPosns[j]];
      bucketEValue *= BgDist[r];
    }
  
  unsigned int poisThreshold = qPois(0.9, bucketEValue);
  return MAX(userThreshold, poisThreshold);
}


///////////////////////////////////////////////////////////////////////
// SELECTBUCKETS()
//
// Given the projections of every potential motif instance in the input,
// find large collections of instances with the same projection and
// create Motifs from them.  These Motifs are our initial guesses
// at real motifs hidden in the input.
//
// INPUTS:
//   - array of Records giving projection value and the string from which
//      it came, sorted by projection value
//   - length of the array
//   - projection function used to compute the array
//   - vector of all input sequences
//   - minimum size threshold to pass a bucket on to refinement
//
//   - consensus of the true Motif (NULL if unknown, used only for
//     testing with synthetic data when SYNTHETIC is enabled).
//
// RETURNS: vector of candidate motifs to be refined.
//
MotifVector SelectBuckets(const Record *records, SeqPosn nRecords,
			  const SimpleLSHFunction &projection,
			  const SeqVector sequences,
			  unsigned int threshold,
			  const Residue *trueConsensus)
{
  MotifVector motifs;
  Motif *motif;
  
  motif = motifs.allocNext();
  motif->init(MotifLength, InputAlphabet, BgDist);
  
  const Record *endPtr = records + nRecords;
  while (records != endPtr)
    {
      const Record *bucket = records;
      LSHValue currKey = bucket->key();
      
      do
	records++;
      while (records->key() == currKey); // skip to end of bucket
      
      SeqLength bucketSize = SeqLength(records - bucket);
      
      //
      // Decide whether this bucket is worth keeping
      //
      {
	const Residue *instance =
	  sequences[bucket[0].seqNum()].data + bucket[0].position();
	
	if (bucketSize < minBucketSize(instance, projection, threshold))
	  continue;
      }
      
      //
      // Construct motif from this bucket
      //
      for (SeqPosn j = 0; j < bucketSize; j++)
	{
	  const Residue *instance = 
	    sequences[bucket[j].seqNum()].data + bucket[j].position();
	  
	  motif->addInstance(bucket[j].seqNum(), 
			     bucket[j].position(),
			     instance);
	}
      
      
#ifdef SYNTHETIC
      annotateTrueMotifs(motif, projection, trueConsensus);
#endif
      
      motif = motifs.allocNext();
      motif->init(MotifLength, InputAlphabet, BgDist);
    }
  
  motifs.removeLast();
  
  return motifs;
}

///////////////////////////////////////////////////////////////////////////

#ifdef SYNTHETIC

//
// annotateTrueMotifs()
// If the input motif contains at least two instances of the *real* motif,
// assign it a unique nonzero tag number so that we can track it during
// refinement. If the motif comes from the consensus bucket, give it a
// positive tag; otherwise, give it a negative tag.
//
static void annotateTrueMotifs(Motif *motif, 
			       const SimpleLSHFunction &projection,
			       const Residue *trueConsensus)
{
  static int uniqueTag = 0;
  unsigned int nTrueInstances = 0;
  
  for (unsigned int j = 0; j < motif->nInstances(); j++)
    {
      const MotifInstance &instance = motif->instances()[j];
      
      if (instance.position == TruePosns[instance.seqNum])
	nTrueInstances++;
    }
  
  if (nTrueInstances < 2)
    return;
  
  const SeqPosn *posns   = projection.hashPosns();
  const Residue *example = motif->instances()[0].data;
  bool isConsensusBucket = true;
  
  for (SeqPosn k = 0; k < projection.nHashPosns(); k++)
    {
      SeqPosn p = posns[k];
      if (Alphabet::isMismatch(trueConsensus[p], example[p]))
	{
	  isConsensusBucket = false;
	  break;
	}
    }
  
  ++uniqueTag;
  motif->setTag(isConsensusBucket ? uniqueTag : -uniqueTag);
  
  cerr << "*** Motif " << motif->tag() << '\n';
}

#endif
