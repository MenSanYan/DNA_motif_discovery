//
// FINDMOTIF.CC
// Find motif using LSH-based initialization
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstring>
#include <cmath>

#include "global.h"
#include "findmotif.h"
#include "estparams.h"
#include "selectbucket.h"
#include "refine.h"
#include "local.h"

#include "lshcommon.h"
#include "lshfunction.h"
#include "timer.h"

using namespace std;


#ifdef SYNTHETIC
#define EARLY_STOPPING
#endif

//#define LOCAL_IMPROVEMENT
//#define PRINT_BEST_PER_ROUND


//
// findMotif()
// Run the LSH motif-finding algorithm for nIterations iterations (l),
// choosing nPositions hash positions each time (k).
//
Motif findMotif(const SeqVector sequences, const Residue *consensus)
{
  double constructionTime = 0.0, checkingTime = 0.0;
  unsigned int nIterations = FixedNIterations;
  unsigned int threshold = FixedMinBucketSize;
  SeqLength nPositions = FixedNPositions;
  FinderParams params;
  Record *records;
  
  
  //
  // Set initial motif-finding parameters.  By default, if NMotifInstances
  // is unspecified, assume it's = to # of input sequences.
  //
  params.motifLength = MotifLength;
  params.nErrors = NErrors;
  params.falseNegativeBound = FALSE_NEGATIVE_BOUND;
  
  params.nSeqs = sequences.length();
  params.totalInstances = TotalNInstances;
  params.nMotifInstances = 
    (NMotifInstances ? NMotifInstances : sequences.length());
  
  if (!nPositions) // posns, iterations not fixed in advance
    chooseKMS(params, &nPositions, &nIterations, &threshold);
  
#ifdef VERBOSE
  cerr << "*** parameters: k = " << nPositions
       << ", m = " << nIterations
       << ", t = " << threshold << '\n';
#endif
  
  
  records = allocRecords(sequences, MotifLength, NErrors);
  
  if (!records) // error -- could not allocate space
    {
      Motif motif(0, InputAlphabet, BgDist);
      return motif;
    }
  
  Motif bestMotif(MotifLength, InputAlphabet, BgDist);
  bestMotif.setScore(-1);
  
  NRefinements = 0; // restart global counter for each motif
  
  for (unsigned int iter = 0; iter < nIterations; iter++)
    {
      MotifVector motifs;
      SeqLength nRecords;
      
#ifdef VERBOSE   
      if (iter % 10 == 0)
	cerr << "** Pass " << iter + 1 << "/" << nIterations << '\n';
#endif
      startTimer();
      
      SimpleLSHFunction hasher(MotifLength, nPositions);
      nRecords = computeProjections(sequences, &hasher, 
				    NErrors, records);
      
      // Set sentinel record so we don't have to keep checking
      // for end of records later.
      //
      records[nRecords].setKey( ~(records[nRecords - 1].key()) );
      
      motifs = SelectBuckets(records, nRecords, hasher, sequences,
			     threshold, consensus);
      
      constructionTime += stopTimer();
      startTimer();
      cout<<"yjh"<<endl;
      motifs = refineMotifs(motifs, sequences);
      
      // initialize per-round maximum
      Motif bestMotifThisRound(MotifLength, InputAlphabet, BgDist);
      bestMotifThisRound.setScore(-1);

      for (unsigned int j = 0; j < motifs.length(); j++)
	{
	  // update per-round maximum
	  if (motifs[j].score() > bestMotifThisRound.score())
	    bestMotifThisRound = motifs[j];
	}
      
#ifdef LOCAL_IMPROVEMENT     
      if (bestMotifThisRound.score() > 0)
	{
	  double oldBestScore = bestMotifThisRound.score();
	  double newBestScore = -1e+9;
	  
	  for (unsigned int j = 0; j < motifs.length(); j++)
	    {
	      if (motifs[j].score() == oldBestScore)
		{
		  // NOTE: we have effectively disabled complexity correction
		  Motif newMotif = localSearch(motifs[j], sequences,
					       3 * MotifLength,
					       MotifLength, MotifLength);
		  
		  if (newMotif.score() > newBestScore)
		    {
		      bestMotifThisRound = newMotif;
		      newBestScore = newMotif.score();
		    }
		}
	    }
	}
#endif // LOCAL_IMPROVEMENT
      
      
#ifdef PRINT_BEST_PER_ROUND
      cerr << "XXX ";
      printSeq(bestMotifThisRound.consensus(), 
	       bestMotifThisRound.length(), cerr);
      cerr << ' ' << bestMotifThisRound.score() << '\n';
#endif

      if (bestMotifThisRound.score() > bestMotif.score())
	bestMotif = bestMotifThisRound;
      
      checkingTime += stopTimer();
      
#ifdef EARLY_STOPPING
      // Terminate now if we've got a "perfect" motif.
      if (bestMotif.score() == sequences.length())
	break;
#endif
    }
  
  cerr << "** Construction time:  " << constructionTime << '\n';
  cerr << "** Checking time:      " << checkingTime     << '\n';
  cerr << "** Candidates refined: " << NRefinements     << '\n';
  
  delete [] records;
  return bestMotif;
}
