//
// LOCAL.H
// Perform local refinement of a motif in an attempt to improve its score.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __LOCAL_H
#define __LOCAL_H

#include "seqinfo.h"
#include "motif.h"

Motif localSearch(const Motif &motif, const SeqVector seqs,
		  SeqLength windowSize,
		  SeqLength minLength, 
		  SeqLength maxLength);

#endif
