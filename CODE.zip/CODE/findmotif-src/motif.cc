//
// MOTIF.CC
// Implementation of a WMM-based sequence motif
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <iomanip>
#include <cstring>

#include "motif.h"
#include "wmm.h"

using namespace std;


//
// Motif::copy()
// Replace this motif with a (deep) copy of another motif
//
void Motif::copy(const Motif &other)
{
  if (this == &other)
    return;
  
  _length = other._length;
  _score  = other._score;
  _tag    = other._tag;
  
  _instances = other._instances.copy();
  
  _wmm = other._wmm;
  
  if (_consensus)
    delete [] _consensus;
  
  if (other._consensus)
    {
      _consensus = new Residue [other._length];
      memcpy(_consensus, other._consensus, other._length * sizeof(Residue));
    }
  else
    _consensus = NULL;
}

//
// Motif::init()
// Initialize the motif as if calling the constructor.  Delete
// any old state associated with it.
//
void Motif::init(SeqLength length, const Alphabet *alphabet,
		 const double *bgDist)
{ 
  _length = length;
  _wmm.init(length, alphabet, 1.0, bgDist);  
  
  if (_consensus != NULL) delete [] _consensus;
  _consensus = NULL;
  
  _score = 0.0;
  _tag = 0;
  
  _instances.truncate(0);
}


//
// Motif::addInstance()
// Add a new instance to the motif, updating the WMM and the instance vector.
//
void Motif::addInstance(SeqNumber seqNum, SeqPosn posn, 
			const Residue *instanceStr)
{
  MotifInstance *i = _instances.allocNext();
  i->seqNum   = seqNum;
  i->position = posn;
  i->data     = instanceStr;
  
  _wmm.addInstance(instanceStr); 
  
  if (_consensus)
    {
      delete [] _consensus;
      _consensus = NULL;
    }
}

//
// Motif::computeConsensus()
// Compute the consensus string of this motif
//
Residue *Motif::computeConsensus(void)
{
  Residue *cons = new Residue [_length];
  _wmm.computeConsensus(cons);
  return cons;
}


//
// Motif::computeLLRScore()
// Compute a motif's "LLR score", which is the joint log likelihood ratio
// (base e) of all of its instances, assuming the null model is the
// background and the alternative is the model which best fits the
// instances.  We have already computed such a model in the motif's WMM.
// 
double Motif::computeLLRScore(void)
{
  double score = 0.0;
  
  for (unsigned int j = 0; j < _instances.length(); j++)
    score += _wmm.scoreInstance(_instances[j].data);
  
  return score;
}


//
// Motif::computeLLRScore(')
// As above, but compute the score from only a specified subset of
// the motif's positions.
//
double Motif::computeLLRScore(const SeqPosn *posns, SeqPosn nPosns)
{
  double cscore = 0.0;
  
  for (unsigned int j = 0; j < _instances.length(); j++)
    cscore += _wmm.scoreInstance(_instances[j].data, posns, nPosns);
  
  return cscore;
}


//
// Motif::nClose()
// compute the number of instances within a specified Hamming distance
// bound of the motif's consensus.
//
unsigned int Motif::nClose(SeqLength bound)
{
  const Residue *cons = consensus();
  unsigned int nClose = 0;
  
  for (unsigned int j = 0; j < _instances.length(); j++)
    {
      const Residue *instance = _instances[j].data;
      SeqLength errs = 0;
      
      for (SeqPosn k = 0; k < _length; k++)
	if (Alphabet::isMismatch(instance[k], cons[k]))
	  errs++;
      
      if (errs <= bound)
	nClose++;
    }
  
  return nClose;
}


//
// Printing routine for motifs
//
ostream &operator<<(ostream &os, Motif &motif)
{
  os << "MOTIF: "  << motif.nInstances() << " instances, "
     << "length = " << motif.length()
     << ", score = " << motif.score() 
#ifdef SYNTHETIC
     << ", tag = " << motif.tag()
#endif
     << '\n';
  os << '\n';
  
  for (unsigned int j = 0; j < motif.nInstances(); j++)
    {
      MotifInstance &instance = motif.instances()[j];
      
      os << setw(4) << instance.seqNum   + 1 << ' ' 
	 << setw(5) << instance.position + 1 << ' ';
      motif.wmm().alphabet()->printSeq(instance.data, motif.length(), os);
      os << '\n';
    }
  
  return os;
}
