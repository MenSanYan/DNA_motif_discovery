//
// ESTPARAMS.CC
// Estimate good parameters for the PROJECTION motif finding algorithm.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.

#ifndef __ESTPARAMS_H
#define __ESTPARAMS_H

#include "datatypes.h"

// These values are needed to choose good parameters for motif finding.
//
struct FinderParams {
  SeqLength motifLength;   // length of motif
  SeqLength nErrors;       // max # of substitutions allowed per instance
  
  unsigned int nSeqs;           // number of input seqs
  unsigned int nMotifInstances; // number of motif instances believed in input
  unsigned int totalInstances;  // total # of motifLength-sized substrings
                                // in input
  
  double falseNegativeBound;    // maximum failure prob for good starting pt
};


const double FALSE_NEGATIVE_BOUND = 0.05;


double chooseKMS(const FinderParams &params,
		 SeqLength *iprojSize,
		 unsigned int *inIters,
		 unsigned int *ithreshold,
		 int ignoreSignalLevel = 0);
  
#endif
