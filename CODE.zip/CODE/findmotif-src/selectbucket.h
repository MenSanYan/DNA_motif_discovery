//
// SELECTBUCKET.CC
// Given a list of records sorted into buckets, return a list of motifs
// created from only those buckets which are significantly unlike the
// background sequence.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __SELECTBUCKET_H
#define __SELECTBUCKET_H

#include "lshfunction.h"
#include "seqinfo.h"
#include "record.h"
#include "motif.h"

MotifVector SelectBuckets(const Record *, SeqPosn,
			  const SimpleLSHFunction &,
			  const SeqVector, unsigned int,
			  const Residue *trueConsensus = NULL);
#endif
