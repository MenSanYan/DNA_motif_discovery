//
// REFINE.CC
// Motif refinement and scoring code
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>

#include "refine.h"
#include "global.h"
#include "em.h"
#include "motif.h"
#include <vector>
using namespace std;


// Define this to add a combinatorial refinement step after the EM
// step.  We used this additional "exact" refinement in our synthetic
// experiments, where it noticeably enhanced performance, but there's
// no particular reason to think it works better for real data.
//
#ifdef SYNTHETIC
#define REFINE_EXACT
#endif

// Don't let exact refinement go for more than this many iterations.
// 
const int MAXITERS = 5;


// a counter that keeps track of # of EM refinements performed
//
long NRefinements;


//
// local prototypes
//
static SeqPosn findMostLikelyInstance(const SeqInfo &seq, WMM &wmm);

#ifdef REFINE_EXACT
static SeqPosn findClosestInstance(const SeqInfo &seq, Motif &motif);
static Motif refineByTossing(Motif &motif, const SeqVector seqs);
#endif


//
// refineMotifs()
// Given a collection of initial guesses at a motif model, and a
// set of input sequences, refine each guess into an improved
// motif.  Score each motif according to the number of instances
// within the (user-specified) bound for # of mutations vs the
// consensus.
//
MotifVector refineMotifs(MotifVector motifs, const SeqVector seqs)
{
  	MotifVector newMotifs;
	/*vector<Motif>::iterator it1 = motifs.begin();
	
	
	while(it1 != motifs.end()){
		vector<MotifInstance>::iterator it = it1->_instances.begin();
		while(it != it1->_instances.end()){
			cout<<it->position<<endl;
		}
		cout<<""<<endl;
	}*/
  for (unsigned int j = 0; j < motifs.length(); j++)
    {

	cout<<motifs[j]<<endl;
      WMM refinedWMM = refineEM(seqs, BgDist, motifs[j].wmm());
      NRefinements++; // count refinements globally
      
      // Pick the instance from each seq that best matches the refined WMM.
      //
      Motif currMotif(MotifLength, InputAlphabet, BgDist);
      for (SeqNumber i = 0; i < seqs.length(); i++)
	{
	  SeqPosn offset = findMostLikelyInstance(seqs[i], refinedWMM);
	  currMotif.addInstance(i, offset, seqs[i].data + offset);
	}
      
#ifdef REFINE_EXACT
      currMotif.setScore( currMotif.nClose(NErrors) );
#else
      currMotif.setScore( currMotif.computeLLRScore() );
#endif
      
#ifdef SYNTHETIC
      if (motifs[j].tag() != 0)
	{
	  cerr << motifs[j].tag() 
	       << " pre " << currMotif.score()
	       << '\n';
	  cerr << currMotif.wmm()
	       << '\n';
	}
#endif

#ifdef REFINE_EXACT
      
      // Refine the motif by choosing the instance closest to the
      // current consensus from each sequence.
      //
      for (int k = 0; k < MAXITERS; k++)
	{
	  Motif newMotif(currMotif.length(), InputAlphabet, BgDist);
	  for (SeqNumber i = 0; i < seqs.length(); i++)
	    {
	      SeqPosn offset = findClosestInstance(seqs[i], currMotif);
	      newMotif.addInstance(i, offset, seqs[i].data + offset);
	    }
	  
	  newMotif.setScore(newMotif.nClose(NErrors));
	  	  
	  // *more* close-enough instances is better
	  if (newMotif.score() <= currMotif.score())
	    break;
	  else
	    currMotif = newMotif;
	}
      
      currMotif = refineByTossing(currMotif, seqs);
      
#ifdef SYNTHETIC   
      currMotif.setTag(motifs[j].tag());
      
      if (currMotif.tag() != 0)
	cerr << currMotif.tag() << " post " << currMotif.score() << '\n';
#endif

#endif // REFINE_EXACT
      
      newMotifs.add(currMotif);
    }
  
  return newMotifs;
}


//
// findMostLikelyInstance()
// Given a sequence and a WMM, find the instance in the sequence
// with the highest LLR score under the WMM vs the background.
// Return the starting offset of this instance (the first, if
// multiple offsets score the same).
//
static SeqPosn findMostLikelyInstance(const SeqInfo &seq, WMM &wmm)
{
  double maxScore = -1e+9;
  SeqPosn maxOffset = 0;
  
  for (SeqPosn j = 0; j < seq.length - wmm.length(); j++)
    {
      double score = wmm.scoreInstance(seq.data + j);
      
      if (score > maxScore)
	{
	  maxScore = score;
	  maxOffset = j;
	}
    }
  
  return maxOffset;
}


#ifdef REFINE_EXACT

//
// findClosestInstance()
// Given a sequence and a WMM, find the instance in the sequence
// with the fewest mismatches w/r to the motif consensus. Return 
// the starting offset of this instance (the first, if multiple
// offsets score the same).
//
static SeqPosn findClosestInstance(const SeqInfo &seq, Motif &motif)
{
  const Residue *consensus = motif.consensus();
  SeqLength minErrs = motif.length() + 1;
  SeqPosn minOffset = 0;
  
  for (SeqPosn j = 0; j <= seq.length - motif.length(); j++) 
    {
      const Residue *instance = seq.data + j;
      SeqLength nErrs = 0;
      
      for (SeqPosn k = 0; k < motif.length(); k++)
	if (Alphabet::isMismatch(instance[k], consensus[k]))
	  nErrs++;
      
      if (nErrs < minErrs)
	{
	  minErrs = nErrs;
	  minOffset = j;
	}
    }
  
  return minOffset;
}


//
// refineByTossing()
// A rather gross hack, used only with combinatorial refinement,
// that gives a small performance boost in practice.  Repeatedly
// find the worst-scoring motif instance, throw it out, and
// replace it with the instance from the same sequence closest to
// the original consensus.  Stop when we converge or after MAXITERS
// iterations, and return the new motif.
//
static Motif refineByTossing(Motif &oldMotif, const SeqVector seqs)
{
  if (oldMotif.nInstances() == 0)
    return oldMotif;
  
  for (int iter = 0; iter < MAXITERS; iter++)
    {
      const Residue *consensus = oldMotif.consensus();
      SeqNumber worstInstance = 0;
      int worstNErrors = -1;
      SeqPosn newPosn;
            
      for (SeqNumber j = 0; j < oldMotif.nInstances(); j++)
        {
          const Residue *i = oldMotif.instances()[j].data;
          int nErrors = 0;
          
          for (SeqPosn k = 0; k < oldMotif.length(); k++)
            if (Alphabet::isMismatch(i[k], consensus[k]))
              nErrors++;
          
	  if (nErrors > worstNErrors)
            {
              worstNErrors = nErrors;
              worstInstance = j;
            }
        }
      
      Motif newMotif(MotifLength, InputAlphabet, BgDist);
      
      for (SeqNumber j = 0; j < oldMotif.nInstances(); j++)
        {
          if (j != worstInstance)
            newMotif.addInstance(oldMotif.instances()[j]);
        }
      
      SeqNumber worstSeq = oldMotif.instances()[worstInstance].seqNum;
      newPosn = findClosestInstance(seqs[worstSeq], newMotif);
      newMotif.addInstance(worstSeq, newPosn, seqs[worstSeq].data + newPosn);
      
      newMotif.setScore( newMotif.nClose(NErrors) );
      
      if (newMotif.score() - oldMotif.score() < 1.0e-4)
        return oldMotif;
      else
	oldMotif = newMotif;
    }
  
  return oldMotif;
}

#if 0

//
// trim()
// Remove from a motif any instance that is further away from the
// consensus than the bound NErrors allowed for combinatorial refinement.
//
static Motif trim(Motif &oldMotif)
{
  const Residue *consensus = oldMotif.consensus();
  Motif newMotif(oldMotif.length(), oldMotif.wmm().alphabet(), BgDist);
  
  for (unsigned int j = 0; j < oldMotif.nInstances(); j++)
    {
      const MotifInstance &in = oldMotif.instances()[j];
      const Residue *i = in.data;
      SeqLength nErrors = 0;
      
      for (SeqPosn k = 0; k < oldMotif.length(); k++)
        if (Alphabet::isMismatch(i[k], consensus[k]))
          nErrors++;
      
      if (nErrors <= NErrors)
        newMotif.addInstance(in);
    }
  
  newMotif.setScore(oldMotif.score());
  
  return newMotif;
}

#endif

#endif // REFINE_EXACT
