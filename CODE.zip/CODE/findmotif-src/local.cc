//
// LOCAL.CC
// Perform local refinement of a motif in an attempt to improve its score.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// This file includes code to search over different motif lengths and
// to shift the position of each instance slightly to try to improve
// its score.  However, the code doesn't work reliably yet and so
// is *disabled* in findmotif.cc (by undefining LOCAL_IMPROVEMENT there).
//

#include <cmath>
#include <cassert>

#include "local.h"

#include "global.h"

using namespace std;


//
// findMaxFeasibleWindow()
// Shrink the search window around a motif so that it does not
// extend past the end of any containing sequence.
//
// INPUTS: initial motif
//         sequence information
//         center of each motif instances w/r to its containing sequence
//         left and right boundaries of window (offsets w/r to motif centers)
//
// RETURNS: length of new window
// SETS:    new left and right window boundaries
//
static SeqLength findMaxFeasibleWindow(const Motif &motif,
				       const SeqVector seqs,
				       const SeqPosn *centers,
				       SeqDiffT *windowLeft,
				       SeqDiffT *windowRight)
{
  for (unsigned int j = 0; j < motif.nInstances(); j++)
    {
      SeqLength seqLen = seqs[motif.instances()[j].seqNum].length;
      SeqPosn center = centers[j];
      
      if (SeqDiffT(center) + *windowLeft < 0)
	*windowLeft = -SeqDiffT(center);
      
      if (center + *windowRight >= seqLen)
	*windowRight = seqLen - 1 - center;
    }
  
  return *windowRight - *windowLeft + 1;
}


//
// computeLLRscores()
// Fill in the array of LLRscores for the search window.  For each offset
// delta (w/r to the center of each motif instance), we compute the
// contribution of the residues at offset delta to the LLR score of any
// motif that includes it.
//
// INPUT: initial motif
//        sequence information
//        Center position of each motif instance
//        range of offsets to compute
//        array to hold scores
// RETURNS: mean LLR score across all positions
// SETS:  score array; offset 0 corresponds to windowLeft, and so on
//
static double computeLLRscores(const Motif &motif, const SeqVector seqs,
			       const SeqPosn *centers,
			       SeqDiffT windowLeft, SeqDiffT windowRight,
			       double *LLRscores)
{
  unsigned int nRealResidues = InputAlphabet->nRealResidues();
  const double priorWeight = 1.0;
  
  //
  // Precompute pointers to center residue of each motif instance.
  //
  const Residue **cptrs = new const Residue * [motif.nInstances()];
  for (unsigned int j = 0; j < motif.nInstances(); j++)
    {
      const Residue *seq = seqs[motif.instances()[j].seqNum].data;
      cptrs[j] = seq + centers[j];
    }
  
  
  double *dist = new double [nRealResidues + 1];
  
  for (SeqDiffT delta = windowLeft; delta <= windowRight; delta++)
    {
      unsigned int nGoodInstances = 0;
      
      //
      // Compute the observed residue distribution across all instances
      // at this position.  Don't use X residues in the computaton.
      //
      
      for (Residue r = 1; r <= nRealResidues; r++)
	dist[r] = BgDist[r] * priorWeight;  // prior weight as backgrnd
      
      for (unsigned int j = 0; j < motif.nInstances(); j++)
	{ 
	  Residue r = *(cptrs[j] + delta);
	  
	  if (r != Alphabet::RESIDUE_X)
	    {
	      dist[r]++;
	      nGoodInstances++;
	    }
	}
      
      
      //
      // Compute the LLR score for the observed instances under
      // the ML model vs the background model, ONLY at this posn.
      //
      
      for (Residue r = 1; r < nRealResidues; r++)
	dist[r] = log( dist[r] / (nGoodInstances + priorWeight) );
      
      double score = 0.0;
      for (unsigned int j = 0; j < motif.nInstances(); j++)
	{ 
	  Residue r = *(cptrs[j] + delta);
      
	  if (r != Alphabet::RESIDUE_X)
	    score += dist[r] - LogBgDist[r];
	}
      
      LLRscores[delta - windowLeft] = score; 
    }
  
  delete [] dist;
      
  unsigned int wsize = windowRight - windowLeft + 1;
  double mean = 0.0;
  for (unsigned int j = 0; j < wsize; j++)
    mean += LLRscores[j];
  mean /= wsize;
  
  delete [] cptrs;
  
  return mean;
}


//
// localSearch()
// Find the best motif in the vicinity of an initial guess by a
// strictly local search.  We consider every contiguous run of
// between minLength and maxLength positions from a window of
// size windowSize centered on the motif.
//
// INPUT: initial guess at the motif
//        input sequence information
//        size of window to search
//        minimum and maximum motif lengths to consider
//
// RETURNS: best motif within given window and length constraints.
//
// NOTE: window size is always rounded up to next odd number.
//
Motif localSearch(const Motif &motif, const SeqVector seqs,
		  SeqLength windowSize,
		  SeqLength minLength, SeqLength maxLength)
{
  // double logAlphabetSize = log(InputAlphabet->nRealResidues());
  SeqDiffT windowLeft = -SeqDiffT(windowSize)/2, windowRight = windowSize/2;
  
  //
  // Find the center position of every motif instance.
  //
  SeqPosn *centers  = new SeqPosn [motif.nInstances()];
  for (unsigned int j = 0; j < motif.nInstances(); j++)
    centers[j] = motif.instances()[j].position + motif.length() / 2;
  
  
  //
  // Reduce the window size and boundaries as needed to avoid
  // walking off the end of any sequence.
  //
  
  windowSize = findMaxFeasibleWindow(motif, seqs, centers,
				     &windowLeft, &windowRight);
  
  if (maxLength > windowSize)
    maxLength = windowSize;
  
  
  //
  // Get per-position LLR scores in neighborhood of motif.
  //
  
  double *LLRscores = new double [windowSize];
  double mean = computeLLRscores(motif, seqs, centers,
				 windowLeft, windowRight, 
				 LLRscores);
  
  
  //
  // Initialize runScores to contain sum scores for each consecutive
  // run of minLength - 1 motif positions.
  //
  
  double *runScores = new double [windowSize];
  
  {
    SeqLength motifLength = minLength - 1;
    
    runScores[0] = LLRscores[0];
    for (SeqPosn k = 1; k < motifLength; k++)
      runScores[0] += LLRscores[k];
    
    for (SeqPosn j = 1; j <= windowSize - motifLength; j++)
      {
	runScores[j] = 
	  runScores[j - 1] - LLRscores[j - 1] + LLRscores[j + motifLength - 1];
      }
  }
  
  
  //
  // Find highest-scoring run of positions of any length between minLength
  // and maxLength.  Because longer runs essentially always look better,
  // we apply a complexity correction to the score to penalize longer
  // motif lengths.
  //
  
  double    globalBestScore  = -1e+9;
  SeqPosn   globalBestOffset = 0;
  SeqLength globalBestLength = 0;
  
  for (SeqLength motifLength = minLength; 
       motifLength <= maxLength; 
       motifLength++)
    {
      runScores[0] += LLRscores[motifLength - 1];
      
      double bestScore   = runScores[0];       // best score for curr length
      SeqPosn bestOffset = 0;                  // posn offset w/best score
      
      for (SeqPosn j = 1; j <= windowSize - motifLength; j++)
	{
	  runScores[j] += LLRscores[j + motifLength - 1];
	  
	  if (runScores[j] > bestScore)
	    {
	      bestScore  = runScores[j];
	      bestOffset = j;
	    }
	}
      
      //
      // ** Complexity correction **
      // The raw motif score is a log likelihood ratio for the data
      // under the motif model vs the null i.i.d. background model.
      // We now weight each motif model with a prior distribution
      // that assigns equal probability to each possible motif *length*.
      // Every hypothesis of a given length is weighted equally.
      //
      // Because there are many more motif models of longer lengths,
      // this correction strongly favors shorter motifs.  The weighting
      // factor is essentially the log of the # of hypotheses, which
      // scales linearly with the motif size.
      //
      // Note that a precise count of the # of hypotheses must also
      // correct for the fact that different #'s of hypotheses of 
      // different lengths fit within a given window size.
      //
      
      // HACK: choose correction size to counteract expected effect
      // of adding one more posn.
      double correction = motifLength * mean;
      // motifLength * logAlphabetSize + log(motif.nInstances() * (windowSize - motifLength + 1));
      
      bestScore -= correction;
      if (bestScore > globalBestScore)
	{
	  globalBestScore  = bestScore;
	  globalBestOffset = bestOffset;
	  globalBestLength = motifLength;
	}
    }
  
  delete [] runScores;
  delete [] LLRscores;
  
  
  //
  // We now have the best length and offset for the motif within
  // the window.  Construct the new best motif.
  //
  
  Motif newMotif(globalBestLength, InputAlphabet, BgDist);
  for (unsigned int j = 0; j < motif.nInstances(); j++)
    {
      SeqNumber seqNum = motif.instances()[j].seqNum;
      SeqPosn start = centers[j] + globalBestOffset + windowLeft;
      newMotif.addInstance(seqNum, start, seqs[seqNum].data + start);
    }
  newMotif.setScore( globalBestScore );
  
  delete [] centers;
  
  return newMotif;
}
