//
// SCAN_GB_FEATURES.CC
// Scan a Genbank-formatted sequence file to extract all its features.
// (up to the end of the first FEATURES section). Print each feature as 
// a single line to standard output, with the whitespace-delimited tokens 
// on each line separated by the character TOKEN_SEPARATOR.  Quoted and 
// parenthesized strings are treated specially: internal whitespace does
// not split them and may be removed.
//
// The file to be parsed may be named on the command line or piped via stdin.
// If two files are named on the command line, the second file will be
// written with the raw sequence from the ORIGIN section of the input
// file.
//

#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// A line beginning with this string indicates the start of 
// sequence features.
//
const char FEATURE_START[]   = "FEATURES ";

// A line beginning with this string indicates the start of
// the actual sequence.
//
const char SEQUENCE_ORIGIN[] = "ORIGIN ";

// This character separates adjacent tokens in the output.
//
const char TOKEN_SEPARATOR = 0x01;

const char EOL = '\n';

// Count the current line number for printing error messages.
//
static unsigned int lineNum = 0;


//
// scanQuoted()
// Scan a quoted string, printing it to standard output.
// Remove any EOL's and any leading spaces on each line
// from the string, but otherwise preserve whitespace.
// We insert a single space between successive lines
// to prevent their text from running together.
//
// ASSUMES: next character to be read is a double-quote
// EFFECTS: positions stream after next double-quote char
//
static void scanQuoted(istream &is)
{
  bool ignoreWhitespace = false;
  
  // Consume the opening quote
  is.get();
  cout << '\"';
  
  for (;;)
    {
      int nextChar = is.get();
      
      // Ignore whitespace at beginning of lines.
      if (isspace(nextChar))
	{
	  if (nextChar == EOL)
	    {
	      ignoreWhitespace = true;
	      cout << ' ';              // space before next word
	      lineNum++;
	    }
	  else if (!ignoreWhitespace)
	    cout << (char) nextChar;
	  
	  continue;
	}
      
      switch (nextChar)
	{
	case EOF:    // stream ended inside quoted string?
	  cerr << "Error: EOF inside quoted string at line "
	       << lineNum + 1 << endl;
	  exit(1);
	  
	case '\"':   // end of quoted region
	  cout << (char) nextChar;
	  return;
	
	default:
	  ignoreWhitespace = false;
	  cout << (char) nextChar;
	  break;
	}
    }
}


//
// scanParenthesized()
// Scan a parenthesized string, printing it to standard output.
// Don't stop until we close the parenthesis that began the
// string.
//
// ASSUMES: next character to be read from is is an open parenthesis
// EFFECTS: stream is positioned after the matching close parenthesis
//
static void scanParenthesized(istream &is)
{
  int level = 0;
  
  for (;;)
    {
      int nextChar = is.get();
      
      // Ignore all whitespace.
      if (isspace(nextChar))
	{
	  if (nextChar == EOL)
	    lineNum++;
	  
	  continue;
	}
      
      switch(nextChar)
	{
	case EOF: // stream ended inside parenthesized region?
	  cerr << "Error: EOF inside parenthesized string at line "
	       << lineNum + 1 << endl;
	  exit(1);
	  
	case '(':
	  cout << (char) nextChar;
	  ++level;
	  break;
	  
	case ')':
	  cout << (char) nextChar;
	  if (--level == 0)
	    return;
	  
	default:
	  cout << (char) nextChar;
	  break;
	}
    }
}


//
// scanToken()
// Scan a complete whitespace-delimited token from the input.  In
// general, we stop at the first whitespace character; however,
// whitespace in quoted strings (e.g. "foo bar baz") and parenthesized
// strings (e.g. (foo,bar,baz) ) does not terminate a token.
//
// EFFECTS: the stream is positioned at the first character after the token.
//
static void scanToken(istream &is)
{
  for (;;)
    {
      int nextChar = is.peek();
      
      if (isspace(nextChar))
	{
	  if (nextChar == EOL)
	    lineNum++;
	  
	  return;
	}
      
      switch (nextChar)
	{
	case EOF:
	  return;
	
	case '\"':                      // special case: quoted string
	  scanQuoted(is);
	  break;
	  
	case '(':                       // special case: parenthesized string
	  scanParenthesized(is);
	  break;
	  
	default:
	  is.get();
	  cout << (char) nextChar;
	  break;
	}
    }
}


//
// scanFeatures()
// Scan a succession of Genbank-formatted features.  A feature is
// assumed to consist of at least two whitespace-delimited tokens
// (the type and the sequence positions occpied by the features).
// All tokens after the first two are feature modifiers, which 
// must begin with the character '/'.
//
// Emit each feature on a single line with a single TOKEN_SEPARATOR
// character between each pair of tokens. Stop when we encounter a 
// non-whitespace character at the beginning of a line (assumed to be
// the next section header).
//
// ASSUMES: stream is positioned at the beginning of a line.
// EFFECTS: positions stream at first nonwhitespace char that
//          begins a line.
//
static void scanFeatures(istream &is)
{
  int tokenCount = 0;
  bool atBOL = true;
  
  for (;;)
    {
      int nextChar = is.peek();
      
      if (nextChar == EOF)
	break;
      else if (isspace(nextChar))
	{
	  if (nextChar == EOL)
	    {
	      atBOL = true;
	      lineNum++;
	    }
	  else
	    atBOL = false;
	  
	  is.get();
	  continue;
	}
      
      if (atBOL) // saw a non-whitespace char at beginning of line!
	break;
      
      // Put single spaces between tokens.  If we've reached the
      // end of the optional tokens, we're in a new feature --
      // emit an EOL instead.
      //
      if (tokenCount >= 2 && nextChar != '/')
	{
	  tokenCount = 0;
	  cout << endl;
	}
      else if (tokenCount > 0)
	cout << TOKEN_SEPARATOR;
      
      scanToken(is);
      tokenCount++;
    }
  
  if (tokenCount > 0) // Were we in the middle of a feature when we stopped?
    cout << endl;     // if so, terminate its output line.
}


//
// findSectionStart()
// Read the stream until we encounter a line beginning with the
// specified header string.  Discard this line and position
// the stream at the beginning of the following line.
//  
void findSectionStart(istream &is, const char *sectionHeader)
{
  static char buf[256];
  buf[0] = 0;
  
  while (!is.eof())
    {
      bool found = false;
      
      is.get(buf, 256 + 1);
      
      // Is this the right line?
      //
      if (!strncmp(buf, sectionHeader, strlen(sectionHeader))) 
	found = true;
      
      // Consume the rest of the line
      //
      while (!is.eof() && is.peek() != EOL)
	is.get(buf, 256 + 1);
      
      is.get(); // consume EOL
      lineNum++;
      
      if (found)
	return;
    }
}


//
// scanSequence()
// Scan a Genbank-style sequence from an input stream and write
// the corresponding raw sequence to an output stream.  Stop at
// EOF or when we see '/' (part of the end-of-sequence marker).
//
void scanSequence(istream &is, ostream &os)
{
  for (;;)
    {
      int nextChar = is.get();
      
      if (nextChar == '/' || nextChar == EOF) // found end of sequence
	return;
      else if (isalpha(nextChar))
	os.put(char(nextChar));
    }
}


int main(int argc, char *argv[])
{
  ifstream infile;
  istream *is;
  
  if (argc < 2)
    is = &cin;
  else
    {
      infile.open(argv[1]);
      
      if (!infile)
	{
	  cerr << "Error: could not open Genbank file " << argv[1] << endl;
	  exit(1);
	}
      else
	is = &infile;
    }
  
  findSectionStart(*is, FEATURE_START);
  
  if (!is->eof())
    scanFeatures(*is);
  
  if (argc > 2)
    {
      findSectionStart(*is, SEQUENCE_ORIGIN);
      
      if (is->eof())
	{
	  cerr << "Error: end of file encountered looking for sequence\n";
	  exit(1);
	}

      ofstream outfile(argv[2]);
      if (!outfile)
	{
	  cerr << "Error: could not open sequence output file " 
	       << argv[2] << endl;
	}
      
      scanSequence(*is, outfile);
    }
  
  return 0;
}
