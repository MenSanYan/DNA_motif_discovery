using System;


namespace SeqAlign
{
	public class Database
	{
		private string [] mySeq;
		private string [] myID;
		private int myCount;
		private string myType;
		public Database()
		{
		}
		public Database(string sequence, string type)
		{
			myType = type.ToUpper();
			myCount = countSeq(sequence);
			if ( myCount <= 0 ) // no id's mean there is only one sequence
			{
				myCount = 1;
				sequence = ">(no_identifier) \n" + sequence;
			}
			mySeq = new string[myCount];
			myID = new string[myCount];
			parseDB(sequence);
		}

		private void parseDB ( string s )
		{
			int [] newID = new int [myCount+1];
			char [] temp = s.ToCharArray();
			int j = 0;
			
			// locate all '>' characters
			for (int i = 0; i < temp.Length; i++ )
			{
				if ( temp[i] == '>' )
				{
					newID[j] = i;
					j++;
				}
			}
			newID[myCount] = temp.Length;
			for (int i = 0; i < myCount; i++)
			{
				int subStart = newID[i];
				int subLength = newID[i+1] - newID[i];
				myID[i] = extractID(s.Substring(subStart,subLength));
				mySeq[i] = extractSeq(s.Substring(subStart,subLength));
			}
			return;
		}

		private string extractSeq (string s)
		{
			int loc = s.IndexOf('\n');
			string data = s.Substring(loc);
			char[] temp = data.ToCharArray();
			string seq = "";
			for (int i = 0; i < temp.Length; i++ )
			{
				if ( ( temp[i] != ' ' ) && ( temp [i] != '\n' ) && ( temp [i] != '\r' ) )
				{
					seq += temp[i];
				}
			}
			return seq.ToUpper();
		}

		private string extractID (string s)
		{
			
			char[] temp = s.ToCharArray();
			string id = "";
			int i = 1;
			while ( ( temp[i] != ' ' ) && ( temp[i] != '\n' ) && (temp[i] != '\r') )
			{
				id += temp[i];
				i++;
			}
			if ( id.Length < 1 )
				id = "(no identifier)";
			return id;
		}

		private int countSeq ( string s )
		{
			int count = 0;
			char [] c = s.ToCharArray();
			for (int i = 0 ; i < c.Length ; i++ )
			{
				if ( c[i] == '>' )
					count ++;
			}
			return count;
		}

		public int SeqCount
		{
			get
			{
				return myCount;
			}
		}
		
		public string[] Sequences
		{
			get
			{
				return this.mySeq;
			}
		}

		public string[] IDs
		{
			get
			{
				return this.myID;
			}
		}

		public string Type
		{
			get
			{
				return this.myType;
			}
		}

		public char[] Alphabet
		{
			get
			{
				char[] alpha;
				if (myType.ToUpper() == "DNA")
					alpha = "ACGT".ToCharArray();
				else if (myType.ToUpper() == "RNA")
					alpha = "ACGU".ToCharArray();
				else if (myType.ToUpper() == "AMINO")
					alpha = "ACDEFGHIKLMNPQRSTVWY".ToCharArray();
				else
					alpha = "ACGT".ToCharArray();
				return alpha;
			}
		}
	}
}
