using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace SeqAlign
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem mnuSeq;
		private System.Windows.Forms.MenuItem mnuSeqDNA;
		private System.Windows.Forms.MenuItem mnuSeqAmino;
		private System.Windows.Forms.MenuItem mnuScore;
		private System.Windows.Forms.MenuItem mnuScorePam250;
		private System.Windows.Forms.Button btnClearAll;
		private System.Windows.Forms.MenuItem mnuScoreCustom;
		private System.Windows.Forms.MenuItem mnuSeqRNA;
		private System.Windows.Forms.Label lblSeq;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label lblScore;
		private System.Windows.Forms.Label lblAlign;
		private System.Windows.Forms.GroupBox grpScore;
		public System.Windows.Forms.RichTextBox txtAlignment;
		private System.Windows.Forms.MenuItem mnuScoreBlosum60;
		private System.Windows.Forms.MenuItem mnuScoreBlosum80;
		private System.Windows.Forms.MenuItem mnuScoreImport;		
		private System.Windows.Forms.Label lblMatch;
		private System.Windows.Forms.MenuItem mnuMotif;
		private System.Windows.Forms.MenuItem mnuMotifEM;
		private System.Windows.Forms.TextBox txtMotifLength;
		private System.Windows.Forms.Button btnCompute;
		private System.Windows.Forms.RichTextBox txtSeq1;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.Button btnImport;
		public System.Windows.Forms.OpenFileDialog dlgImport;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnSaveResults;
		private System.Windows.Forms.Button btnSaveData;
		private System.Windows.Forms.SaveFileDialog dlgSaveData;
		private System.Windows.Forms.TextBox txtParticleQty;
		private System.Windows.Forms.Label Label6;
		private System.Windows.Forms.Button btnSwarm;

		private int [,] scoreMatrix;
		private char [] scoreHeadings;
		private string matrixName;
		private string [] alignDisplay;
		private int [] alignScore;
		private double [] sigScore;
		private Swarm mySwarm;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtIndiv;
		private System.Windows.Forms.TextBox txtSocial;
		private System.Windows.Forms.Label label8;
		
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			InitializeComponent();
			
			string d1 = ""
                + ">seq1\n"
                + "CGACGATTATTGCGACGG\n"
                + ">seq2\n"
                + "CGCGACGAGGTATTTGCCAGAGCGC\n"
                + ">seq3\n"
                + "CCGGAATTTTCGCGCACAGAGA\n"
                + ">seq4\n"
                + "GGCCAGAGACGCGGCCACTTTTCGGAC\n"
                + ">seq5\n"
                + "GGGAACACGCGCGCCCGGAATTTTGCGAGAC\n"
                + ">seq6\n"
                + "CGACCTTTTGCCGAAGATCGAGACCGACACC\n"
                + ">seq7\n"
                + "CGCGACCCCCCCCTTTTGCCGAAGAGACCGACACC\n"
                + ">seq8\n"
                + "CGCGAGGACACGATTTTCCGAAGAGACCGACACC\n"
                + ">seq9\n"
                + "CGCGACAGAAGAGAAATTTTGCCCCGACACC\n"
                + ">seq10\n"
                + "CGCGACATTTTACCGAAGAGACCGATTTTCC\n";

			// test dataset 2
			// counts, A:10, C:15, G:13, T:16, total 54
			string d2 = ""
                + ">seq1\n"
                + "CGACGATTTTG\n"
                + ">seq2\n"
                + "GTTTTGCCAGAGCGC\n"
                + ">seq3\n"
                + "CCAATTTTCGCA\n"
                + ">seq4\n"
                + "GGAGCCACTTTTCGAC\n";
				
			txtSeq1.Text = d2;
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtAlignment = new System.Windows.Forms.RichTextBox();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.mnuSeq = new System.Windows.Forms.MenuItem();
			this.mnuSeqDNA = new System.Windows.Forms.MenuItem();
			this.mnuSeqRNA = new System.Windows.Forms.MenuItem();
			this.mnuSeqAmino = new System.Windows.Forms.MenuItem();
			this.mnuMotif = new System.Windows.Forms.MenuItem();
			this.mnuMotifEM = new System.Windows.Forms.MenuItem();
			this.mnuScore = new System.Windows.Forms.MenuItem();
			this.mnuScoreCustom = new System.Windows.Forms.MenuItem();
			this.mnuScoreBlosum60 = new System.Windows.Forms.MenuItem();
			this.mnuScoreBlosum80 = new System.Windows.Forms.MenuItem();
			this.mnuScorePam250 = new System.Windows.Forms.MenuItem();
			this.mnuScoreImport = new System.Windows.Forms.MenuItem();
			this.btnClearAll = new System.Windows.Forms.Button();
			this.btnCompute = new System.Windows.Forms.Button();
			this.lblSeq = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.lblScore = new System.Windows.Forms.Label();
			this.lblAlign = new System.Windows.Forms.Label();
			this.grpScore = new System.Windows.Forms.GroupBox();
			this.Label6 = new System.Windows.Forms.Label();
			this.txtParticleQty = new System.Windows.Forms.TextBox();
			this.txtMotifLength = new System.Windows.Forms.TextBox();
			this.lblMatch = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.txtSeq1 = new System.Windows.Forms.RichTextBox();
			this.btnExit = new System.Windows.Forms.Button();
			this.btnImport = new System.Windows.Forms.Button();
			this.btnSaveResults = new System.Windows.Forms.Button();
			this.dlgImport = new System.Windows.Forms.OpenFileDialog();
			this.label2 = new System.Windows.Forms.Label();
			this.btnSaveData = new System.Windows.Forms.Button();
			this.dlgSaveData = new System.Windows.Forms.SaveFileDialog();
			this.btnSwarm = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.txtIndiv = new System.Windows.Forms.TextBox();
			this.txtSocial = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.grpScore.SuspendLayout();
			this.SuspendLayout();
			// 
			// txtAlignment
			// 
			this.txtAlignment.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtAlignment.Location = new System.Drawing.Point(8, 272);
			this.txtAlignment.Name = "txtAlignment";
			this.txtAlignment.ShowSelectionMargin = true;
			this.txtAlignment.Size = new System.Drawing.Size(760, 272);
			this.txtAlignment.TabIndex = 4;
			this.txtAlignment.Text = "Motif";
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuSeq,
																					  this.mnuMotif,
																					  this.mnuScore});
			// 
			// mnuSeq
			// 
			this.mnuSeq.Index = 0;
			this.mnuSeq.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.mnuSeqDNA,
																				   this.mnuSeqRNA,
																				   this.mnuSeqAmino});
			this.mnuSeq.Text = "Sequence Type";
			// 
			// mnuSeqDNA
			// 
			this.mnuSeqDNA.Checked = true;
			this.mnuSeqDNA.Index = 0;
			this.mnuSeqDNA.Text = "DNA (nucleotides)";
			this.mnuSeqDNA.Click += new System.EventHandler(this.mnuSeqDNA_Click);
			// 
			// mnuSeqRNA
			// 
			this.mnuSeqRNA.Index = 1;
			this.mnuSeqRNA.Text = "RNA (nucleotides)";
			this.mnuSeqRNA.Visible = false;
			this.mnuSeqRNA.Click += new System.EventHandler(this.mnuSeqRNA_Click);
			// 
			// mnuSeqAmino
			// 
			this.mnuSeqAmino.Index = 2;
			this.mnuSeqAmino.Text = "Amino Acids";
			this.mnuSeqAmino.Visible = false;
			this.mnuSeqAmino.Click += new System.EventHandler(this.mnuSeqAmino_Click);
			// 
			// mnuMotif
			// 
			this.mnuMotif.Index = 1;
			this.mnuMotif.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.mnuMotifEM});
			this.mnuMotif.Text = "Motif Algorithm";
			// 
			// mnuMotifEM
			// 
			this.mnuMotifEM.Checked = true;
			this.mnuMotifEM.Index = 0;
			this.mnuMotifEM.Text = "Expectation-Maximization";
			// 
			// mnuScore
			// 
			this.mnuScore.Index = 2;
			this.mnuScore.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.mnuScoreCustom,
																					 this.mnuScoreBlosum60,
																					 this.mnuScoreBlosum80,
																					 this.mnuScorePam250,
																					 this.mnuScoreImport});
			this.mnuScore.Text = "Scoring Matrix";
			this.mnuScore.Visible = false;
			// 
			// mnuScoreCustom
			// 
			this.mnuScoreCustom.Checked = true;
			this.mnuScoreCustom.Index = 0;
			this.mnuScoreCustom.Text = "Custom Scores";
			this.mnuScoreCustom.Click += new System.EventHandler(this.mnuScoreCustom_Click);
			// 
			// mnuScoreBlosum60
			// 
			this.mnuScoreBlosum60.Enabled = false;
			this.mnuScoreBlosum60.Index = 1;
			this.mnuScoreBlosum60.Text = "Blosum 60 (Amino)";
			this.mnuScoreBlosum60.Click += new System.EventHandler(this.mnuScoreBlosum60_Click);
			// 
			// mnuScoreBlosum80
			// 
			this.mnuScoreBlosum80.Enabled = false;
			this.mnuScoreBlosum80.Index = 2;
			this.mnuScoreBlosum80.Text = "Blosum80 (Amino)";
			this.mnuScoreBlosum80.Click += new System.EventHandler(this.mnuScoreBlosum80_Click);
			// 
			// mnuScorePam250
			// 
			this.mnuScorePam250.Enabled = false;
			this.mnuScorePam250.Index = 3;
			this.mnuScorePam250.Text = "Pam250 (Amino)";
			this.mnuScorePam250.Click += new System.EventHandler(this.mnuScorePam250_Click);
			// 
			// mnuScoreImport
			// 
			this.mnuScoreImport.Index = 4;
			this.mnuScoreImport.Text = "Import Scoring Matrix";
			this.mnuScoreImport.Click += new System.EventHandler(this.mnuScoreImport_Click);
			// 
			// btnClearAll
			// 
			this.btnClearAll.Location = new System.Drawing.Point(336, 216);
			this.btnClearAll.Name = "btnClearAll";
			this.btnClearAll.Size = new System.Drawing.Size(112, 32);
			this.btnClearAll.TabIndex = 7;
			this.btnClearAll.Text = "Clear All";
			this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
			// 
			// btnCompute
			// 
			this.btnCompute.Location = new System.Drawing.Point(192, 216);
			this.btnCompute.Name = "btnCompute";
			this.btnCompute.Size = new System.Drawing.Size(112, 32);
			this.btnCompute.TabIndex = 8;
			this.btnCompute.Text = "Compute Motif";
			this.btnCompute.Click += new System.EventHandler(this.btnCompute_Click);
			// 
			// lblSeq
			// 
			this.lblSeq.Location = new System.Drawing.Point(128, 8);
			this.lblSeq.Name = "lblSeq";
			this.lblSeq.Size = new System.Drawing.Size(160, 23);
			this.lblSeq.TabIndex = 10;
			this.lblSeq.Text = "DNA";
			this.lblSeq.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(112, 23);
			this.label1.TabIndex = 9;
			this.label1.Text = "Sequence Type:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 56);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(112, 23);
			this.label4.TabIndex = 12;
			this.label4.Text = "Scoring Matrix:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label4.Visible = false;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 32);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(112, 23);
			this.label5.TabIndex = 13;
			this.label5.Text = "Motif Algorithm";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lblScore
			// 
			this.lblScore.Location = new System.Drawing.Point(128, 56);
			this.lblScore.Name = "lblScore";
			this.lblScore.Size = new System.Drawing.Size(160, 23);
			this.lblScore.TabIndex = 14;
			this.lblScore.Text = "Custom";
			this.lblScore.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblScore.Visible = false;
			// 
			// lblAlign
			// 
			this.lblAlign.Location = new System.Drawing.Point(128, 32);
			this.lblAlign.Name = "lblAlign";
			this.lblAlign.Size = new System.Drawing.Size(160, 23);
			this.lblAlign.TabIndex = 15;
			this.lblAlign.Text = "Expectation-Maximization";
			this.lblAlign.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// grpScore
			// 
			this.grpScore.Controls.Add(this.label3);
			this.grpScore.Controls.Add(this.txtIndiv);
			this.grpScore.Controls.Add(this.txtSocial);
			this.grpScore.Controls.Add(this.label8);
			this.grpScore.Controls.Add(this.Label6);
			this.grpScore.Controls.Add(this.txtParticleQty);
			this.grpScore.Controls.Add(this.txtMotifLength);
			this.grpScore.Controls.Add(this.lblMatch);
			this.grpScore.Location = new System.Drawing.Point(304, 8);
			this.grpScore.Name = "grpScore";
			this.grpScore.Size = new System.Drawing.Size(456, 80);
			this.grpScore.TabIndex = 22;
			this.grpScore.TabStop = false;
			this.grpScore.Text = "Scoring Paramters";
			// 
			// Label6
			// 
			this.Label6.Location = new System.Drawing.Point(16, 40);
			this.Label6.Name = "Label6";
			this.Label6.Size = new System.Drawing.Size(72, 23);
			this.Label6.TabIndex = 27;
			this.Label6.Text = "Particle Qty:";
			this.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// txtParticleQty
			// 
			this.txtParticleQty.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtParticleQty.Location = new System.Drawing.Point(96, 40);
			this.txtParticleQty.Name = "txtParticleQty";
			this.txtParticleQty.Size = new System.Drawing.Size(48, 22);
			this.txtParticleQty.TabIndex = 26;
			this.txtParticleQty.Text = "5";
			this.txtParticleQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// txtMotifLength
			// 
			this.txtMotifLength.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtMotifLength.Location = new System.Drawing.Point(96, 16);
			this.txtMotifLength.Name = "txtMotifLength";
			this.txtMotifLength.Size = new System.Drawing.Size(48, 22);
			this.txtMotifLength.TabIndex = 25;
			this.txtMotifLength.Text = "4";
			this.txtMotifLength.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// lblMatch
			// 
			this.lblMatch.Location = new System.Drawing.Point(16, 16);
			this.lblMatch.Name = "lblMatch";
			this.lblMatch.Size = new System.Drawing.Size(72, 23);
			this.lblMatch.TabIndex = 22;
			this.lblMatch.Text = "Motif Length:";
			this.lblMatch.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(8, 88);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(176, 16);
			this.label7.TabIndex = 23;
			this.label7.Text = "Database (FASTA format)";
			// 
			// txtSeq1
			// 
			this.txtSeq1.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtSeq1.Location = new System.Drawing.Point(8, 104);
			this.txtSeq1.Name = "txtSeq1";
			this.txtSeq1.Size = new System.Drawing.Size(640, 88);
			this.txtSeq1.TabIndex = 24;
			this.txtSeq1.Text = "richTextBox1";
			// 
			// btnExit
			// 
			this.btnExit.Location = new System.Drawing.Point(616, 216);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(112, 32);
			this.btnExit.TabIndex = 25;
			this.btnExit.Text = "Exit";
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// btnImport
			// 
			this.btnImport.Location = new System.Drawing.Point(656, 104);
			this.btnImport.Name = "btnImport";
			this.btnImport.Size = new System.Drawing.Size(104, 32);
			this.btnImport.TabIndex = 26;
			this.btnImport.Text = "Load Data From File";
			this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
			// 
			// btnSaveResults
			// 
			this.btnSaveResults.Location = new System.Drawing.Point(480, 216);
			this.btnSaveResults.Name = "btnSaveResults";
			this.btnSaveResults.Size = new System.Drawing.Size(112, 32);
			this.btnSaveResults.TabIndex = 27;
			this.btnSaveResults.Text = "Save Results";
			this.btnSaveResults.Click += new System.EventHandler(this.btnSaveResults_Click);
			// 
			// dlgImport
			// 
			this.dlgImport.DefaultExt = "txt";
			this.dlgImport.InitialDirectory = "c:\\";
			this.dlgImport.Title = "Import Database";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 256);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(176, 16);
			this.label2.TabIndex = 28;
			this.label2.Text = "Results";
			// 
			// btnSaveData
			// 
			this.btnSaveData.Location = new System.Drawing.Point(656, 160);
			this.btnSaveData.Name = "btnSaveData";
			this.btnSaveData.Size = new System.Drawing.Size(104, 32);
			this.btnSaveData.TabIndex = 29;
			this.btnSaveData.Text = "Save Data";
			this.btnSaveData.Click += new System.EventHandler(this.btnSaveData_Click);
			// 
			// btnSwarm
			// 
			this.btnSwarm.Location = new System.Drawing.Point(48, 216);
			this.btnSwarm.Name = "btnSwarm";
			this.btnSwarm.Size = new System.Drawing.Size(112, 32);
			this.btnSwarm.TabIndex = 30;
			this.btnSwarm.Text = "Run Swarm";
			this.btnSwarm.Click += new System.EventHandler(this.btnSwarm_Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(164, 41);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(72, 23);
			this.label3.TabIndex = 31;
			this.label3.Text = "Indiv Factor";
			this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// txtIndiv
			// 
			this.txtIndiv.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtIndiv.Location = new System.Drawing.Point(244, 41);
			this.txtIndiv.Name = "txtIndiv";
			this.txtIndiv.Size = new System.Drawing.Size(48, 22);
			this.txtIndiv.TabIndex = 30;
			this.txtIndiv.Text = "1.0";
			this.txtIndiv.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// txtSocial
			// 
			this.txtSocial.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtSocial.Location = new System.Drawing.Point(244, 17);
			this.txtSocial.Name = "txtSocial";
			this.txtSocial.Size = new System.Drawing.Size(48, 22);
			this.txtSocial.TabIndex = 29;
			this.txtSocial.Text = "1.0";
			this.txtSocial.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(164, 17);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(72, 23);
			this.label8.TabIndex = 28;
			this.label8.Text = "Social Factor";
			this.label8.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.ClientSize = new System.Drawing.Size(792, 553);
			this.Controls.Add(this.btnSwarm);
			this.Controls.Add(this.btnSaveData);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.btnSaveResults);
			this.Controls.Add(this.btnImport);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.txtSeq1);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.grpScore);
			this.Controls.Add(this.lblAlign);
			this.Controls.Add(this.lblScore);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.lblSeq);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnCompute);
			this.Controls.Add(this.btnClearAll);
			this.Controls.Add(this.txtAlignment);
			this.Menu = this.mainMenu1;
			this.Name = "frmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Motif Swarm Algorithm";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.frmMain_Load);
			this.grpScore.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		private void mnuSeqDNA_Click(object sender, System.EventArgs e)
		{
			lblSeq.Text = "DNA";
			lblMatch.Visible = true;
			mnuSeqDNA.Checked = true;
			mnuSeqAmino.Checked = false;
			mnuSeqRNA.Checked = false;
			mnuScoreBlosum60.Enabled = false;
			mnuScoreBlosum80.Enabled = false;
			mnuScorePam250.Enabled = false;
			mnuScoreCustom.Enabled = true;
			mnuScoreImport.Enabled = true;
		}

		private void mnuSeqAmino_Click(object sender, System.EventArgs e)
		{
			lblSeq.Text = "Amino Acids";
			mnuSeqDNA.Checked = false;
			mnuSeqAmino.Checked = true;
			mnuSeqRNA.Checked = false;
			mnuScoreBlosum60.Enabled = true;
			mnuScoreBlosum80.Enabled = true;
			mnuScorePam250.Enabled = true;
			mnuScoreCustom.Enabled = true;
			mnuScoreImport.Enabled = true;
			mnuScorePam250_Click(sender, e);
		}

		private void mnuSeqRNA_Click(object sender, System.EventArgs e)
		{
			lblSeq.Text = "DNA";
			lblMatch.Visible = true;
			lblSeq.Text = "RNA";
			mnuSeqDNA.Checked = false;
			mnuSeqAmino.Checked = false;
			mnuSeqRNA.Checked = true;
			mnuScoreBlosum60.Enabled = false;
			mnuScoreBlosum80.Enabled = false;
			mnuScorePam250.Enabled = false;
			mnuScoreCustom.Enabled = true;
			mnuScoreImport.Enabled = true;		
		}

		private void mnuScoreCustom_Click(object sender, System.EventArgs e)
		{
			lblScore.Text = "Custom Settings";
			mnuScoreCustom.Checked = true;
			mnuScoreBlosum60.Checked = false;
			mnuScoreBlosum80.Checked = false;
			mnuScorePam250.Checked = false;
			mnuScoreImport.Checked = false;
			lblMatch.Visible = true;
		}

		private void mnuScorePam1Amino_Click(object sender, System.EventArgs e)
		{
			lblScore.Text = "PAM1 (Amino)";
			mnuScoreCustom.Checked = false;
			mnuScorePam250.Checked = false;
			lblMatch.Visible = false;
		}

		private void mnuScorePam250_Click(object sender, System.EventArgs e)
		{
			lblScore.Text = "PAM250";
			mnuScoreCustom.Checked = false;
			mnuScoreBlosum60.Checked = false;
			mnuScoreBlosum80.Checked = false;
			mnuScorePam250.Checked = true;
			mnuScoreImport.Checked = false;
			lblMatch.Visible = false;
		}

		private void mnuScoreBlosum60_Click(object sender, System.EventArgs e)
		{
			lblScore.Text = "BLOSUM-60";
			mnuScoreCustom.Checked = false;
			mnuScoreBlosum60.Checked = true;
			mnuScoreBlosum80.Checked = false;
			mnuScorePam250.Checked = false;
			mnuScoreImport.Checked = false;
			lblMatch.Visible = false;
		}

		private void mnuScoreImport_Click(object sender, System.EventArgs e)
		{
			lblScore.Text = "USER MATRIX";
			mnuScoreCustom.Checked = false;
			mnuScoreBlosum60.Checked = false;
			mnuScoreBlosum80.Checked = false;
			mnuScorePam250.Checked = false;
			mnuScoreImport.Checked = true;
			lblMatch.Visible = false;
            Utilities.ImportScore(out scoreMatrix, out scoreHeadings, out matrixName);
		}

		private void mnuScoreBlosum80_Click(object sender, System.EventArgs e)
		{
			lblScore.Text = "BLOSUM-80";
			mnuScoreCustom.Checked = false;
			mnuScoreBlosum60.Checked = true;
			mnuScoreBlosum80.Checked = false;
			mnuScorePam250.Checked = false;
			mnuScoreImport.Checked = false;
			lblMatch.Visible = false;
		}

		private void btnCompute_Click(object sender, System.EventArgs e)
		{
			Sequence seq1;
			string seqType;

			if (mnuSeqDNA.Checked == true ) seqType = "DNA";
			else if (mnuSeqRNA.Checked == true ) seqType = "RNA";
			else  seqType = "AMINO";

			Database db = new Database(txtSeq1.Text, seqType);
			if (db.SeqCount <= 0)
			{
				MessageBox.Show("ERROR - Error in Database Sequence.\nUnable to detect a valid sequence.");
				return;
			}
			alignDisplay = new string[db.SeqCount];
			alignScore = new int[db.SeqCount];
			sigScore = new double[db.SeqCount];
			for (int i = 0; i < db.SeqCount; i++)
			{
				seq1 = new Sequence(db.Sequences[i], seqType);	
				string seq1ID = db.IDs[i];
				if (seq1.IsValid == false)
				{
					MessageBox.Show("ERROR - Error in Database Seqeunce");
					return;
				}
			}
			txtAlignment.Text = "Expectation-Maximization Algorithm   (run: ";
            txtAlignment.Text += (DateTime.Now + ")\n\n");
			txtAlignment.Text += "Sequence Identification:\n";
			for (int i = 0; i < db.SeqCount; i++)
			{
				txtAlignment.Text += String.Format("\tSeq {0:0000}: {1}\n",i,db.IDs[i]) ;
			}
			txtAlignment.Text += "\n\nMotif: \n";
			Motif myMotif = new Motif(db, Int32.Parse(txtMotifLength.Text) );
			string s = txtAlignment.Text + myMotif.OutputText;
			txtAlignment.Text += myMotif.OutputText;
			s = " ";
		}

		private void btnClearAll_Click(object sender, System.EventArgs e)
		{
			txtSeq1.Text = "";
			txtAlignment.Text = "";
		}

		private void btnExit_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void btnImport_Click(object sender, System.EventArgs e)
		{
			dlgImport.DefaultExt = "txt";
			if(dlgImport.ShowDialog() == DialogResult.OK)
			{
				System.IO.StreamReader sr = new 
					System.IO.StreamReader(dlgImport.FileName);
				//MessageBox.Show(sr.ReadToEnd());
				txtSeq1.Text = sr.ReadToEnd();
				sr.Close();
			}
		}

		private void btnSaveData_Click(object sender, System.EventArgs e)
		{   
			// Initialize the SaveFileDialog to specify the RTF extension for the file.
			dlgSaveData.DefaultExt = "*.txt";
			dlgSaveData.Filter = "Text Files|*.txt|RTF Files|*.rtf";

			// Determine if the user selected a file name from the saveFileDialog.
			if(dlgSaveData.ShowDialog() == System.Windows.Forms.DialogResult.OK &&
				dlgSaveData.FileName.Length > 0) 
			{
				// Save the contents of the RichTextBox into the file.
				txtSeq1.SaveFile(dlgSaveData.FileName, RichTextBoxStreamType.PlainText);
			}
		}

		private void btnSaveResults_Click(object sender, System.EventArgs e)
		{
		}

		private void btnSwarm_Click(object sender, System.EventArgs e)
		{
			//Sequence seq1;
			string seqType;
			this.txtAlignment.Text = "working...";

			if (mnuSeqDNA.Checked == true ) seqType = "DNA";
			else if (mnuSeqRNA.Checked == true ) seqType = "RNA";
			else  seqType = "AMINO";

			Database db = new Database(txtSeq1.Text, seqType);
			if (db.SeqCount <= 0)
			{
				MessageBox.Show("ERROR - Error in Database Sequence.\nUnable to detect a valid sequence.");
				return;
			}
			mySwarm = new Swarm(db, Int32.Parse(txtParticleQty.Text), Int32.Parse(txtMotifLength.Text),
				Double.Parse(txtSocial.Text), Double.Parse(txtIndiv.Text));
			this.txtAlignment.Text = mySwarm.outputString;

		}

		private void frmMain_Load(object sender, System.EventArgs e)
		{
			this.Width = Screen.PrimaryScreen.WorkingArea.Width;
			this.Height = Screen.PrimaryScreen.WorkingArea.Height;
			this.txtAlignment.Width = (int)(this.Width*.9);
			this.txtAlignment.Height = (int)(this.Height *.95 - 300);
		
		}
	}
}
