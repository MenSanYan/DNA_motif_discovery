using System;

namespace SeqAlign
{
	/// <summary>
	/// 
	/// </summary>
	public class Motif
	{
		private Sequence [] mySeq;			// an array of sequences in this dataset
		private bool DNA, RNA, AMINO;		// denotes the type of sequence
		private int mLength;				// length of the motif in this dataset
		private int [] charCount;			// count of characters in all datasets		
		private double oldScore, newScore;
		private int [] myMotif;				// array of motif starting indexes
		private int [] oldMotif;
        private int [,] freqTable;			// frequency table
		private double [,] oddsTable;		// odds table
		private string display;				// string suitable for displaying results
		private double [] bitScore;
		private Database myDB;
		char[] alphabet;

		public Motif()
		{
		}

		public Motif( Database db, int motifLength )
		{
			DNA = RNA = AMINO = false;
			//mySeq = seq;
			myDB = db;
			
			if ( myDB.Type.ToUpper() == "DNA" ) DNA = true;
			else if ( myDB.Type.ToUpper() == "RNA" ) RNA = true;
			else if ( myDB.Type.ToUpper() == "AMINO" ) AMINO = true;
			mySeq = new Sequence[myDB.SeqCount];
			for (int i = 0; i < myDB.SeqCount; i++ )
			{
				Sequence temp = new Sequence(myDB.Sequences[i], myDB.Type);
				mySeq[i] = temp;
			}



			mLength = motifLength;
			myMotif = new int[mySeq.Length];
			initializeVariables();
			initializeMotif();
			charCount = countCharacters();
			oldMotif = myMotif;
			oldScore = double.MinValue/2;
			myMotif = updateMotif(oldMotif, out newScore);
			while (newScore - oldScore >.01)
			{
				oldScore = newScore;
				oldMotif = myMotif;
				myMotif = updateMotif( oldMotif, out newScore );
			}
			display = formatOutput();
		}

		private string formatOutput()
		{
			int maxLength = 0, maxPad=0;
			foreach( int i in myMotif )
			{
				if ( i > maxPad) 
					maxPad = i;
			}
			for (int i = 0; i < mySeq.Length; i++)
			{
				if (mySeq[i].Length > maxLength) 
					maxLength = mySeq[i].Length;
			}
			char [,] result = new char [mySeq.Length,maxLength+maxPad];
			for (int row = 0; row < mySeq.Length; row++)
			{
				for (int col = 0; col < mySeq[row].Length; col++)
				{
					result[row,col] = char.ToLower(mySeq[row].Residue(col));
				}
				for (int col = myMotif[row]; col < myMotif[row]+mLength; col++)
				{
					result[row,col] = char.ToUpper(result[row,col]);
				}
				int pad = maxPad - myMotif[row];
				for (int col = mySeq[row].Length-1; col >= 0; col-- )
				{
					result[row,col+pad] = result[row,col];
				}
				for (int col = mySeq[row].Length; col < maxLength+maxPad; col++)
				{
					if (result[row,col] == '\0')
						result[row,col] = ' ';
				}
				for (int col = 0; col < pad; col++ )
				{
					result[row,col] = ' ';
				}
			}
			string s = "";
			for (int row = 0; row < mySeq.Length; row++)
			{
				s = s + String.Format("\tSeq {0:0000}: ",row ) ;
				for (int col = 0; col < mySeq[row].Length+maxPad; col++)
				{
					s += result[row,col].ToString();
				}
				s += String.Format("\tbit score = {0:###0.00\n}",bitScore[row]);
			}
			s += String.Format("Total score = {0:###0.00\n}",newScore);
			return s;
		}

		private int[] updateMotif( int[] motif, out double score )
		{
			double nextScore;
			int[] nextMotif = new int [motif.Length];
			freqTable = buildFreqTable(motif);
			addPseudoCounts();
			oddsTable = buildOddsTable();
			nextMotif = optimizeMotif (motif, out nextScore);
			score = nextScore;
			return nextMotif;
		}

		private int[] optimizeMotif( int []motif, out double score )
		{
			bitScore = new double [mySeq.Length];
			int[] nextMotif = new int [motif.Length];
			score = 0;
			int loc = 0;
			double temp;
			for (int s = 0; s < mySeq.Length; s++)
			{
				double max = double.MinValue/2;
				for ( int p = 0; p < mySeq[s].Length-mLength+1; p++)
				{
					temp = motifScore(s,p);
					if ( temp > max )
					{
						loc = p;
						max = temp;
					}
				}
				score += max;
				nextMotif[s] = loc; 
				bitScore[s] = max;
			}		
			return nextMotif;
		}

		private double motifScore ( int seq, int begPos )
		{
			double motifScore = 1;
			double randScore = 1;
			for (int c = 0; c  < mLength; c ++)
			{
				int pos = c + begPos;
				for (int r = 0; r < alphabet.Length; r++)
				{
					if ( mySeq[seq].Residue(pos) == alphabet[r] )
					{
						motifScore *= oddsTable[r,c+1];
						randScore *= oddsTable[r,0];
						break;
					}
				}
			}
			return Math.Log(motifScore/randScore,2.0);
		}

		private double totalScore ( int[] motif )
		{
			double score = 0;
			for (int i = 0; i < mySeq.Length; i++)
			{
				score += motifScore(i, motif[i] );
			}
			return score;
		}

		private double[,] buildOddsTable()
		{
			double [,] table = new double [alphabet.Length, mLength+1];
			int sRow = alphabet.Length;
			for( int col = 0; col < mLength+1; col++ )
			{
				double divisor = (double) freqTable[sRow,col];
				for (int row = 0; row < alphabet.Length; row++)
				{
					table[row,col] = ( (double)freqTable[row,col] ) / divisor;
				}
			}
			return table;
		}

		private int maxLocation()
		{
			return 0;
		}

		private void initializeVariables()
		{
			if (DNA == true)
			{
				alphabet = "ACGT".ToCharArray();
				freqTable = new int[5,mLength+1];
				oddsTable = new double[5,mLength+1];
		}
			else if (RNA == true)
			{
				alphabet = "ACGU".ToCharArray();
				freqTable = new int[5,mLength+1];
				oddsTable = new double[5,mLength+1];
			}
			else if (AMINO == true)
			{
				alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
				freqTable = new int[27,mLength+1];
				oddsTable = new double[27,mLength+1];
			}
			else // error condition
			{
				alphabet = "".ToCharArray();
			}
		}
		private void initializeMotif()
		{
			Random r = new Random(DateTime.Now.Millisecond);
			for (int i = 0; i < mySeq.Length; i++ )
			{
				myMotif[i] = r.Next(0,mySeq[i].Length - mLength);
				//myMotif[i] = 1;
			}
		}

		private int[] countCharacters()
		{
			int [] count = new int [alphabet.Length];
			for (int s = 0; s < mySeq.Length; s++) // for each sequence in the database
			{
				for (int c = 0; c < mySeq[s].Length; c++) // for each character in a sequence
				{
					for (int a = 0; a < alphabet.Length; a++)	// for each character in the alphabet
					{
						if ( mySeq[s].Residue(c) == alphabet[a] )
						{
							count[a]++;
							break;
						}
					}
				}
			}
			return count;
		}
		private int[,] buildFreqTable(int [] motif)
		{
			int loc;
			int [,] table = new int [5,mLength+1];
			// calcualte counts in each position of the current motif
			for (int s = 0; s < mySeq.Length; s++) 
			{
				for (int pos = 0; pos < mLength; pos++) 
				{
					loc = pos + motif[s];
					for (int a = 0; a < alphabet.Length; a++)	
					{
						if ( mySeq[s].Residue(loc) == alphabet[a] )
						{
							table[a,pos+1]++;
							break;
						}
					}
				}
			}

			// calculate background counts
			for (int i = 0; i < alphabet.Length; i ++) 
			{
				table[i,0] = charCount[i];
				for (int p = 0; p < mLength; p++)
				{
					table[i,0] -= table[i,p+1];
				}
			}

			// calculate column sums
			for (int col = 0; col < mLength+1 ; col++)
			{
				for (int row = 0; row < alphabet.Length; row ++)
				{
					table [alphabet.Length, col] += table[row,col];
				}
			}
			return table;
		}

		private void addPseudoCounts()
		{
			for (int col = 0; col < mLength+1; col++ )
			{
				for (int row = 0; row < alphabet.Length; row++)
				{
					freqTable[row,col] ++;
					freqTable[alphabet.Length,col]++;	// increment the totals row
				}
			}
		}

		public string OutputText
		{
			get
			{
				return this.display;
			}
		}
	}
}
