/* 
 * PRNG.H
 * Interface to the Mersenne Twistor PRNG
 *****************************************************************************
 * Projection Genomics Toolkit
 * Copyright (C) 2000-2003 by Jeremy Buhler, all rights reserved.
 * For licensing terms, please see the accompanying LICENSE file.
 * For information and bug reports, please contact jbuhler@cse.wustl.edu.
 *****************************************************************************
 */

#ifndef __PRNG_H
#define __PRNG_H

#ifdef __cplusplus
extern "C" {
#endif
  void init_genrand(unsigned long s);
  
  /* random integers */
  unsigned long genrand_int32(void);  /* [0 .. 2^32) */
  long genrand_int31(void);           /* [0 .. 2^31) */
  
  /* random FP w/32 bits of randomness in mantissa */
  double genrand_real1(void);  /* [0 .. 1] */
  double genrand_real2(void);  /* [0 .. 1) */
  double genrand_real3(void);  /* (0 .. 1) */

  /* random FP w/53 bits of randomness in mantissa */
  double genrand_res53(void);  /* [0 .. 1) */

#ifdef __cplusplus
}
#endif

#endif
