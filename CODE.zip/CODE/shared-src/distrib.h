/*
 * DISTRIB.H
 * Calculate the densities and cumulative probabilities associated with
 * various common distributions.  The first parameter of each function is
 * the distribution value; other parameters specify aspects of the
 * distribution being calculated.  All cumulative probabilities cover the
 * range from the lower limit of the distribution (0 or -Inf as
 * appropriate) to the specified value.
 *
 * NOTE: code which uses these functions must be linked with libm.
 */

#ifndef __distrib_h
#define __distrib_h

#ifdef __cplusplus
extern "C" {
#endif

/* P routines are based on the incomplete gamma function */
double Pnorm(double x);          /* standard normal */
double Dnorm(double x);

/* macros for nonstandard normal */
#define PZnorm(mean, stddev, x) ( Pnorm( ((x) - (mean)) / (stddev) ) )
#define DZnorm(mean, stddev, x) ( Dnorm( ((x) - (mean)) / (stddev) )/(stddev) )

double Pchisq(double x, int df);   /* chi square with df degrees of freedom */
double Dchisq(double x, int df);

double Ppoisson(int k, double mean); /* Poisson with mean m */
double Dpoisson(int k, double mean);

/* P routines are based on the incomplete beta function */
double Pstudent(double x, int df);     /* Student's T with df degrees free */
double Dstudent(double x, int df);

double PF(double x, int df1, int df2); /* F with df1 and df2 degrees free */
double DF(double x, int df1, int df2);

double Pbinom(int k, int N, double p); /* binomial(N,p) */
double Dbinom(int k, int N, double p); 

/* 
 * The log of the gamma function is useful for computing
 * large factorials, permutations and combinations, etc.
 * This implementation is defined for any a >= 0 but is accurate 
 * only for a = 0.5 and a >= 1. 
 */
double log_gamma(double a);

/* log(x!) */
#define lfact(x) ( log_gamma(x + 1.0) )

#ifdef __cplusplus
}
#endif

#endif
