//
// SEQIO.H
// Routines for reading FASTA-formatted DNA sequences
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __SEQIO_H
#define __SEQIO_H

#include <iostream>
#include <stdio.h>
#include "seqinfo.h"
#include "vector.h"

SeqVector readSequencesFromStream(std::istream &is,
				  const Alphabet *alphabet,
				  const SeqNumVector reversals,
				  SeqNumber firstSeqNum);

#endif
