//
// SEQIO.CC
// Routines for reading FASTA_formatted DNA sequences
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cctype>

#include "seqio.h"

using namespace std;

const char FASTA_START_CHAR = '>';        // this char starts FASTA seqs

//
// local prototypes
//
static void readFASTASequence(istream &, SeqInfo *);
static void readRawSequence(istream &, SeqInfo *);
static char *readTitle(istream &);


//
// readSequencesFromStream()
// Read FASTA-formatted sequences from a stream, numbering them
// consecutively starting with firstSeqNum. Every sequence whose number
// is in the vector 'reversals' is reverse-complemented, and its
// 'complement' field is set.
//
// RETURNS: vector of all sequences read.  If an error occurred
// or no sequences were read, the vector will be empty.
//
SeqVector readSequencesFromStream(istream &is,
				  const Alphabet *alphabet,
				  const SeqNumVector reversals,
				  SeqNumber firstSeqNum)
{
  SeqNumber nextReversedIdx = 0;
  SeqVector seqs;
  
  for (SeqNumber seqNum = firstSeqNum; /* loop forever */; seqNum++)
    {
      SeqInfo info;
      
      info.alphabet = alphabet;
      
      if (!alphabet->isProtein())
	{
	  // Find the index of the next sequence to reverse (if any).
	  while (nextReversedIdx < reversals.length() &&
		 reversals[nextReversedIdx] < seqNum)
	    nextReversedIdx++;
	  
	  // Are we supposed to reverse-complement the current sequence?
	  if (nextReversedIdx < reversals.length())
	    info.complement = (seqNum == reversals[nextReversedIdx]);
	  else
	    info.complement = false;
	}
      else
	info.complement = false;
      
      info.seqNum = seqNum;
      readFASTASequence(is, &info);
      
      if (!info.data) // reached EOF
	break;
      else
	seqs.add(info);
    }
  
  return seqs;
}


//
// readFASTASequence()
// Read a complete FASTA sequence from is.  The sequence begins
// begin with an optional title line '> title...', followed by
// one or more lines of DNA sequence.  If the boolean condition
// info->complement is true, the sequence is reverse-complemented.
//
// We allow the following extensions:
//
//  1. There may be arbitrary whitespace (space, tab, EOL) before the
//     beginning of the sequence.
//  2. The sequence may have no title line, in which case we
//     return an empty string for the title.
//
// SETS: info->data   to sequence read, or NULL if EOF before start
//       info->length to length read
//       info->title  to sequence title (or empty string if none)
//
static void readFASTASequence(istream &is, SeqInfo *info)
{
  bool foundTitle = false;
  int nextChar;
  
  // Set these to sane values in case we hit EOF.
  info->data   = NULL;
  info->length = 0;
  info->title  = NULL;
  
  // Consume whitespace up to either EOF, title start character,
  // or sequence start.  Save the title if it is found.
  //
  while (!foundTitle)
    {
      nextChar = is.peek();
      switch (nextChar)
	{
	case EOF:
	  return;
	  
	case FASTA_START_CHAR:
	  is.get();
	  
	  // read to EOL and save as title string
	  info->title = readTitle(is);
	  foundTitle = true;
	  break;
	  
	default:
	  if (isspace(nextChar)) // consume if whitespace
	    is.get();
	  else                   // sequence starts with no title
	    {
	      // create empty title
	      char *title = new char [1];
	      title[0] = 0;
	      info->title = title;
	      foundTitle = true;
	    }
	  break;
	}
    }
  
  // read the raw sequence data
  readRawSequence(is, info);
}


//////////////////////////////////////////////////////////////////////////////
// Low-level sequence I/O
//////////////////////////////////////////////////////////////////////////////

const int BUFSIZE = 256;  // max line size to read at once

// information from one line of a sequence
struct Str {
  char *data;
  size_t length;
};
typedef Vector<Str> StrVector;


//
// readResidue()
// Map an input character to a residue according to the
// specified Alphabet.  Replace unknown chars, gaps, and 
// multiresidue wildcards with the X character.
// Complain about unknown characters or gaps.
//
inline Residue readResidue(const Alphabet *a, char c)
{
  Residue r = a->fromChar(c);
      
  if (r == Alphabet::INVALID_CHAR)
    {
      if (c == '-')
	cerr << "Warning: sequence contains gaps of unknown length!\n";
      else
	cerr << "Warning: unknown sequence character '" << c << "'\n";
    
      r = Alphabet::RESIDUE_X;
    }
  
  return r;
}


//
// readRawSequence()
// Read raw DNA data sequence from a stream.  If info->complement is false,
// return the sequence; otherwise, return its reverse complement.
// The sequence will be converted to Residues, and chars other
// than the known residues will be converted to the X residue for
// the sequence's alphabet.
//
// SETS: info->data to sequence read
//       info->length to sequence length 
//
static void readRawSequence(istream &is, SeqInfo *info)
{
  unsigned int nRealResidues = info->alphabet->nRealResidues(); 
  SeqLength unmaskedLength = 0;
  double *freqs = info->freqs;
  char buf[BUFSIZE + 1];
  StrVector lines;
  size_t seqLength;
  
  // Initialize the array of frequencies.
  for (Residue r = 0; r < info->alphabet->nResidues(); r++)
    freqs[r] = 1.0 / info->alphabet->nRealResidues();
  
  // Read the sequence into a vector of lines, stopping when we reach
  // EOF or hit a stop character.
  seqLength = 0;
  do
    {
      int nextChar = is.peek();
      bool stop = false;
      
      // Stop reading if the next char begins a new FASTA sequence, if
      // it is whitespace (not allowed inside a seq -- assume
      // a new seq has started), or if we have reached EOF.
      //
      switch(nextChar)
	{
	case FASTA_START_CHAR:
	case EOF:
	  stop = true;
	  break;
	  
	default:
	  stop = isspace(nextChar);
	  break;
	}
      
      if (stop)
	break;
      
      // Read the next line and trim off any trailing blanks.
      is.get(buf, BUFSIZE + 1);
      if (is.peek() == '\n') is.get();  // eat the EOL if any
      
      size_t slen = strlen(buf);
      while (slen > 0 && isspace(buf[slen - 1]))
	{
	  buf[slen - 1] = 0;
	  slen--;
	}
      
      // Save a copy of this line.
      if (slen > 0)
	{
	  Str str;
	  str.length = slen;
	  str.data = new char [slen + 1];
	  strcpy(str.data, buf);
	  
	  lines.add(str);
	  seqLength += slen;
	}
    }
  while (!is.eof());
  
  // allocate a single string for the sequence
  Residue *seq = new Residue [seqLength];
  if (!seq)
    {
      cerr << "Could not allocate buffer of size "
	   << seqLength + 1 << " for sequence\n";
      exit(3);
    }
  
  const Alphabet *a = info->alphabet;
  
  // If lines.length() == 0, the following is a no-op.
  if (info->complement)
    {
      // Concatenate the strings in reverse order, complementing
      // each character as it is read.  Delete each string from temporary
      // storage as it is concantenated.
      //
      size_t strPtr = seqLength - 1;
      for (unsigned int j = 0; j < lines.length(); j++)
	{
	  Str *line = &(lines[j]);
	  
	  for (size_t c = 0; c < line->length; c++)
	    {
	      Residue r = a->complement(readResidue(a, line->data[c]));
	      seq[strPtr--] = r;	      
	      freqs[r]++;
	      unmaskedLength += (r != Alphabet::RESIDUE_X);
	    }

	  delete [] line->data;
	}
    }
  else
    {
      // Concatenate the strings in the order they were read. Delete each
      // string from temporary storage as it is concatenated.
      //
      size_t strPtr = 0;
      for (unsigned int j = 0; j < lines.length(); j++)
	{
	  Str *line = &(lines[j]);
	  
	  for (size_t c = 0; c < line->length; c++)
	    {
	      Residue r = readResidue(a, line->data[c]);
	      seq[strPtr++] = r;
	      freqs[r]++;
	      unmaskedLength += (r != Alphabet::RESIDUE_X);
	    }
	  
	  delete [] line->data;
	}
    }
  
  // We happily read in sequences of any length, but
  // we can't necessarily process them.  Thus, we explicitly
  // cast the (possibly huge) seqLength down to type SeqLength.
  //
  info->length = SeqLength(seqLength);
  info->data   = seq;
  info->unmaskedLength = unmaskedLength;
  
  freqs[Alphabet::RESIDUE_X] = 0.0;
  
  for (Residue r = 1; r <= nRealResidues; r++)
    freqs[r] /= (double(unmaskedLength) + 1.0);
}


//
// readTitle()
// Read and return a single line's worth of title data from a stream.
//
static char *readTitle(istream &is)
{
  char buf[BUFSIZE + 1];
  StrVector lines;
  size_t length;
  
  length = 0;
  do
    {
      is.get(buf, BUFSIZE + 1);
      size_t linelen = strlen(buf);
      
      while (linelen > 0 && isspace(buf[linelen - 1]))
	{
	  buf[linelen - 1] = 0;
	  linelen--;
	}
      
      // Save a copy of this line.
      if (linelen > 0)
	{
	  Str str;
	  str.length = linelen;
	  str.data = new char [linelen + 1];
	  strcpy(str.data, buf);
	  
	  lines.add(str);
	  length += linelen;
	}
      
      
      if (is.peek() == '\n')  // at EOL
	{
	  is.get();
	  break;
	}
    }
  while (!is.eof());
  
  char *title = new char [length + 1];
  if (!title)
    {
      cerr << "Could not allocate buffer of size "
	   << length + 1 << " for title\n";
      exit(3);
    }
  title[length] = 0;
  
  // Concatenate the strings in the order they were read.
  // Delete each string from temporary storage as it is concatenated.
  //
  size_t strPtr = 0;
  for (unsigned int j = 0; j < lines.length(); j++)
    {
      Str *line = &(lines[j]);
      memcpy(title + strPtr, line->data, line->length);
      strPtr += line->length;
      delete [] line->data;
    }
  
  return title;
}
