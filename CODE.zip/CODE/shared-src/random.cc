//
// RANDOM.CC
// Utility functions based on supplied PRNG
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2003 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <sys/time.h>

#include "random.h"

void seedPRNG(long seed)
{
  if (seed < 0)
    {
      struct timeval tv; 
      struct timezone tz;
      
      gettimeofday(&tv, &tz);
      
      seed = tv.tv_usec + 37 * tv.tv_sec;
    }
  
  init_genrand(seed);
}
