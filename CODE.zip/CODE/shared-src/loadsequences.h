//
// LOADSEQUENCES.H
// Load sequences from command line
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __LOADSEQUENCES_H
#define __LOADSEQUENCES_H

#include "seqinfo.h"

SeqVector loadSequences(int argc, char *argv[],
			const char *specificOptions,
			bool loadAnnotations = true);

// user-provided callback from loadSequences(), which processes the
// argument list to handle any generic sequence-related args
extern void handleArgument(int optchar, const char *optarg);

// print usage info for sequence options
void printSequenceUsage(void);

#endif
