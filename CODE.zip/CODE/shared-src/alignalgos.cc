//
// ALIGNALGOS.CC
// Variants of Smith-Waterman alignment
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <cstdlib>

#include "alignalgos.h"

using namespace std;

//
// alignUngappedLocal()
// Find the score and endpoints of an optimal ungapped local
// alignment in the segment beginning at s1 in sequence 1, s2 in
// sequence 2, and running for length len.  We try heuristically to
// keep the alignment as long as possible but do not guarantee that
// the longest optimal alignment is returned.
//
// We use the obvious ungapped simplification of Smith-Waterman.
//
// ARGUMENTS
//   * pointers to sequences being aligned
//   * substitution score matrix
//   * starting point and length of the segment to explore
//   * ref for result structure
//
// RETURNS
//   * score of alignment
//   * score and endpoints of alignment in result structure
//
ScoreT alignUngappedLocal(const Residue *iseq1, const Residue *iseq2, 
			  const ScoreMatrix &M,
			  SeqPosn s1, SeqPosn s2, SeqLength len,
			  Alignment &result)
{
  const Residue *seq1 = iseq1 + s1, *seq2 = iseq2 + s2;
  
  ScoreT optSuffixScore  = 0;
  SeqPosn optSuffixStart = 0;
  
  ScoreT optSegmentScore  = optSuffixScore;
  SeqPosn optSegmentStart = optSuffixStart;
  SeqPosn optSegmentEnd   = 0;
  
  // For each j, compute the score of the highest-scoring suffix of
  // the aligned segment [0..j].  When the score falls below 0,
  // the best suffix becomes the empty one.
  //
  // The optimal segment score in [0..j] is the max over all optimal
  // suffix scores.
  //
  // Try to keep the alignment as long as possible by not truncating
  // suffixes with a score of 0, and by setting the segment's end
  // as late as possible.
  //
  for (unsigned int j = 0; j < len; j++)
    {
      optSuffixScore += M[seq1[j]][seq2[j]];
      
      if (optSuffixScore < 0)  // truncate this suffix?
        {
          optSuffixScore =   0;
          optSuffixStart = j+1;
        }
      else if (optSuffixScore >= optSegmentScore)
        {
          optSegmentScore = optSuffixScore;
          optSegmentStart = optSuffixStart;
          optSegmentEnd   = j;
        }
    }
  
  result.setEndpoints(optSegmentStart + s1, optSegmentEnd + s1,
		      optSegmentStart + s2, optSegmentEnd + s2);
  result.setScore(optSegmentScore);
  
  return optSegmentScore;
}


//
// alignUngappedBlast()
// Find the score and endpoints of an optimal ungapped local
// alignment, starting from an initial ungapped Match (that
// supplies the alignment's frame) and limited to the interval
// [s2..e2] in sequence 2 (and the corresponding interval in
// sequence 1).
//
// We use NCBI BLAST's iterative procedure for turning hits into
// HSP's to determine what portion of the original match forms
// the "center" of the alignment and how far to search along
// the diagonal in each direction.
//
// NOTE: this version of the procedure is slightly pessimized versus
// that found in the NCBI BLAST source code, but it should be
// functionally equivalent (and more readable!).
//
// ARGUMENTS
//   * pointers to sequences being aligned
//   * substitution score matrix
//   * initial Match that seeds alignment
//   * endpoints of interval over which to extend
//   * max allowable X-drop: halt extension in a given dir if
//     the alignment score falls XDrop below the current
//     optimal value
//   * ref for result structure
//
// RETURNS
//   * score of alignment
//   * score and endpoints of alignment in result structure
//
ScoreT alignUngappedBlast(const Residue *iseq1, const Residue *iseq2,
			  const ScoreMatrix &M, const Match &match,
			  SeqPosn s2, SeqPosn e2,
			  ScoreT XDrop, Alignment &result)
{
  const Residue *seq1 = iseq1 - match.frame();
  const Residue *seq2 = iseq2;
  
  SeqPosn aLeft  = 0;
  SeqPosn aRight = 0;
  ScoreT  aScore = 0;
  
  // Step 1: determine highest-scoring interval [aLeft .. aRight] within the 
  // initial Match.  Assume that *some* such interval is positive, else
  // aLeft and aRight will not be set.
  {
    ScoreT  score = 0;
    SeqPosn start = match.low(1);
    
    for (SeqPosn j = match.low(1); j < match.low(1) + match.length(); j++)
      {
	score += M[ seq1[j] ][ seq2[j] ];
	
	if (score > aScore)
	  {
	    aScore = score;
	    aLeft  = start;
	    aRight = j;
	  }
	else if (score <= 0)
	  {
	    score = 0;
	    start = j+1;
	  }
      }
  }
  
  ScoreT maxDrop = MAX(-aScore, XDrop);
  
  // Step 2: extend the alignment to left and right.  We stop
  // extending to the left when the score of the interval
  // [left..aRight] either drops to zero (delta == -score) or falls 
  // by at least X.  A similar rule applies to the right extension.
  //
  // Since each direction's extension can change the overall
  // alignment score, and hence the drop threshold for stopping,
  // we iterate trying both extensions until no further
  // improvement occurs for either.
  //
  ScoreT leftDelta = 0, rightDelta = 0;
  SeqPosn left = aLeft, right = aRight;
  ScoreT prevScore = 0;
  
  while (aScore > prevScore)
    {
      // Extend to the left...
      
      while (leftDelta >= maxDrop && left > s2)
	{
	  left--;
	  leftDelta += M[ seq1[left] ][ seq2[left] ];
	  
	  if (leftDelta > 0) // found a new optimum endpoint!
	    {
	      aLeft   = left;
	      aScore += leftDelta;
	      maxDrop = MAX(-aScore, XDrop);
	      
	      leftDelta = 0;
	    }
	}
      
      prevScore = aScore;
      
      // ... and to the right.
      
      while (rightDelta >= maxDrop && right < e2)
	{
	  right++;
	  rightDelta += M[ seq1[right] ][ seq2[right] ];
	  
	  if (rightDelta > 0)
	    {
	      aRight  = right;
	      aScore += rightDelta;
	      maxDrop = MAX(-aScore, XDrop);
	      
	      rightDelta = 0;
	    }
	}
      
      prevScore = aScore;
    }
  
  // Save resulting alignment
  result.setEndpoints(aLeft - match.frame(), aRight - match.frame(),
		      aLeft, aRight);
  result.setScore(aScore);
  
  return aScore;
}


//
// alignGappedBandedFwd()
//
// Find the score and endpoints of an optimal gapped sequence
// alignment starting at s1 in sequence 1 and s2 in sequence 2, ending
// anywhere in [s1, e1] x [s2, e2], and remaining entirely within the
// specified bandwidth around the diagonal s2 - s1.  Stop if every
// candidate alignment in a given row of the band falls below the
// score minScore.
//
// We use linear-space affine banded Smith-Waterman.
//
// ARGUMENTS
//   * pointers to sequences being aligned
//   * gapped scoring function
//   * score threshold at which extension stops
//   * boundaries (0-based) of rectangle in which to do alignments
//   * width of the band (implicity rounded up to odd number)
//   * ref for result structure
//
// RETURNS
//   * score of alignment
//   * score and endpoints of alignment in result structure
//
ScoreT alignGappedBandedFwd(const Residue *iseq1, const Residue *iseq2, 
			    const ScoreFunction &scoreFunction,
			    ScoreT minScore,
			    SeqPosn s1, SeqPosn s2, 
			    SeqPosn e1, SeqPosn e2,
			    SeqDiffT bandwidth,
			    Alignment &result)
{
  const Residue *seq1 = iseq1 + s1 - 1, *seq2 = iseq2 + s2 - 1;  // 1-based math
  SeqLength len1 = e1 - s1 + 1, len2 = e2 - s2 + 1;
  
  SeqDiffT dLeft = -bandwidth/2, dRight = bandwidth/2;
  
  // For self alignments, we assume that iseq1 == iseq2, and that all
  // hits have positive diagonal.  To avoid returning the trivial self-
  // alignment, restrict the band so that it excludes diagonals below 1.
  //
  SeqDiffT mainDiag = s2 - s1;
  if (iseq1 == iseq2 && mainDiag + dLeft < 1)
    dLeft = 1 - mainDiag;
  
  const ScoreMatrix &M = scoreFunction.subs();
  const ScoreT gapOpen = scoreFunction.gapOpen();
  const ScoreT gapExt  = scoreFunction.gapExt();
  
  ScoreT *Vorig     = new ScoreT [bandwidth + 2];
  ScoreT *Vprevorig = new ScoreT [bandwidth + 2];
  ScoreT *Forig     = new ScoreT [bandwidth + 2];
  
  //
  // Initialize V, F arrays for row i = 0
  //
  {
    ScoreT *Vprev = Vprevorig - (dLeft - 1);
    Vprev[0] = 0;
        
    for (SeqPosn j = 1; j <= SeqPosn(dRight); j++)
      Vprev[j] = gapOpen + j * gapExt;
    
    ScoreT *F = Forig - (dLeft - 1);
    for (SeqPosn j = 0; j <= SeqPosn(dRight); j++)
      F[j] = -INFTY;
    
    //
    // Set guard cells to prevent the alignment path from
    // trying to enter the band from the right.
    //
    ScoreT *V = Vorig - (dLeft - 1);
    V[dRight + 1]     = -INFTY;
    Vprev[dRight + 1] = -INFTY;
    F[dRight + 1]     = -INFTY;
  }
  
  // Keep track of the best alignment and its endpoint
  // (the starting point is fixed at [s1, s2]).
  ScoreT maxScore = 0;
  SeqPosn last1 = 1, last2 = 1;
  
  for (SeqPosn i = 1; i <= len1; i++)
    {
      SeqDiffT leftOffset = i + dLeft, rightOffset = i + dRight;
      bool keepExtending = false;
      
      const ScoreT *Mrow = M[seq1[i]];
      
      // 
      // Offset the V and F arrays so that we may address them
      // with the "natural" indices into the full score matrix
      // for the rectangle [1, len1] x [1, len2].
      //
      
      ScoreT *V     = Vorig     - (leftOffset - 1); 
      ScoreT *F     = Forig     - (leftOffset - 1);
      ScoreT *Vprev = Vprevorig - (leftOffset - 1 - 1);
      ScoreT E      = -INFTY;
      
      //
      // Fill in only this range of cells in the current row.
      //
      SeqPosn jLeft  = MAX(leftOffset,  1);
      SeqPosn jRight = MIN(rightOffset, SeqDiffT(len2));
      
      //
      // One nasty piece of business: 
      //
      //  If the current row is limited by the left side of the matrix,
      //  V must be initialized to permit a gap in s2 running from 0 to
      //  the current row.  Otherwise, V is initialized to forbid coming
      //  in from outside the band to the left.
      //
      // Note: if i is very large, we may overflow ScoreT, but this
      // won't happen for reasonable bandwidths.
      //
      V[jLeft - 1] = (jLeft == 1 ? gapOpen + ScoreT(i) * gapExt : -INFTY);
      
      for (SeqPosn j = jLeft; j <= jRight; j++)
	{
	  E = MAX(E, V[j-1] + gapOpen) + gapExt;
	  
	  F[j] = MAX(F[j+1], Vprev[j] + gapOpen) + gapExt;
	 
	  V[j] = MAX(MAX(E, F[j]), Vprev[j-1] + Mrow[seq2[j]]);
	  
	  if (V[j] > minScore)
	    {
	      // Keep going as long as some alignment path hasn't fallen
	      // below the score dropoff.
	      keepExtending = true;
	      
	      if (V[j] > maxScore)
		{
		  maxScore = V[j];
		  last1 = i;
		  last2 = j;
		}
	    }
	}
      
      // FIXME: shrink band if V[jLeft] or V[jRight] falls below cutoff?
      
      if (!keepExtending)
	break;
      else
      {
	ScoreT *temp = Vorig;
	Vorig = Vprevorig;
	Vprevorig = temp;
      }
    }
  
  delete [] Vorig;
  delete [] Vprevorig;
  delete [] Forig;
  
  result.setEndpoints(s1, last1 + s1 - 1, s2, last2 + s2 - 1);
  result.setScore(maxScore);
  
  return maxScore;
}


//
// alignGappedBandedBck()
// Find the score and endpoints of an optimal sequence alignment
// ending at e1 in sequence 1 and e2 in sequence 2, beginning anywhere
// in [s1, e1] x [s2, e2], and remaining entirely within the specified
// bandwidth around the diagonal e2 - e1.  Stop if every candidate
// alignment in a given row of the band falls below the score
// minScore.
//
// We use linear-space affine banded Smith-Waterman.
//
// ARGUMENTS
//   * pointers to sequences being aligned
//   * gapped scoring function
//   * score threshold at which extension stops
//   * boundaries (0-based) of rectangle in which to do alignments
//   * width of the band (implicity rounded up to odd number)
//   * ref for result structure
//
// RETURNS
//   * score of alignment
//   * score and endpoints of alignment in result structure
//
ScoreT alignGappedBandedBck(const Residue *iseq1, const Residue *iseq2, 
			    const ScoreFunction &scoreFunction,
			    ScoreT minScore,
			    SeqPosn s1, SeqPosn s2, 
			    SeqPosn e1, SeqPosn e2,
			    SeqDiffT bandwidth,
			    Alignment &result)
{
  const Residue *seq1 = iseq1 + s1 - 1, *seq2 = iseq2 + s2 - 1;  // 1-based math
  SeqLength len1 = e1 - s1 + 1, len2 = e2 - s2 + 1;

  SeqDiffT dLeft = -bandwidth/2, dRight = bandwidth/2;
  
  // For self alignments, we assume that iseq1 == iseq2, and that all
  // hits have positive diagonal.  To avoid returning the trivial self-
  // alignment, restrict the band so that it excludes diagonals below 1.
  //
  SeqDiffT mainDiag = s2 - s1;
  if (iseq1 == iseq2 && mainDiag + dLeft < 1)
    dLeft = 1 - mainDiag;
  
  const ScoreMatrix &M = scoreFunction.subs();
  const ScoreT gapOpen = scoreFunction.gapOpen();
  const ScoreT gapExt  = scoreFunction.gapExt();
    
  ScoreT *Vorig     = new ScoreT [bandwidth + 2];
  ScoreT *Vprevorig = new ScoreT [bandwidth + 2];
  ScoreT *Forig     = new ScoreT [bandwidth + 2];
  
  //
  // Initialize V, F arrays for row i = 0
  //
  {
    ScoreT *Vprev = Vprevorig - (dLeft - 1);
    Vprev[0] = 0;
        
    for (SeqPosn j = 1; j <= SeqPosn(dRight); j++)
      Vprev[j] = gapOpen + j * gapExt;
    
    ScoreT *F = Forig - (dLeft - 1);
    for (SeqPosn j = 0; j <= SeqPosn(dRight); j++)
      F[j] = -INFTY;
    
    //
    // Set guard cells to prevent the alignment path from
    // trying to enter the band from the right.
    //
    ScoreT *V = Vorig - (dLeft - 1);
    V[dRight + 1]     = -INFTY;
    Vprev[dRight + 1] = -INFTY;
    F[dRight + 1]     = -INFTY;
  }
  
  // Keep track of the best alignment and its endpoint
  // (the starting point is fixed at [s1, s2]).
  ScoreT maxScore = 0;
  SeqPosn last1 = 1, last2 = 1;
  
  //
  // Note: although we are effectively reversing the sequences to do
  // backwards alignment, we cannot set the seq ptrs to their ends and
  // use negative indices because the position variables are unsigned.
  // Instead, leave the seq ptrs at the starts and use positive array
  // indices.
  //
  for (SeqPosn i = 1; i <= len1; i++)
    {
      SeqDiffT leftOffset = i + dLeft, rightOffset = i + dRight;
      bool keepExtending = false;
      
      const ScoreT *Mrow = M[seq1[len1 - i + 1]];
      
      // 
      // Offset the V and F arrays so that we may address them
      // with the "natural" indices into the full score matrix
      // for the rectangle [1, len1] x [1, len2].
      //
      
      ScoreT *V     = Vorig     - (leftOffset - 1); 
      ScoreT *F     = Forig     - (leftOffset - 1);
      ScoreT *Vprev = Vprevorig - (leftOffset - 1 - 1);
      ScoreT E      = -INFTY;
      
      //
      // Fill in only this range of cells in the current row.
      //
      SeqPosn jLeft  = MAX(leftOffset,  1);
      SeqPosn jRight = MIN(rightOffset, SeqDiffT(len2));
      
      //
      // One nasty piece of business: 
      //
      //  If the current row is limited by the left side of the matrix,
      //  V must be initialized to permit a gap in s2 running from 0 to
      //  the current row.  Otherwise, V is initialized to forbid coming
      //  in from outside the band to the left.
      //
      // Note: if i is very large, we may overflow ScoreT, but this
      // won't happen for reasonable bandwidths.
      //
      V[jLeft - 1] = (jLeft == 1 ? gapOpen + ScoreT(i) * gapExt : -INFTY);
      
      for (SeqPosn j = jLeft; j <= jRight; j++)
	{
	  E = MAX(E, V[j-1] + gapOpen) + gapExt;
	  
	  F[j] = MAX(F[j+1], Vprev[j] + gapOpen) + gapExt;
	 
	  V[j] = MAX(MAX(E, F[j]), Vprev[j-1] + Mrow[seq2[len2 - j + 1]]);
	  
	  if (V[j] > minScore)
	    {
	      // Keep going as long as some alignment path hasn't fallen
	      // below the score dropoff.
	      keepExtending = true;
	      
	      if (V[j] > maxScore)
		{
		  maxScore = V[j];
		  last1 = i;
		  last2 = j;
		}
	    }
	}
      
      // FIXME: shrink band if V[jLeft] or V[jRight] falls below cutoff?
      
      if (!keepExtending)
	break;
      else
      {
	ScoreT *temp = Vorig;
	Vorig = Vprevorig;
	Vprevorig = temp;
      }
    }
  
  delete [] Vorig;
  delete [] Vprevorig;
  delete [] Forig;
  
  result.setEndpoints(e1 - last1 + 1, e1, e2 - last2 + 1, e2);
  result.setScore(maxScore);
  
  return maxScore;
}

///////////////////////////////////////////////////////////////////////////

//
// alignGappedBandedLPin()
// Find the score and one endpoint of an optimal gapped sequence alignment
// in the rectangle [s1, e1] x [s2, e2] that is forced to pass
// through row pinnedRow of the dynamic programming matrix
// (s1 <= pinnedRow <= e1).  We use a banded linear-space Smith-Waterman 
// search with the specified bandwidth.
//
// This function is useful for searching a region around a known
// starting point for a good alignment.  By forcing the alignment
// to pass through a specific row, e.g. the midpoint of the rectangle in 
// sequence 1, we can find relatively low-scoring alignments that would be 
// suppressed by a nearby high-scoring alignment overlapping a corner of the
// search rectangle.
//
// ARGUMENTS
//   * pointers to sequences being aligned
//   * gapped scoring function
//   * boundaries (0-based) of rectangle in which to do alignments
//   * width of the band (implicity rounded up to odd number)
//   * pinned row (in range [s1..e1]) through which alignment must pass
//   * ref for result structure
//
// RETURNS
//   * score of alignment
//   * score and one (upper) endpoint of alignment
//
ScoreT alignGappedBandedLPin(const Residue *iseq1, const Residue *iseq2, 
			     const ScoreFunction &scoreFunction,
			     SeqPosn s1, SeqPosn s2, 
			     SeqPosn e1, SeqPosn e2, 
			     SeqDiffT bandwidth,
			     SeqPosn pinnedRow,
			     Alignment &result)
{
  const Residue *seq1 = iseq1 + s1 - 1, *seq2 = iseq2 + s2 - 1; // 1-based math
  SeqLength len1 = e1 - s1 + 1, len2 = e2 - s2 + 1;
  
  SeqDiffT dLeft = -bandwidth/2, dRight = bandwidth/2;
  
  // For self alignments, we assume that iseq1 == iseq2, and that all
  // hits have positive diagonal.  To avoid returning the trivial self-
  // alignment, restrict the band so that it excludes diagonals below 1.
  //
  SeqDiffT mainDiag = s2 - s1;
  if (iseq1 == iseq2 && mainDiag + dLeft < 1)
    dLeft = 1 - mainDiag;
  
  const ScoreMatrix &M = scoreFunction.subs();
  const ScoreT gapOpen = scoreFunction.gapOpen();
  const ScoreT gapExt  = scoreFunction.gapExt();
  
  ScoreT *Vorig     = new ScoreT [bandwidth + 2];
  ScoreT *Vprevorig = new ScoreT [bandwidth + 2];
  ScoreT *Forig     = new ScoreT [bandwidth + 2];
  
  //
  // Initialize V, F arrays for row i = 0
  //
  {
    ScoreT *Vprev = Vprevorig - (dLeft - 1);
    
    for (SeqPosn j = 0; j <= SeqPosn(dRight); j++)
      Vprev[j] = 0;
    
    ScoreT *F = Forig - (dLeft - 1);
    for (SeqPosn j = 0; j <= SeqPosn(dRight); j++)
      F[j] = -INFTY;
    
    //
    // Set guard cells to prevent the alignment path from
    // trying to enter the band from the right.
    //
    ScoreT *V = Vorig - (dLeft - 1);
    V[dRight + 1]     = -INFTY;
    Vprev[dRight + 1] = -INFTY;
    F[dRight + 1]     = -INFTY;
  }
  
  // Keep track of the best alignment and its endpoint
  ScoreT maxScore = 0;
  SeqPosn last1 = 1, last2 = 1;
  
  SeqPosn iPinned = pinnedRow - s1 + 1;
  
  for (SeqPosn i = 1; i <= len1; i++)
    {
      SeqDiffT leftOffset = i + dLeft, rightOffset = i + dRight;
      
      const ScoreT *Mrow = M[seq1[i]];
      
      // 
      // Offset the V and F arrays so that we may address them
      // with the "natural" indices into the full score matrix
      // for the rectangle [1, len1] x [1, len2].
      //
      
      ScoreT *V     = Vorig     - (leftOffset - 1); 
      ScoreT *F     = Forig     - (leftOffset - 1);
      ScoreT *Vprev = Vprevorig - (leftOffset - 1 - 1);
      ScoreT E      = -INFTY;
      
      //
      // Fill in only this range of cells in the current row.
      //
      SeqPosn jLeft  = MAX(leftOffset,  1);
      SeqPosn jRight = MIN(rightOffset, SeqDiffT(len2));
      
      //
      // One nasty piece of business: 
      //
      //  If the current row is limited by the left side of the matrix,
      //  V must be initialized allow the alignment to start at the left.
      //  Otherwise, V is initialized to forbid coming
      //  in from outside the band to the left.
      //
      // Note: if i is very large, we may overflow ScoreT, but this
      // won't happen for reasonable bandwidths.
      //
      V[jLeft - 1] = (jLeft == 1
		      ? (i <= iPinned 
			 ? 0 
			 : gapOpen + ScoreT(i - iPinned) * gapExt)
		      : -INFTY);
      
      for (SeqPosn j = jLeft; j <= jRight; j++)
	{
	  E = MAX(E, V[j-1] + gapOpen) + gapExt;
	  
	  F[j] = MAX(F[j+1], Vprev[j] + gapOpen) + gapExt;
	  
	  V[j] = MAX(MAX(E, F[j]), Vprev[j-1] + Mrow[seq2[j]]);
	  
	  if (i < iPinned)
	    {
	      // We can start a new alignment anywhere up to the midline,
	      // if doing so would be advantageous.
	      
	      V[j] = MAX(V[j], 0);
	    }
	  else
	    {
	      // We cannot start a new alignment here, but we can record
	      // the optimal alignment that passes through the pinned row!
	      
	      if (V[j] > maxScore)
		{
		  maxScore = V[j];
		  last1 = i;
		  last2 = j;
		}
	    }
	}
      
      {
	ScoreT *temp = Vorig;
	Vorig = Vprevorig;
	Vprevorig = temp;
      }
    }
  
  delete [] Vorig;
  delete [] Vprevorig;
  delete [] Forig;
  
  result.setEnd(0, last1 + s1 - 1);
  result.setEnd(1, last2 + s2 - 1);
  result.setScore(maxScore);
  
  return maxScore;
}


//
// alignGappedBandedLPinE()
//
// This function is identical to alignGappedBandedLPin(), except that
// it computes and returns *both* endpoints of the optimal alignment
// (at a slightly greater cost).  The algorithm is still linear-space.
//
ScoreT alignGappedBandedLPinE(const Residue *iseq1, const Residue *iseq2, 
			      const ScoreFunction &scoreFunction,
			      SeqPosn s1, SeqPosn s2, 
			      SeqPosn e1, SeqPosn e2, 
			      SeqDiffT bandwidth,
			      SeqPosn pinnedRow,
			      Alignment &result)
{
  const Residue *seq1 = iseq1 + s1 - 1, *seq2 = iseq2 + s2 - 1; // 1-based math
  SeqLength len1 = e1 - s1 + 1, len2 = e2 - s2 + 1;
  
  SeqDiffT dLeft = -bandwidth/2, dRight = bandwidth/2;
  
  // For self alignments, we assume that iseq1 == iseq2, and that all
  // hits have positive diagonal.  To avoid returning the trivial self-
  // alignment, restrict the band so that it excludes diagonals below 1.
  //
  SeqDiffT mainDiag = s2 - s1;
  if (iseq1 == iseq2 && mainDiag + dLeft < 1)
    dLeft = 1 - mainDiag;
  
  const ScoreMatrix &M = scoreFunction.subs();
  const ScoreT gapOpen = scoreFunction.gapOpen();
  const ScoreT gapExt  = scoreFunction.gapExt();
  
  ScoreT *Vorig     = new ScoreT [bandwidth + 2];
  ScoreT *Vprevorig = new ScoreT [bandwidth + 2];
  ScoreT *Forig     = new ScoreT [bandwidth + 2];
  
  SeqPosn *Vs1orig      = new SeqPosn [bandwidth + 2];
  SeqPosn *Vs2orig      = new SeqPosn [bandwidth + 2];
  SeqPosn *Vprevs1orig  = new SeqPosn [bandwidth + 2];
  SeqPosn *Vprevs2orig  = new SeqPosn [bandwidth + 2];
  SeqPosn *Fs1orig      = new SeqPosn [bandwidth + 2];
  SeqPosn *Fs2orig      = new SeqPosn [bandwidth + 2];
  
  //
  // Initialize V, F arrays for row i = 0
  //
  {
    ScoreT  *Vprev   = Vprevorig   - (dLeft - 1);
    SeqPosn *Vprevs1 = Vprevs1orig - (dLeft - 1);
    SeqPosn *Vprevs2 = Vprevs2orig - (dLeft - 1);
    
    for (SeqPosn j = 0; j <= SeqPosn(dRight); j++)
      {
	Vprev[j]   = 0;
	Vprevs1[j] = 0; 
	Vprevs2[j] = j;
      }
    
    ScoreT *F = Forig - (dLeft - 1);
    for (SeqPosn j = 0; j <= SeqPosn(dRight); j++)
      F[j] = -INFTY;
    
    //
    // Set guard cells to prevent the alignment path from
    // trying to enter the band from the right.
    //
    ScoreT *V = Vorig - (dLeft - 1);
    V[dRight + 1]     = -INFTY;
    Vprev[dRight + 1] = -INFTY;
    F[dRight + 1]     = -INFTY;
  }
  
  // Keep track of the best alignment and its endpoints
  ScoreT maxScore = 0;
  SeqPosn first1 = 1, first2 = 1;
  SeqPosn last1  = 1, last2  = 1;
  
  SeqPosn iPinned = pinnedRow - s1 + 1;
  
  for (SeqPosn i = 1; i <= len1; i++)
    {
      SeqDiffT leftOffset = i + dLeft, rightOffset = i + dRight;
      
      const ScoreT *Mrow = M[seq1[i]];
      
      // 
      // Offset the V and F arrays so that we may address them
      // with the "natural" indices into the full score matrix
      // for the rectangle [1, len1] x [1, len2].
      //
      
      ScoreT *V     = Vorig     - (leftOffset - 1); 
      ScoreT *F     = Forig     - (leftOffset - 1);
      ScoreT *Vprev = Vprevorig - (leftOffset - 1 - 1);
      
      SeqPosn *Vs1  = Vs1orig   - (leftOffset - 1); 
      SeqPosn *Vs2  = Vs2orig   - (leftOffset - 1); 
      
      SeqPosn *Fs1  = Fs1orig   - (leftOffset - 1); 
      SeqPosn *Fs2  = Fs2orig   - (leftOffset - 1); 
      
      SeqPosn *Vprevs1  = Vprevs1orig - (leftOffset - 1 - 1); 
      SeqPosn *Vprevs2  = Vprevs2orig - (leftOffset - 1 - 1); 
      
      ScoreT E    = -INFTY;
      SeqPosn Es1 = INFTY, Es2 = INFTY;
      
      //
      // Fill in only this range of cells in the current row.
      //
      SeqPosn jLeft  = MAX(leftOffset,  1);
      SeqPosn jRight = MIN(rightOffset, SeqDiffT(len2));
      
      //
      // One nasty piece of business: 
      //
      //  If the current row is limited by the left side of the matrix,
      //  V must be initialized allow the alignment to start at the left.
      //  Otherwise, V is initialized to forbid coming
      //  in from outside the band to the left.
      //
      // Note: if i is very large, we may overflow ScoreT, but this
      // won't happen for reasonable bandwidths.
      //
      if (jLeft == 1)
	{
	  if (i <= iPinned)
	    {
	      V[jLeft - 1]   = 0;
	      Vs1[jLeft - 1] = i;
	      Vs2[jLeft - 1] = 0;
	    }
	  else
	    {
	      V[jLeft - 1]   = gapOpen + (i - iPinned) * gapExt;
	      Vs1[jLeft - 1] = iPinned;
	      Vs2[jLeft - 1] = jLeft - 1;
	    }
	}
      else
	{
	  V[jLeft - 1] = -INFTY;
	}
      
      //
      // This loop is identical to the one in alignGappedBandedLPin(),
      // except that we also propagate the starting point of the
      // optimal alignment in each cell along with its score.
      //
      for (SeqPosn j = jLeft; j <= jRight; j++)
	{
	  ScoreT eMax = MAX(E, V[j-1] + gapOpen);
	  if (eMax == E)
	    {
	      // extending from E -- Es1 and Es2 unchanged
	    }
	  else
	    {
	      Es1 = Vs1[j-1];
	      Es2 = Vs2[j-1];
	    }
	  E = eMax + gapExt;
	  
	  ScoreT fMax = MAX(F[j+1], Vprev[j] + gapOpen);
	  if (fMax == F[j+1])
	    {
	      Fs1[j] = Fs1[j+1];
	      Fs2[j] = Fs2[j+1];
	    }
	  else
	    {
	      Fs1[j] = Vprevs1[j];
	      Fs2[j] = Vprevs2[j];
	    }
	  F[j] = fMax + gapExt;
	  
	  ScoreT efMax = MAX(E, F[j]);
	  SeqPosn efs1, efs2;
	  if (efMax == E)
	    {
	      efs1 = Es1;
	      efs2 = Es2;
	    }
	  else
	    {
	      efs1 = Fs1[j];
	      efs2 = Fs2[j];
	    }
	  
	  ScoreT ascore = Vprev[j-1] + Mrow[seq2[j]];
	  if (ascore >= efMax)
	    {
	      V[j]   = ascore;
	      Vs1[j] = Vprevs1[j-1];
	      Vs2[j] = Vprevs2[j-1];
	    }
	  else
	    {
	      V[j]   = efMax;
	      Vs1[j] = efs1;
	      Vs2[j] = efs2;
	    }
	  
	  if (i < iPinned)
	    {
	      // We can start a new alignment anywhere up to the pinned row,
	      // if doing so would be advantageous.
	      
	      if (V[j] < 0)
		{
		  V[j] = 0;
		  Vs1[j] = i;
		  Vs2[j] = j;
		}
	    }
	  else
	    {
	      // We cannot start a new alignment here, but we can record
	      // the optimal alignment that passes through the pinned row!
	      
	      if (V[j] > maxScore)
		{
		  maxScore = V[j];
		  first1 = Vs1[j];
		  first2 = Vs2[j];
		  last1 = i;
		  last2 = j;
		}
	    }
	}
      
      {
	ScoreT *temp = Vorig;
	Vorig = Vprevorig;
	Vprevorig = temp;
	
	SeqPosn *ptemp;
	
	ptemp = Vs1orig;
	Vs1orig = Vprevs1orig;
	Vprevs1orig = ptemp;
	
	ptemp = Vs2orig;
	Vs2orig = Vprevs2orig;
	Vprevs2orig = ptemp;
      }
    }
  
  delete [] Vorig;
  delete [] Vprevorig;
  delete [] Forig;
  
  result.setEndpoints(first1 + s1, last1 + s1 - 1, 
		      first2 + s2, last2 + s2 - 1);
  result.setScore(maxScore);

  return maxScore;
}


//
// alignGappedBandedLPinA()
//
// This function is identical to alignGappedBandedLPin(), except that
// it computes and returns the path of the optimal alignment in
// result.path().  The algorithm is quadratic-space, but the
// space is limited in practice by the search bandwidth.
//
// To conserve space, search back pointers are stored as bit flags
// in a single byte.
//

typedef unsigned char byte;
typedef Vector<byte> ByteVector;

const byte BT_VMASK  = 0x07;

const byte BT_VALIGN = 0x01;
const byte BT_VGAP1  = 0x02;
const byte BT_VGAP2  = 0x03;
const byte BT_VSTOP  = 0x07;

const byte BT_EGAPOPEN  = 0x10;
const byte BT_EGAPEXT   = 0x20;
const byte BT_FGAPOPEN  = 0x40;
const byte BT_FGAPEXT   = 0x80;

//
// local prototypes
//
static void computePath(const byte *backTraceorig, 
			SeqDiffT bandwidth, SeqDiffT dLeft,
			SeqPosn last1, SeqPosn last2,
			Alignment &a);


ScoreT alignGappedBandedLPinA(const Residue *iseq1, const Residue *iseq2, 
			      const ScoreFunction &scoreFunction,
			      SeqPosn s1, SeqPosn s2, 
			      SeqPosn e1, SeqPosn e2, 
			      SeqDiffT bandwidth,
			      SeqPosn pinnedRow,
			      Alignment &result)
{
  const Residue *seq1 = iseq1 + s1 - 1, *seq2 = iseq2 + s2 - 1;  // 1-based math
  SeqLength len1 = e1 - s1 + 1, len2 = e2 - s2 + 1;
  
  SeqDiffT dLeft = -bandwidth/2, dRight = bandwidth/2;
  
  // For self alignments, we assume that iseq1 == iseq2, and that all
  // hits have positive diagonal.  To avoid returning the trivial self-
  // alignment, restrict the band so that it excludes diagonals below 1.
  //
  SeqDiffT mainDiag = s2 - s1;
  if (iseq1 == iseq2 && mainDiag + dLeft < 1)
    dLeft = 1 - mainDiag;
  
  const ScoreMatrix &M = scoreFunction.subs();
  const ScoreT gapOpen = scoreFunction.gapOpen();
  const ScoreT gapExt  = scoreFunction.gapExt();
  
  ScoreT *Vorig     = new ScoreT [bandwidth + 2];
  ScoreT *Vprevorig = new ScoreT [bandwidth + 2];
  ScoreT *Forig     = new ScoreT [bandwidth + 2];
  
  byte *backTraceorig = new byte [(len1 + 1) * (bandwidth + 1)];
  memset(backTraceorig, 0, (len1 + 1) * (bandwidth + 1) * sizeof(byte));
  
  //
  // Initialize V, F arrays for row i = 0
  //
  {
    ScoreT  *Vprev   = Vprevorig   - (dLeft - 1);
    byte *backTrace  = backTraceorig - (dLeft - 1);
    
    for (SeqPosn j = 0; j <= SeqPosn(dRight); j++)
      {
	Vprev[j]   = 0;
	backTrace[j] = BT_VSTOP;
      }
    
    ScoreT *F = Forig - (dLeft - 1);
    for (SeqPosn j = 0; j <= SeqPosn(dRight); j++)
      F[j] = -INFTY;
    
    //
    // Set guard cells to prevent the alignment path from
    // trying to enter the band from the right.
    //
    ScoreT *V = Vorig - (dLeft - 1);
    V[dRight + 1]     = -INFTY;
    Vprev[dRight + 1] = -INFTY;
    F[dRight + 1]     = -INFTY;
  }
  
  // Keep track of the best alignment and its endpoint
  ScoreT maxScore = 0;
  SeqPosn last1 = 1, last2 = 1;
  
  SeqPosn iPinned = pinnedRow - s1 + 1;
  
  for (SeqPosn i = 1; i <= len1; i++)
    {
      SeqDiffT leftOffset = i + dLeft, rightOffset = i + dRight;
      
      const ScoreT *Mrow = M[seq1[i]];
      
      // 
      // Offset the V and F arrays so that we may address them
      // with the "natural" indices into the full score matrix
      // for the rectangle [1, len1] x [1, len2].
      //
      
      ScoreT *V     = Vorig     - (leftOffset - 1); 
      ScoreT *F     = Forig     - (leftOffset - 1);
      ScoreT *Vprev = Vprevorig - (leftOffset - 1 - 1);
      
      byte *backTrace = 
	backTraceorig + i * (bandwidth + 1) - (leftOffset - 1);
      
      ScoreT E = -INFTY;
      
      //
      // Fill in only this range of cells in the current row.
      //
      SeqPosn jLeft  = MAX(leftOffset,  1);
      SeqPosn jRight = MIN(rightOffset, SeqDiffT(len2));
      
      //
      // One nasty piece of business: 
      //
      //  If the current row is limited by the left side of the matrix,
      //  V must be initialized allow the alignment to start at the left.
      //  Otherwise, V is initialized to forbid coming
      //  in from outside the band to the left.
      //
      // Note: if i is very large, we may overflow ScoreT, but this
      // won't happen for reasonable bandwidths.
      //
      if (jLeft == 1)
	{
	  if (i <= iPinned)
	    {
	      V[jLeft - 1] = 0;
	      backTrace[jLeft - 1] = (BT_VSTOP | BT_FGAPOPEN);
	    }
	  else
	    {
	      V[jLeft - 1] = gapOpen + (i - iPinned) * gapExt;
	      backTrace[jLeft - 1] = (BT_VGAP2 | BT_FGAPEXT);
	    }
	}
      else
	{
	  V[jLeft - 1] = -INFTY;
	}
      
      // This loop is identical to that in alignGappedBandedLPin(),
      // except that we remember how we got to each cell in the
      // score matrix.
      //
      for (SeqPosn j = jLeft; j <= jRight; j++)
	{
	  ScoreT eMax = MAX(E, V[j-1] + gapOpen);
	  backTrace[j] |= (eMax == E ? BT_EGAPEXT : BT_EGAPOPEN);
	  E = eMax + gapExt;
	  
	  ScoreT fMax = MAX(F[j+1], Vprev[j] + gapOpen);
	  backTrace[j] |= (fMax == F[j+1] ? BT_FGAPEXT : BT_FGAPOPEN);
	  F[j] = fMax + gapExt;
	  
	  ScoreT efMax = MAX(E, F[j]);
	  byte efByte = (efMax == E ? BT_VGAP1 : BT_VGAP2);
	  
	  // When choosing between equal-scoring paths, favor
	  // alignments over gaps.
	  //
	  ScoreT ascore = Vprev[j-1] + Mrow[seq2[j]];
	  if (ascore >= efMax)
	    {
	      V[j] = ascore;
	      backTrace[j] |= BT_VALIGN;
	    }
	  else
	    {
	      V[j] = efMax;
	      backTrace[j] |= efByte;
	    }
	  
	  if (i < iPinned)
	    {
	      // We can start a new alignment anywhere before the
	      // pinned row, if doing so would be advantageous.
	      
	      if (V[j] < 0)
		{
		  V[j] = 0;
		  backTrace[j] = ((backTrace[j] & ~BT_VMASK) | BT_VSTOP);
		}
	    }
	  else
	    {
	      // We cannot start a new alignment here, but we can record
	      // the optimal alignment that passes through the pinned row!
	      
	      if (V[j] > maxScore)
		{
		  maxScore = V[j];
		  last1 = i;
		  last2 = j;
		}
	    }
	}
      
      {
	ScoreT *temp = Vorig;
	Vorig = Vprevorig;
	Vprevorig = temp;
      }
    }
  
  delete [] Vorig;
  delete [] Vprevorig;
  delete [] Forig;
  
  
  result.setEnd(0, last1 + s1 - 1);
  result.setEnd(1, last2 + s2 - 1);
  result.setScore(maxScore);
  
  computePath(backTraceorig, bandwidth, dLeft, last1, last2, result);
  
  result.setStart(0, result.start(0) + s1);
  result.setStart(1, result.start(1) + s2);
  
  delete [] backTraceorig;
  
  return maxScore;
}


//
// computePath()
// Compute the path corresponding to an optimal alignment from the
// backtrace data generated by alignGappedBandedLPinA().
//
// ARGUMENTS:
//  * pointer to block of backtrace data
//  * search bandwidth
//  * leftmost diagonal searched
//  * endpoint (last1,last2) of alignment to trace
//  * reference to result structure
//
// RETURNS:
//  * alignment path in a.path()
//  * starting point of alignment in a.start(*)
//
static void computePath(const byte *backTraceorig, 
			SeqDiffT bandwidth, SeqDiffT dLeft,
			SeqPosn last1, SeqPosn last2,
			Alignment &a)
{
  SeqPosn i = last1, j = last2;
  Alignment::Path path;
  
  const byte *backTrace = 
    backTraceorig + i * (bandwidth + 1) - (i + dLeft - 1);
  
  SeqDiffT delta = bandwidth;
  
  for (;;)
    {
      switch (backTrace[j] & BT_VMASK)
	{
	case BT_VSTOP:
	  goto finish;
	  
	case BT_VALIGN:
	  path.add(Alignment::MATCH);
	  backTrace -= delta;
	  i--; j--;
	  break;
	  
	case BT_VGAP1:
	  // add one gap for each extension, plus one for opening
	  do
	    {
	      path.add(Alignment::GAP1);
	    }
	  while (backTrace[j--] & BT_EGAPEXT);
	  break;
	  
	case BT_VGAP2:
	  // add one gap for each extension, plus one for opening
	  do
	    {
	      path.add(Alignment::GAP2);
	      backTrace -= delta; 
	      i--;
	    }
	  while ((backTrace + delta)[j] & BT_FGAPEXT);
	  break;
	  
	default: // cases should be exhaustive -- catch errors here
	  cerr << "*** ERROR: REACHED BOGUS CELL " << i << ' ' << j << '\n';
	  exit(1);
	}
    }
  
 finish:
  
  // Reverse the path so that it proceeds from start to end.
  //
  for (unsigned int m = 0; m < path.length() / 2; m++)
    {
      unsigned int revIdx = path.length() - m - 1;
      
      Alignment::Step temp  = path[m];
      path[m]               = path[revIdx];
      path[revIdx]          = temp;
    }
  
  a.setStart(0, i); a.setStart(1, j);
  a.setPath(path);
}
