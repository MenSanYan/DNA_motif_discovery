//
// MATCH.H
// The Match data type, which contains information about an inexact match
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __MATCH_H
#define __MATCH_H

#include "datatypes.h"
#include "vector.h"

class Match {
public:
  Match(void) {}
  
  Match(SeqNumber seq0, SeqPosn low0,
	SeqNumber seq1, SeqPosn low1,
	SeqLength ilength)
  {
    seqs[0] = seq0; seqs[1] = seq1;
    lows[0] = low0; lows[1] = low1;
    _length = ilength;
  }
  
  // copy constructor and op= do the obvious elt-wise copy
  
  // inspectors
  SeqNumber seq(int j)   const { return seqs[j]; }
  SeqPosn   low(int j)   const { return lows[j]; }
  SeqLength length(void) const { return _length; }
  
  // mutators
  void setSeq(int j, SeqNumber v) { seqs[j] = v; }
  void setLow(int j, SeqPosn v)   { lows[j] = v; }
  void setLength(SeqLength v)     { _length = v; }
  
  // ** derived values **
  
  // The high endpoint of a match segment
  //
  SeqPosn high(int j) const { return lows[j] + _length - 1; }
  
  // The frame is the difference between a match's second and first
  // starting points.
  //
  SeqDiffT frame(void) const { return SeqDiffT(lows[1]) - SeqDiffT(lows[0]); }
  
private:
  
  SeqNumber seqs[2]; // sequences from which match is taken
  SeqPosn   lows[2]; // lower indices of matches within sequences
  SeqLength _length; // length of match
};

typedef Vector<Match> MatchVector;

#endif
