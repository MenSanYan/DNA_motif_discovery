//
// PRINTALIGNMENT.H
// Routines for printing BLAST-style sequence alignments
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __PRINTALIGNMENT_H
#define __PRINTALIGNMENT_H

#include <iostream>

#include "seqinfo.h"
#include "alignment.h"

void printUngappedAlignment(const SeqInfo &seqInfo1, const SeqInfo &seqInfo2,
			    const Alignment &a, std::ostream &os,
			    unsigned int lineLength,
			    unsigned int indent = 0);

void printGappedAlignment(const SeqInfo &seqInfo1, const SeqInfo &seqInfo2,
			  const Alignment &a, std::ostream &os,
			  unsigned int lineLength,
			  unsigned int indent = 0);

#endif
