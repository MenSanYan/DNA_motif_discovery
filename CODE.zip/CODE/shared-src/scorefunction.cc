//
// SCOREFUNCTION.CC
// Scoring functions for alignment of biosequences
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2002 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <cctype>

#include "scorefunction.h"
#include "fileops.h"

using namespace std;

const int MAXLINELEN = 4096;

// Consume and discard all characters up to and including
// the next end-of-line.
inline void discardToEOL(istream &is)
{
  is.ignore(INT_MAX, '\n');
}


//
// ScoreFunction::ScoreFunction()
// Constructor 
ScoreFunction::ScoreFunction(const Alphabet *a, const char *scoreFileName)
  : S(a)
{
  if (scoreFileName)
    {
      const char *tail = strrchr(scoreFileName, DirSeparator);
      if (!tail)
	tail = scoreFileName;
      else
	tail++;
      
      char *tname = new char [strlen(tail)+1];
      strcpy(tname, tail);
      _name = tname;
      
      _valid = readFile(scoreFileName);
      
      if (_valid)
	readGappedKAValues(scoreFileName);
    }
  else
    {
      _name = NULL;
      _valid = false;
    }
}


//
// ScoreFunction::readFile()
// Initialize a score function from the contents of a score
// file named "fileName".  The file may be either BLAST or
// FASTA formatted.
//
// RETURNS: true if initialization succeeded, false otherwise
//
bool ScoreFunction::readFile(const char *fileName)
{
  ifstream is(fileName);
  char c;
  
  if (!is)
    {
      cerr << "Error: could not open score function file "
	   << fileName << '\n';
      return false;
    }
  
  is >> c;
  if (c == ';') // FASTA score file
    {
      return readFastaFile(is);
    }
  else // BLAST (does not supply default gap penalties)
    {
      is.putback(c);
      
      _gapOpen = -1; _gapExt = -1;
      return readBlastFile(is);
    }
}


//
// ScoreFunction::readFastaFile()
// Initialize a score function from a FASTA-formatted score file
// on input stream is.
//
// RETURNS: true iff read succeeds.
//
bool ScoreFunction::readFastaFile(istream &is)
{
  // ignore lines 1 and 2
  discardToEOL(is);
  discardToEOL(is);  
  
  // read gap penalties on line 3
  is >> _gapOpen;
  is >> _gapExt;
  discardToEOL(is);
  
  // ignore line 4
  discardToEOL(is);
  
  // read alphabet on line 5 and set residue mapping
  Vector<Residue> mapping;
  if (!getAlphabetMapping(is, mapping, S.alphabet()))
    return false;
  
  // ignore line 6
  discardToEOL(is);
  
  // Read values of the score matrix.  To handle either full
  // or partial matrices, read one line at a time.
  char *buf = new char [MAXLINELEN + 1];
  
  bool success = true;
  for (unsigned int i = 0; i < mapping.length(); i++)
    {
      char *currPtr = buf;
      char c;
      
      // skip any leading row label (non-numeric first char)
      is >> c;
      if (c == '-' || isdigit(c))
	is.putback(c);
      
      is.getline(buf, MAXLINELEN+1);
      
      if (!is)
	{
	  cerr << "Error: failed to read row " << i+1
	       << " of score matrix\n";
	  success = false;
	  goto finish;
	}
      
      for (unsigned int j = 0; j <= i; j++)
        {
          char *endPtr = 0;
          
          ScoreT v = strtol(currPtr, &endPtr, 10);
          if (endPtr == currPtr)
            {
              cerr << "Error: failed to read entry ("
                   << i+1 << ',' << j+1 << ") of score matrix\n";
	      success = false;
	      goto finish;
            }
	  else
	    currPtr = endPtr;
	  
	  S.setEntry(mapping[i], mapping[j], v);
          S.setEntry(mapping[j], mapping[i], v);
        }
    }
  
 finish:
  delete [] buf;
  return success;
}


//
// ScoreFunction::readBlastFile()
// Initialize a score function from a BLAST-formatted score file
// on input stream is.
//
// RETURNS: true iff read succeeds.
//
bool ScoreFunction::readBlastFile(istream &is)
{
  // ignore any initial comment lines
  for (;;)
    {
      char c;
      
      is >> c;
      if (c == '#')
	discardToEOL(is);
      else
	{
	  is.putback(c);
	  break;
	}
    }
  
  // read alphabet line and set residue mapping
  Vector<Residue> mapping;
  if (!getAlphabetMapping(is, mapping, S.alphabet()))
    return false;
  
  // Read values of the score matrix.  Read one line at a time
  // so we may ignore terminal "*" column.
  //
  char *buf = new char [MAXLINELEN + 1];
  
  bool success = true;
  for (unsigned int i = 0; i < mapping.length(); i++)
    {
      char *currPtr = buf;
      char c;
      
      // skip any leading row label (non-numeric first char)
      is >> c;
      if (c == '-' || isdigit(c))
	is.putback(c);
      
      is.getline(buf, MAXLINELEN+1);
      
      if (!is)
	{
	  cerr << "Error: failed to read row " << i+1
	       << " of score matrix\n";
	  success = false;
	  goto finish;
	}
      
      for (unsigned int j = 0; j < mapping.length(); j++)
        {
          char *endPtr = 0;
          
          ScoreT v = strtol(currPtr, &endPtr, 10);
          if (endPtr == currPtr)
            {
              cerr << "Error: failed to read entry ("
                   << i+1 << ',' << j+1 << ") of score matrix\n";
	      success = false;
	      goto finish;
            }
          else
	    currPtr = endPtr;
	  
          S.setEntry(mapping[i], mapping[j], v);
        }
    }

 finish:  
  delete [] buf;
  
  return success;
}


//
// ScoreFunction::getAlphabetMapping()
// Determine for each column of the score matrix what residue it corresponds
// to in the input alphabet.  The score file must have exactly one
// column for each alphabet character.
//
// RETURN: true iff read was successful.
//
bool ScoreFunction::getAlphabetMapping(istream &is, Vector<Residue> &mapping,
				       const Alphabet *a)
{
  bool *seen = new bool [a->nResidues()];
  bool success = true;
  
  for (unsigned int j = 0; j < a->nResidues(); j++)
    seen[j] = false;
  
  while (is)
    {
      char c = is.get();
      
      if (c == '\n')
	{
	  is.putback(c);
	  break;
	}
      else if (c == EOF || c == '*')
        break;
      else if (isspace(c))
        continue;
      else
	{
	  Residue r = a->fromChar(c);
	  
	  if (r == Alphabet::INVALID_CHAR)
	    {
	      cerr << "Error: unknown residue '" << c 
		   << "' in score function\n";
	      success = false;
	      goto finish;
	    }
	  else if (seen[r])
	    {
	      cerr << "Warning: residue '" << c << "' is equivalent to "
		   << "previously read residue '" << a->toChar(r) << "'\n"
		   << "  (The column for '" << c << "' will be used)\n";
	    }
	  
	  mapping.add(r);
	  seen[r] = true;
	}
    }
  
  // sanity check: did we encounter scores for every residue in the alphabet?
  for (Residue r = 0; r < a->nResidues(); r++)
    {
      if (!seen[r])
	{
	  cerr << "Error: residue '" << a->toChar(r) << "' (or its "
	       << "equivalent) does not appear in the score function\n";
	  success = false;
	}
    }
  
 finish:
  delete [] seen;
  discardToEOL(is);
  return success;
}


//
// ScoreFunction::readGappedKAValues()
// Read a list of gapped Karlin-Altschul K and lambda values from a file
// linked to a particular score.  If the file "SCORE-FILE" exists, the
// gapped KA values must be in the file SCORE-FILE.gka.  The content
// of this file is a series of lines, each of which is either a comment
// (starts with "#") or a list of numbers of the form
// <gapOpen> <gapExt> <lambda> <k> [any trailing garbage you like]
//
void ScoreFunction::readGappedKAValues(const char *scoreFileName)
{
  unsigned int nameLen = strlen(scoreFileName);
  char *gkaName = new char [nameLen + 1 + 3 + 1];
  
  strcpy(gkaName, scoreFileName);
  strcat(gkaName, ".gka");
  
  ifstream is(gkaName);
  
  if (is)
    {
      char *buf = new char [MAXLINELEN + 1];
      int lineno = 0;
      char c;
      
      do
	{
	  lineno++;
	  
	  is >> c; if (!is) break;
	  
	  if (c == '#')
	    {
	      discardToEOL(is);
	      continue;
	    }
	  else
	    is.putback(c);
	  
	  is.getline(buf, MAXLINELEN+1);
	  
	  GappedKAValues v;
	  char *currPtr = buf;
	  char *endPtr;
	  
	  v.gapOpen = strtol(currPtr, &endPtr, 10);
	  if (currPtr == endPtr)
	    goto err;
	  else
	    currPtr = endPtr;
	  
	  v.gapExt = strtol(currPtr, &endPtr, 10);
	  if (currPtr == endPtr)
	    goto err;
	  else
	    currPtr = endPtr;
	  
	  v.lambda = strtod(currPtr, &endPtr);
	  if (currPtr == endPtr)
	    goto err;
	  else
	    currPtr = endPtr;
	  
	  v.K = strtod(currPtr, &endPtr);
	  if (currPtr == endPtr)
	    goto err;
	  
	  // gap penalties in file are not negated
	  v.gapOpen = -v.gapOpen;
	  v.gapExt  = -v.gapExt;
	  
	  gappedKAValues.add(v);
	  
	  continue;
	  
	err:
	  cerr << "* Error: could not read line " << lineno << " of file '"
	       << gkaName << "'\n";
	  gappedKAValues.truncate();
	  break;
	}
      while (is);
      
      delete [] buf;
    }
  
  delete [] gkaName;
}


//
// ScoreFunction::getGappedKAValues()
// Find the gapped Karlin-Altschul values (if known) associated with
// particular gap penalties for this score function.  If no such
// values are known, print an error and return NULL.
//
const ScoreFunction::GappedKAValues *
ScoreFunction::getGappedKAValues(ScoreT gapOpen, ScoreT gapExt) const
{
  for (unsigned int j = 0; j < gappedKAValues.length(); j++)
    {
      const GappedKAValues &v = gappedKAValues[j];
      
      if (v.gapOpen == gapOpen && v.gapExt == gapExt)
	return &v;
    }
  
  // if here, we didn't find a match
  if (gappedKAValues.isEmpty())
    {
      // table for score fcn not found
      cerr << "* Error: no gapped K and lambda values known for score fcn "
	   << _name << '\n';
    }
  else
    {
      // penalty combo not found
      cerr << "* Error: no K and lambda known for gap penalties ("
	   << gapOpen << ',' << gapExt << ")\n"
	   << "         for score function " << _name << '\n';
    }
  
  return NULL;
}


// print a score function
ostream &operator<<(ostream &os, const ScoreFunction &F)
{
  os << F.name() <<'\n';
  os << F.gapOpen() << ' ' << F.gapExt() << '\n';
  os << F.subs();
  
  return os;
}

/////////////////////////////////////////////////////////////////

//
// ScoreMatrix constructor
//
ScoreMatrix::ScoreMatrix(const Alphabet *a)
{
  _alphabet = a;
  
  logLen = computeLogLen(a->nResidues());
  
  values = new ScoreT [a->nResidues() << logLen]; 
}


//
// ScoreMatrix::copy()
// common copy code for ScoreMatrix copy ctor and operator=
//
void ScoreMatrix::copy(const ScoreMatrix &other)
{
  if (values) delete [] values;
  
  _alphabet = other._alphabet;
  logLen    = other.logLen;
  
  values = new ScoreT [_alphabet->nResidues() << logLen]; 
  
  memcpy(values, other.values, 
	 (_alphabet->nResidues() << logLen) * sizeof(ScoreT));
}


//
// ScoreMatrix::minScore()
// Return the largest score value in the matrix.
// ASSUMES: M[x][*] = M[*][x] = c for every residue *, the x residue, and
// some constant c.
//
ScoreT ScoreMatrix::minScore(bool includeX) const
{
  ScoreT vMin = (*this)[1][1];
  
  for (Residue i = 1; i <= _alphabet->nRealResidues(); i++)
    for (Residue j = 1; j <= _alphabet->nRealResidues(); j++)
      {
	ScoreT v = (*this)[i][j];
	if (v < vMin)
	  vMin = v;
      }
  
  if (includeX && (*this)[0][0] < vMin)
    vMin = (*this)[0][0];
  
  return vMin;
}


//
// ScoreMatrix::maxScore()
// Return the largest score value in the matrix.
// ASSUMES: M[x][*] = M[*][x] = c for every residue *, the x residue, and
// some constant c.
//
ScoreT ScoreMatrix::maxScore(bool includeX) const
{
  ScoreT vMax = (*this)[1][1];
  
  for (Residue i = 1; i < _alphabet->nRealResidues(); i++)
    for (Residue j = 1; j < _alphabet->nRealResidues(); j++)
      {
	ScoreT v = (*this)[i][j];
	if (v > vMax)
	  vMax = v;
      }
  
  if (includeX && (*this)[0][0] > vMax)
    vMax = (*this)[0][0];
  
  return vMax;
}


// print a substitution score matrix
ostream &operator<<(ostream &os, const ScoreMatrix &S)
{
  const Alphabet *a = S.alphabet();
  ScoreT min = S.minScore(true);
  int width = (min <= -100 ? 5 : 4);
  
  for (Residue r = 0; r < a->nResidues(); r++)
    {
      for (int j = 0; j < width - 1; j++)
	os << ' ';
      os << char(toupper(a->toChar(r)));
    }
  os << '\n';
  
  for (Residue i = 0; i < a->nResidues(); i++)
    {
      for (Residue j = 0; j < a->nResidues(); j++)
	os << setw(width) << S[i][j];
      os << '\n';
    }
  
  return os;
}
