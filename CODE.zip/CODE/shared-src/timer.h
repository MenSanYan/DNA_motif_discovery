//
// TIMER.H
// Trivial timer code
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __TIMER_H
#define __TIMER_H

// start the timer
void startTimer(void);

// stop the timer and return the number of seconds elapsed
double stopTimer(void);

#endif
