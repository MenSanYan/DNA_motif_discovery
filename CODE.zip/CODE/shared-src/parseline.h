//
// PARSELINE.H
// Support routines for a simple, line-oriented parser that ignores
// whitespace *except* for EOL's.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __PARSELINE_H
#define __PARSELINE_H

#include <iostream>

#include <stdio.h>
#include "datatypes.h"
#include "direction.h"

// useful character constants
const int EOL = '\n';
const int NIL = '\0';

// parse a single character
bool parseChar(std::istream &, char *c);

// parse an ASCIIZ string; do not write more than length chars including
// the terminating NIL.
bool parseString(std::istream &, char *, size_t length);

// parse a direction value
bool parseDirection(std::istream &, Direction *);

// consume whitespace up to EOL or next non-whitespace char
bool consumeWhiteSpace(std::istream &);

// consume non-whitespace up to EOL or next whitespace char
bool consumeNonWhiteSpace(std::istream &);


//
// Generic parser for numeric types
//

bool _parseNumber(std::istream &, unsigned long *, int);

template <class T>
bool parseNumber(std::istream &is, T *v)
{
  unsigned long tmp;
  
  // Compute max # of decimal digits that fit in sizeof(T) bytes.
  int maxDigits = int(sizeof(T) * 2.409 + 1);
  
  bool result = _parseNumber(is, &tmp, maxDigits);
  *v = T( tmp );
  
  return result;
}

#endif
