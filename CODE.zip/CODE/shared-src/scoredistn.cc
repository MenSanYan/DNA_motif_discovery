//
// SCOREDISTN.CC
// Compute score distributions
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2002 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include "scoredistn.h"


//
// Constructor given residue distribtuions and score function
//
// Compute the distribution of score values, that is, the
// probability (given the background seq distns and a score matrix)
// that a random pair of residues, one from each sequence, will have
// each possible score.
//
ScoreDistn::ScoreDistn(const double *d1, const double *d2, 
		       const ScoreMatrix &M)
{
  // Find the lowest and highest scores in M (not counting X's).
  _low = M.minScore();
  _high = M.maxScore();
  
  init(_low, _high);
  
  for (ScoreT m = _low; m <= _high; m++)
    probs[m] = 0.0;
  
  // Compute the probability of obtaining each score m from a random
  // draw of two residues from seqs 1 and 2.
  //
  for (Residue i = 1; i <= M.alphabet()->nRealResidues(); i++)
    for (Residue j = 1; j <= M.alphabet()->nRealResidues(); j++)
      {
	ScoreT m = M[i][j];
	probs[m] += d1[i] * d2[j];
      }
}


//
// ScoreDistn::computeSumDistn()
// Compute the distribution of the sum of matchLength consecutive
// pairs of residues chosen independently at random from the current
// score distribution.
//
ScoreDistn *
ScoreDistn::computeSumDistn(SeqLength matchLength) const
{
  //
  // THEORY OF OPERATION
  //
  // Let S_j be the score sum of j independently-chosen random residue pairs.
  // To compute the distribution of S_j, we need to know Pr[S_j = s] for all 
  // possible sums s of j scores.  The value of s is bounded by the closed 
  // interval [j * low .. j * high].
  //
  // We may compute Pr[S_j = s] recursively as follows.  For the base
  // case, Pr[S_0 = 0] = 1.  Inductively, we have
  //
  //   Pr[S_j = sigma] = Sum_(m=low .. high) Pr[S_(j-1) = sigma - m] * Pr[m]
  //
  // where Pr[m] is the probability of a residue pair with score m.  Note
  // that we must restrict the summation on the right to reference only
  // score values between (j-1) * low and (j-1) * high.  In other words,
  // we require that
  //
  //                 (j-1) * low <= sigma - m <= (j-1) * high 
  //
  // Equivalently, we can further restrict m so that
  //
  //           sigma - (j-1) * high <= m <= sigma - (j-1) * low
  //
  // Finally, we show how to do the computation for successive values of j
  // in-place. It is not obvious how to do this because we need the values
  // Pr[S_(j-1) = t] from the previous iteration to compute Pr[S_j = s].
  //
  // Let Q be a single, sufficiently long array.  In iteration j, define
  // &Pr[S_j = s] = (Q - j * low + s), where r = (high - low) is the range
  // of single-residue-pair scores.  Suppose further that we compute 
  // Pr[S_j = s] for s from j*high downto j*low.
  //
  // Consider the computation for Pr[S_j = sigma].  The result will 
  // overwrite the cell at
  //
  //     &Pr[S_j = sigma] 
  //    = Q - j * low + sigma
  //
  // But the highest-numbered cell possibly read by this computation is
  //
  //     &Pr[S_(j-1) = sigma - low] 
  //    = Q - (j-1) * low + sigma - low
  //    = Q - j * low + sigma
  //
  // Thus, it is always safe to store the result Pr[S_j = sigma] after
  // its computation is finished.
  //
  
  ScoreDistn *sdsum = new ScoreDistn(matchLength * _low,
				     matchLength * _high);
  double *Q = sdsum->rawArray();
  double *pPrev = Q, *pSum = NULL;
  
  pPrev[0] = 1.0; // base case
  
  for (int j = 1; j <= (int) matchLength; j++)
    {
      pSum = Q - j * _low;
      
      // Update the probabilities Pr[S_j = sigma] for every score sigma.
      //
      for (ScoreT sigma = j * _high; sigma >= j * _low; sigma--)
	{
	  ScoreT lowBound  = MAX(_low,  sigma - (j - 1) * _high);
	  ScoreT highBound = MIN(_high, sigma - (j - 1) * _low);
	  
	  double p = 0.0;
	  for (ScoreT m = lowBound; m <= highBound; m++)
	    p += pPrev[sigma - m] * probs[m];
	  
	  pSum[sigma] = p;
	}
      
      pPrev = pSum;
    }
  
  return sdsum;
}
