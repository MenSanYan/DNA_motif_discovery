//
// INTERVAL.CC
// A closed, directed interval of a sequence
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include "interval.h"

// relativeTo()
// Express this interval relative to another base interval.  If
// the base interval is in the reverse orientation, our direction
// must change.
//
// NOTE: if interval endpoints are unsigned, this method is safe
// iff base.low() <= low() <= high() <= base.high(),
// that is, iff this interval is contained within the base.
//
Interval Interval::relativeTo(const Interval &base) const
{
  SeqPosn newLow;
  Direction newDir;
  
  if (dir() == base.dir())
    newDir = FORWARD;
  else
    newDir = REVERSE;
  
  if (base.dir() == FORWARD)
    newLow = low() - base.low();
  else
    newLow = base.high() - high();
  
  return Interval(newLow, newLow + length() - 1, newDir);
}
