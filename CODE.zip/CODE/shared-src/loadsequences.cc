//
// LOADSEQUENCES.CC
// Load FASTA-formatted sequence files, possibly with their annotations.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// The files to load may be specified either on the command line or in
// sequence info files. 
//

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <climits>

#include <unistd.h> // for getopt()

#include "loadsequences.h"

#include "vector.h"
#include "parseline.h"
#include "seqio.h"
#include "annoio.h"
#include "fileops.h"

using namespace std;

//
// seqFileInfo describes the information associated with a single
// sequence file.  The file may contain multiple FASTA-formatted
// sequences and may be associated with multiple annotation files.
// Each annotation file describes *one* of the sequences in the file;
// which sequence goes with which annotations is described by the
// vector of sequence numbers for each file.
//
struct SeqFileInfo {
  const char   *seqFileName;             // name of sequence file
  StringVector annotationFileNames;      // names of annotation files
  SeqNumVector annotationFileSeqNums;    // seq #'s associated with anno files
};

typedef Vector<SeqFileInfo> SeqFileInfoVector;


//
// Options handled by this parser
// (Any options not appearing in this list, as well as any extraneous
// non-switch arguments, are passed to a user-supplied helper procedure
// in the order in which they appear.
//
const char commonOptions[] = "-s:a:f:c:AF:zV";

//
// Local flag for printing verbose overview
//
static bool verboseOverview = false;

//
// local prototypes
//
static SeqFileInfoVector readSequenceInfoFile(const char *);
static SeqVector  loadSequenceFiles(SeqFileInfoVector, const Alphabet *,
				    SeqNumVector, bool);
static SeqNumVector parseSeqNumberList(const char *);
static void printSequenceOverview(SeqVector sequences, ostream &os);


//
// loadSequences()
//
// Load all the sequences and annotations specified on the command line.
// Each sequence file to load may be specified as
//
//  -s <sequence file> [-a <anno-directive>]*
//  <anno-directive>: ['@'<num>] <anno-filename>]
//
// where @<num> indicates that the following annotation file applies to
// the <num>th sequence (counting from 1) in the file.  Other options
// parsed by loadSequences include:
//
//  -f <sequence info file> -- contains the same info as above, but
//                             stored in a text file, one seq file per line
//  -c <numlist>            -- the numbered sequences (counting globally
//                             over *all* sequences loaded) should
//                             be reverse-complemented on input.
//                             Numbers start from 1.
//
// Sequence files are loaded and their sequences numbered consecutively
// starting from 0 in the order specified on the command line.  If a
// sequence info file is loaded with -f, its sequences are inserted into
// the global order as if they had been specified on the command line
// at the point where the -f option occurred.
//
// Other options may be specified by the getopt-style string specificOptions.
// Whenever one of these options or a non-option string is encountered, it
// is passed to a user-supplied function handleArgument(optchar, optarg)
// in the order in which it is encountered.
//
// Annotation files are loaded by default but may be ignored if the
// caller specifies loadAnnotations == false.
//
// RETURNS: a vector of SeqInfo, one element per loaded sequence,
//          including any annotations loaded for that sequence.
//
// EFFECTS: if loadSequences() encounters an error parsing the command
//          line, reading a sequence info file, or reading a sequence
//          or annotation file, it prints an error message
//          and exits with code 1.
//
SeqVector loadSequences(int argc, char *argv[],
			const char *specificOptions,
			bool loadAnnotations)
{
  enum ParseState { ANY_OPT, IN_SEQ, IN_ANNO } parseState;
  Alphabet *alphabet;
  const char *scoreFunctionName = NULL;
  SeqFileInfoVector infoVec;
  SeqFileInfo *info = NULL;
  SeqNumVector inputReversals;
  bool readAsProtein = false;
  bool smashLowerCase = false;
  SeqVector sv;
  int optchar;
  
  //
  // Concatenate the user's specific options with our common options
  //
  char *allOptions = 
    new char [strlen(commonOptions) + strlen(specificOptions) + 1];
  strcpy(allOptions, commonOptions);
  strcat(allOptions, specificOptions);
  
  // Main Parsing loop
  //
  //  Handle all options that we recognize.  Pass any other
  //  options off to the caller's handleArgument() callback.
  //
  //  Because annotations must follow sequence directives and
  //  may span more than one token after the switch, we need to
  //  keep some state in the command-line parser to interpret
  //  tokens and detect errors.
  //
  parseState = ANY_OPT;
  while ((optchar = getopt(argc, argv, allOptions)) >= 0)
    {
      switch (optchar)
	{
	case 1:                                    // a non-switch token
	  if (parseState == IN_ANNO)
	    {
	      // token is an annotation file name
	      info->annotationFileNames.add(optarg);
	      parseState = IN_SEQ;
	    }
	  else
	    {
	      // token is not part of any option we know of
	      handleArgument(optchar, optarg);
	      parseState = ANY_OPT;
	    }
	  break;
	  
	case 's':                                   // sequence filename
	  if (!(parseState == IN_SEQ || parseState == ANY_OPT))
	    goto error_incomplete_annotation;
	  else // create a new sequence file info record
	    {
	      SeqFileInfo newInfo;
	      newInfo.seqFileName = optarg;
	      
	      infoVec.add(newInfo);
	      info = &(infoVec[infoVec.length() - 1]);
	      
	      parseState = IN_SEQ;
	    }
	  break;
	  
	case 'a':                                   // annotation directive
	  if (parseState != IN_SEQ)
	    {
	      cerr << "Error: annotation '-a " << optarg
		   << "' must follow '-s <sequence file>'\n";
	      goto error;
	    }
	  
	  if (optarg[0] == '@' && isdigit(optarg[1]))
	    {
	      // Argument indicates which sequence in the file should
	      // receive the following annotation info.
	      //
	      SeqNumber num = SeqNumber( strtoul(optarg + 1, NULL, 10) ); 
	      
	      if (num == 0)
		{
		  cerr << "Error in '@': sequence numbers must be >= 1\n";
		  goto error;
		}
	      
	      info->annotationFileSeqNums.add(num - 1);
	      parseState = IN_ANNO;
	    }
	  else
	    {
	      // Argument is a filename; assume annos apply
	      // to first sequence in the file.
	      //
	      info->annotationFileNames.add(optarg);
	      info->annotationFileSeqNums.add(0);
	      parseState = IN_SEQ;
	    }
	  break;
	
	case 'f':                                // read seq info file
	  if (!(parseState == IN_SEQ || parseState == ANY_OPT))
	    goto error_incomplete_annotation;
	  else
	    {
	      SeqFileInfoVector vec = readSequenceInfoFile(optarg);
	      if (vec.isEmpty())
		{
		  cerr << "Warning: sequence file " << optarg
		       << " is empty.\n";
		}
	      
	      infoVec.concat(vec);
	      parseState = ANY_OPT;
	    }
	  break;
      
	case 'c':                                // list of input reversals
	  if (!(parseState == IN_SEQ || parseState == ANY_OPT))
	    goto error_incomplete_annotation;
	  else
	    {
	      inputReversals = parseSeqNumberList(optarg);
	      if (inputReversals.isEmpty())
		{
		  cerr << "Error: could not parse reversal list "
		       << "'-c " << optarg << "'\n";
		  goto error;
		}
	      else
		{
		  // Convert 1-based seqNums to internal, 0-based form.
		  //
		  for (unsigned int j = 0; j < inputReversals.length(); j++)
		    {
		      if (inputReversals[j] == 0)
			{
			  cerr << "Error in '-c': sequence numbers must "
			       << "be >= 1\n";
			  goto error;
			}
		      else
			inputReversals[j]--;
		    }
		}
	      
	      parseState = ANY_OPT;
	    }
	  break;
	  
	case 'z':
	  smashLowerCase = true;
	  break;
	  
	case 'A':
	  readAsProtein = true;
	  break;
	  
	case 'F':
	  scoreFunctionName = optarg;
	  break;
	  
	case 'V':
	  verboseOverview = true;
	  break;
	  
	case '?':
	  cerr << "Error: unknown or incomplete option '-" 
	       << char(optchar) << "'\n";
	  goto error;
	  
	default:
	  if (!(parseState == IN_SEQ || parseState == ANY_OPT))
	    goto error_incomplete_annotation;
	  else
	    {
	      handleArgument(optchar, optarg);
	      parseState = ANY_OPT;
	    }
	  break;
	}
    }
  
  delete [] allOptions;
  
  if (scoreFunctionName)
    {
      const char *scoreFileName = computeFullScorePath(scoreFunctionName);
      
#ifdef VERBOSE
      cerr << "Reading sequence alphabet from score file "
	   << scoreFileName << '\n';
#endif
      
      alphabet = new Alphabet(scoreFileName, (readAsProtein 
					      ? Alphabet::PROTEIN
					      : Alphabet::DNA));
      if (!alphabet->isValid())
	{
	  cerr << "ERROR: could not obtain sequence alphabet from file "
	       << scoreFileName << '\n';
	  exit(1);
	}
      delete [] scoreFileName;
      
      // The caller may also have requested the score function argument
      if (strchr(specificOptions, 'F'))
	handleArgument('F', scoreFunctionName);
    }
  else if (readAsProtein)
    {
      alphabet = new Alphabet(Alphabet::PROTEIN, "acdefghiklmnpqrstvwy", "x");
    }
  else
    {
      alphabet = new Alphabet(Alphabet::DNA, "acgt", "x");
    }
  
  if (alphabet->isProtein() && !inputReversals.isEmpty())
    {
      cerr << "Warning: ignoring requests to take reverse complement "
	   << "of protein sequences!\n";
    }
  
  if (smashLowerCase)
    alphabet->forceLowerCaseToX();
  
  sv = loadSequenceFiles(infoVec, alphabet,
			 inputReversals, loadAnnotations);
  
#ifdef ONE_SEQ_ONLY
  if (sv.length() > 1 || scoreFunctionName != NULL)
    {
      cerr << "Error: tools were compiled with -DONE_SEQ_ONLY;\n"
	   << "       cannot handle more than one sequence or\n"
	   << "       the -F option!\n";
      exit(1);
    }
#endif
  
  printSequenceOverview(sv, cerr);
  
  return sv;
  
 error_incomplete_annotation:
  cerr << "Error: incomplete annotation directive for seq file "
       << info->seqFileName << '\n';
 
 error:
  exit(1);
}


//
// readSequenceInfoFile()
// Parse a file containing sequence file information analogous to the 
// info passed by -s and -a on the command line.
//
// Format of each line:
//  <line>: <sequence file> [<anno directive>]*
//  <anno directive>: ['@'<number>] <anno file>
//
// The @<number> notation indicates the the annotations apply to
// the <number>th sequence in the file [1-based].
//
// RETURNS: a vector of SeqFileInfo structs containing all the
// listed sequence files and their annotation files.
//
static SeqFileInfoVector readSequenceInfoFile(const char *fileName)
{
  static char buf[PATH_MAX + 1];
  SeqFileInfoVector infoVec;
  unsigned int lineNum;
  
  ifstream infile(fileName);
  if (!infile)
    {
      cerr << "Error: could not open sequence info file " << fileName << '\n';
      exit(1);
    }
  
  for (lineNum = 1; !infile.eof(); lineNum++)
    {
      SeqFileInfo info;
      
      // check for EOF or blank line
      if (!consumeWhiteSpace(infile))
	{
	  if (infile.eof())
	    break;
	  else
	    {
	      infile.get(); // consume EOL
	      continue;
	    }
	}
      
      // Get name of sequence file.
      //
      if (!parseString(infile, buf, PATH_MAX + 1))
	{
	  cerr << "Error: filename too long: " << buf << "...\n";
	  goto error;
	}
      else
	{
	  char *seqFileName = new char [strlen(buf) + 1];
	  strcpy(seqFileName, buf);
	  info.seqFileName = seqFileName;
	}
      
      // Read annotation directives, either filenames or '@<num>' pairs.
      //
      for (;;)
	{
	  // Get next directive
	  //
	  if (!parseString(infile, buf, PATH_MAX + 1))
	    {
	      int nextChar = infile.get();
	      
	      if (nextChar == EOF || nextChar == EOL) // ran out of directives
		break;
	      else
		{
		  cerr << "Error: filename too long: " << buf << "...\n";
		  goto error;
		}
	    }
	  else 
	    {
	      // Is directive '@<num>'?  If so, expect anno filename to
	      // follow. Otherwise, treat read string itself as anno filename.
	      //
	      if (buf[0] == '@' && isdigit(buf[1])) // specific annotation info
		{
		  SeqNumber num = SeqNumber( strtoul(buf + 1, NULL, 10) );
		  
		  if (num == 0)
		    {
		      cerr << "Error: sequence numbers must be >= 1\n";
		      goto error;
		    }
		  
		  info.annotationFileSeqNums.add(num - 1);
		  
		  if (!parseString(infile, buf, PATH_MAX + 1))
		    {
		      int nextChar = infile.peek();
		      
		      if (nextChar == EOF || nextChar == EOL)
			cerr << "Error: premature end-of-line "
			     << "while parsing annotation directive\n";
		      else
			cerr << "Error: filename too long: " << buf << "...\n";
		      
		      goto error;
		    }
		}
	      else
		info.annotationFileSeqNums.add(0);
	      
	      // store anno filename
	      char *annoFileName = new char [strlen(buf) + 1];
	      strcpy(annoFileName, buf);
	      info.annotationFileNames.add(annoFileName);
	    }
	}
      
      infoVec.add(info);
    }
  
  return infoVec;
  
 error:
  cerr << "Error parsing sequence info file on line " << lineNum << '\n';
  exit(1);
}


//
// loadSequenceFiles()
// Load all the sequence files and annotations specified by the information
// in infoVec.  Reverse-complement any sequences whose numbers are in
// inputReversals.  If loadAnnotations is true, load the accompanying
// annotation files for the sequences as well.
//
// RETURNS: vector of seqInfo for all loaded sequences.
//
static SeqVector loadSequenceFiles(SeqFileInfoVector infoVec,
				   const Alphabet *alphabet,
				   SeqNumVector inputReversals,
				   bool loadAnnotations)
{
  SeqVector sequences;
  
  for (unsigned int j = 0; j < infoVec.length(); j++)
    {
      SeqNumber firstSeqNum = sequences.length();
      SeqFileInfo &info = infoVec[j];
      SeqVector s;
      
      // read the sequence file
      {
	ifstream seqFile(info.seqFileName);
	if (!seqFile)
	  {
	    cerr << "Error: could not open sequence file " 
		 << info.seqFileName << '\n';
	    exit(1);
	  }
	s = readSequencesFromStream(seqFile, alphabet,
				    inputReversals, firstSeqNum);
      }
      
      if (s.isEmpty())
	{
	  cerr << "Warning: could not read any sequences from file "
	       << infoVec[j].seqFileName << '\n';
	}
      else if (loadAnnotations)
	{
	  const StringVector annoFileNames = info.annotationFileNames;
	  const SeqNumVector annoSeqNums   = info.annotationFileSeqNums;
	  
	  for (unsigned int k = 0; k < annoFileNames.length(); k++)
	    {
	      const char *annoFileName = annoFileNames[k];
	      SeqNumber   seqNum       = annoSeqNums[k];
	      
	      if (seqNum >= s.length())
		{
		  cerr << "Error: annotation file " << annoFileName
		       << " applies to sequence #" << seqNum + 1
		       << ", but only " << s.length() 
		       << " sequences were read\n";
		  exit(1);
		}
	      else
		{
		  AnnotationVector a;
		  
		  // read the annotation file
		  {
		    ifstream annoFile(annoFileName);
		    if (!annoFile)
		    {
		      cerr << "Error: could not open annotation file "
			   << annoFileName << '\n';
		      exit(1);
		    }
		  
		    a = readAnnotationsFromStream(annoFile, 
						  seqNum + firstSeqNum);
		  }
		  
		  if (a.isEmpty())
		    {
		      cerr << "Warning: could not read any annotations "
			   << "from file " << annoFileName << '\n';
		    }
		  else
		    s[seqNum].annotations.concat(a);
		}
	    }
	}
      
      sequences.concat(s);
    }
  
  return sequences;
}


//
// parseSeqNumberList()
// Parse a list of sequence numbers, storing their values into
// the vector 'numbers'.
//
// A (nonempty) number list is of the form <value>[,<value>]* where
// <value> is either a single number or a range <number>-<number>,
// denoting all the values between the range's endpoints.
//
// RETURNS: vector of numbers parsed.
//
static SeqNumVector parseSeqNumberList(const char *numList)
{
  const char *listPtr = numList;
  SeqNumVector numbers, emptyVector;
  
  while (listPtr != NULL)
    {
      const char *nextBreak;
      char *endPtr;
      SeqNumber lowNum;
      
      if (!isdigit(*listPtr))
        {
          cerr << "invalid or missing number in list\n";
          return emptyVector;
        }
      
      nextBreak = strpbrk(listPtr, ",");
      
      lowNum = SeqNumber( strtoul(listPtr, &endPtr, 10) );
      if (lowNum == 0)
        {
          cerr << "Zero is not a valid sequence number.\n";
          return emptyVector;
        }
      else if (*endPtr == '-') // must read a range
        {
          listPtr = endPtr + 1;
          SeqNumber highNum = SeqNumber( strtoul(listPtr, &endPtr, 10) );
          if (listPtr == endPtr) // invalid number
            {
              cerr << "Invalid or missing number in range\n";
              return emptyVector;
            }
          else if (highNum < lowNum)
            {
              cerr << "Invalid range\n";
              return emptyVector;
            }
          else
            {
              for (SeqNumber j = lowNum; j <= highNum; j++)
                numbers.add(j);
            }
        }
      else
        numbers.add(lowNum);
      
      listPtr = (nextBreak ? nextBreak + 1 : 0);
    }
  
  return numbers;
}



//////////////////////////////////////////////////////////////////////////


// Max # of characters of sequence title to print for overview
const int MaxOverviewPrintLength = 55;

//
// printSequenceOverview()
// Inform the user about the input sequences
//
static void printSequenceOverview(SeqVector sequences, ostream &os)
{
  if (sequences.isEmpty())
    return;
  
  if (verboseOverview)
    {
      os << "*** INPUT SEQUENCES ***\n";
      for (unsigned int s = 0; s < sequences.length(); s++)
	{
	  SeqInfo *info = &(sequences[s]);
	  
	  os << info->seqNum + 1 << " (n=" << info->length
	     << (info->complement ? " [RC]" : "");
	  os << ")\t";
	  if (info->title[0])
	    {
	      char titleBuf[MaxOverviewPrintLength + 1];
	      titleBuf[MaxOverviewPrintLength] = 0;
	      strncpy(titleBuf, info->title, MaxOverviewPrintLength);
	      
	      os << '>' << titleBuf << '\n';
	    }
	  else
	    os << "[no FASTA title]\n";
	  
	  if (!info->annotations.isEmpty())
	    {
	      os << "  (sequence has " << info->annotations.length()
		 << " annotations)\n";
	    }
	}
    }
  else
    os << "*** READ " << sequences.length() << " SEQUENCES ***\n";
  
  os << '\n';
}


//
// Print usage for common arguments for all programs using loadSequences()
//
void printSequenceUsage(void)
{
  cerr << "Sequence options (any number of sequences allowed):\n\n";
  
  cerr << "  -s <sequence file> [-a [@<num>] <annotation file>]*\n"
       << "    Load all the sequences in a FASTA-formatted sequence file.\n"
       << "    Optionally, load any number of annotation files.  By\n"
       << "    default, annotations apply to the first sequence in the\n"
       << "    file, but they may assigned to the <num>th sequence by\n"
       << "    specifying '@<num>' before the annotation.\n\n";

  cerr << "  -f <sequence info file>\n"
       << "    Read a sequence info file to get a list of sequence files to\n"
       << "    load.  Each line of the info file has the form\n"
       << "       <sequence file> [ [@<num>] <annotation file>]*\n\n";
  
  cerr << "  -c <num>[,<num>]*\n"
       << "    Reverse-complement the sequences specified by the numbers\n"
       << "    in a comma-separated list.  Sequences are numbered starting\n"
       << "    with 1 in the order in which they are read.\n\n";
  
  cerr << "  -A\n"
       << "    Treat all input sequences as protein (default is DNA;\n"
       << "    choice is overridden by FASTA-formatted score file)\n\n";
  
  cerr << "  -V\n"
       << "    Print a verbose list of all input sequences read\n\n";
  
  cerr << "  -z\n"
       << "    Mask out all lower-case residues\n";
}
