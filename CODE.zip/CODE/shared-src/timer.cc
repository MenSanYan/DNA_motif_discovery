//
// TIMER.CC
// Trivial timer code (UNIX implementation)
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <sys/time.h>
#include <unistd.h>

#include "timer.h"

static struct timeval tStart;

// start the timer
void startTimer(void)
{
  gettimeofday(&tStart, NULL);
}

// stop the timer and return the number of seconds elapsed
double stopTimer(void)
{
  struct timeval tEnd;
  double totalTime;
  
  gettimeofday(&tEnd, NULL);
  
  totalTime = 
    ((1e+6 * tEnd.tv_sec + tEnd.tv_usec) - 
     (1e+6 * tStart.tv_sec + tStart.tv_usec)) / 1e+6;
  
  return totalTime;
}
