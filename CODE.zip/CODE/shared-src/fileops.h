//
// FILEOPS.H
// Operations on filenames
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __FILEOPS_H
#define __FILEOPS_H

#include <climits> // for PATH_MAX

const char DirSeparator = '/';
const char DirSepString[2] = { DirSeparator, 0 };

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

char *computeFullScorePath(const char *scoreFileName);

#endif
