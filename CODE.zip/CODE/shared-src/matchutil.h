//
// MATCHUTIL.CC
// Code to sort matches, remove duplicates, and merge overlaps.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//

#ifndef __MATCHUTIL_H
#define __MATCHUTIL_H

#include "match.h"

MatchVector removeDuplicateMatches(MatchVector ms);
MatchVector mergeOverlappingMatches(MatchVector ms, bool deleteOnly = false);

inline MatchVector removeOverlappingMatches(MatchVector ms)
{ return mergeOverlappingMatches(ms, true); }

int cmpMatchesByStart(const void *p0, const void *p1);
int cmpMatchesByFrame(const void *p0, const void *p1);

#endif
