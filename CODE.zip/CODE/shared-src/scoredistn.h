//
// SCOREDISTN.H
// Compute score distributions
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __SCOREDISTN_H
#define __SCOREDISTN_H

#include "scorefunction.h"
#include "seqinfo.h"
#include "seqops.h"

class ScoreDistn {
public:
  ScoreDistn(const double *d1, const double *d2, const ScoreMatrix &M);
  
  ~ScoreDistn(void)
  {
    double *data = probs + _low;
    delete [] data;
  }
  
  // lowest and highest scores in the distribution
  ScoreT low(void)  const { return _low; }
  ScoreT high(void) const { return _high; }
  
  // any element of the distribution
  double &operator[](int j) const { return probs[j]; }
  
  // Compute the distribution of scores for ungapped runs of
  // matchLength residues, distributed as specified in constructor.
  //
  ScoreDistn *computeSumDistn(SeqLength matchLength) const;
  
private:
  ScoreT _low, _high;      // lowest and highest scores
  double *probs;           // distribution on scores
  
  ScoreDistn(ScoreT ilow, ScoreT ihigh)
  {
    init(ilow, ihigh);
  }
  
  void init(ScoreT low, ScoreT high)
  {
    _low = low; _high = high;
    double *data = new double [_high - _low + 1];
    probs = data - _low;
  }
  
  double *rawArray(void) const { return probs + _low; }
};

#endif
