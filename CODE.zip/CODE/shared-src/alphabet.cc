//
// ALPHABET.CC
//
// Implementation of the Alphabet class
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <cstring>
#include <cctype>
#include <climits>

#include "alphabet.h"

using namespace std;

const char DNARealBases[]      = "acgt";
const char DNARequiredXBases[] = "xn";
const char DNAOptionalXBases[] = "ryswkmhbvd";

const char DNARealComplements[]      = "tgca";
const char DNAOptionalXComplements[] = "yrswmkdvbh";
const char DNAPurines[]              = "agr";
const char DNAPyrimidines[]          = "cty";

const char ProteinRealAminos[]      = "acdefghiklmnpqrstvwy";
const char ProteinRequiredXAminos[] = "xj";
const char ProteinOptionalXAminos[] = "bz";


//
// init()
// Initialize an Alphabet for either DNA or protein.  A somewhat
// compex set of initialization rules handles input alphabets that
// may consider certain characters to be either real or X residues.
// The initialization rules are as follows:
//
//  1. Every input residue in residueNames gets a unique number,
//     except that those in the list of required X's are always
//     mapped to RESIDUE_X.
//  2. Any residues in addlXNames get mapped to RESIDUE_X.
//  3. Every "optional" X residue that does not appear in residueNames
//     gets mapped to RESIDUE_X.
//  4. For DNA, if a given residue is defined, so too must be its
//     complement.
//
// The first X residue seen determines the value printed for RESIDUE_X.
//
// It is expected that residueNames contains at most one X name and
// all of the required real residue names for the alphabet type
// (e.g. ACGT for DNA).
//
// As a special case, for DNA alphabets, T and U are considered equivalent.
// Exactly one of these must be specified in residueNames, but both
// are always understood.
//
// NOTE: why all these weird rules?  The alphabet declarations come
// from score function files, and we need to make sure that there
// is nothing we can't handle there.
//
void Alphabet::init(Type type, 
		    const char *residueNames, 
		    const char *addlXNames)
{
  char iresidue2char[MAX_RESIDUES];
  unsigned int nRealResidues = 0;
  bool seenX = false;
  
  _type = type;
  char2residue = new Residue [256];
  memset(char2residue, (Residue) INVALID_CHAR, 256 * sizeof(Residue));
  
  const char *realResidues, *requiredXResidues, *optionalXResidues;
  if (type == DNA)
    {
      realResidues      = DNARealBases;
      requiredXResidues = DNARequiredXBases;
      optionalXResidues = DNAOptionalXBases;
    }
  else // type == PROTEIN
    {
      realResidues      = ProteinRealAminos;
      requiredXResidues = ProteinRequiredXAminos;
      optionalXResidues = ProteinOptionalXAminos;
    }
  
  // First, map all the input names to residues.  Any character not
  // required to be an X is assigned a real residue number.  Warn
  // if multiple X's are specified among the basic residue names
  // (since this may indicate that they are treated differently).
  //
  for (unsigned int j = 0; j < strlen(residueNames); j++)
    {
      char c = residueNames[j];
      
      if (strchr(requiredXResidues, tolower(c)))
	{
	  if (seenX)
	    {
	      cerr << "Warning: multiple X residues specified in "
		   << "alphabet; printed value will be '"
		   << c << "' (was '" 
		   << iresidue2char[RESIDUE_X] << "')\n";
	    }
	  
	  char2residue[toupper(c)] = RESIDUE_X;
	  char2residue[tolower(c)] = RESIDUE_X;
	  iresidue2char[RESIDUE_X]  = c;
	  seenX = true;
	}
      else
	{
	  char canonicalChar;
	  
	  if (type == DNA && toupper(c) == 'U') // T and U are equivalent
	    canonicalChar = 'T';
	  else
	    canonicalChar = c;
	  
	  if (char2residue[canonicalChar] != INVALID_CHAR)
	    cerr << "Warning: duplicate residue '" << c << "' ignored\n";
	  else
	    {
	      Residue nextResidue = (Residue) ++nRealResidues;
	      char2residue[toupper(canonicalChar)] = nextResidue;
	      char2residue[tolower(canonicalChar)] = nextResidue;
	      iresidue2char[nextResidue] = c;
	    }
	}
    }
  
  // Sanity check: are all the non-X residues specified? If not, complain.
  for (unsigned int j = 0; j < strlen(realResidues); j++)
    {
      char c = realResidues[j];
      
      if (char2residue[c] == INVALID_CHAR)
	{
	  Residue r = (Residue) ++nRealResidues;
	  char2residue[toupper(c)] = r;
	  char2residue[tolower(c)] = r;
	  iresidue2char[r] = c;
	  
       	  cerr << "Warning: required residue '" << c << "' missing\n";
	}
    }
  
  // Force equivalence of T with U.
  if (type == DNA)
    {
      Residue rT = char2residue['T'];
      char2residue['U'] = rT;
      char2residue['u'] = rT;
    }

  // Make sure that some X residue has been set.  Use the additional
  // X names if possible; otherwise, use a required X name.
  if (!seenX)
    {
      if (addlXNames != NULL)
	iresidue2char[RESIDUE_X] = addlXNames[0];
      else
	iresidue2char[RESIDUE_X] = requiredXResidues[0];
    }
  
  if (addlXNames != NULL)
    {
      // Handle all the additional X names.
      for (unsigned int j = 0; j < strlen(addlXNames); j++)
	{
	  char c = addlXNames[j];
	  char2residue[toupper(c)] = RESIDUE_X;
	  char2residue[tolower(c)] = RESIDUE_X;
	}
    }
  
  // Handle any required X's not yet specified.
  for (unsigned int j = 0; j < strlen(requiredXResidues); j++)
    {
      char c = requiredXResidues[j];
      char2residue[toupper(c)] = RESIDUE_X;
      char2residue[tolower(c)] = RESIDUE_X;
    }
  
  // Handle any optional X's not defined to something else.
  for (unsigned int j = 0; j < strlen(optionalXResidues); j++)
    {
      char c = optionalXResidues[j];
      
      if (char2residue[c] == INVALID_CHAR) // not yet set
	{
	  char2residue[toupper(c)] = RESIDUE_X;
	  char2residue[tolower(c)] = RESIDUE_X;
	}
    }
  
  // If this is DNA, compute the complement of each residue.  Note that
  // both a residue AND its complement must be defined, so fix up the
  // alphabet if any residues' complements are missing.
  //
  if (type == DNA)
    {
      Residue icomplements[MAX_RESIDUES];
      
      memset(icomplements, INVALID_CHAR, MAX_RESIDUES);
      
      icomplements[RESIDUE_X] = RESIDUE_X;
      
      for (unsigned int j = 0; j < strlen(DNARealBases); j++)
	{
	  char c     = DNARealBases[j];
	  char cComp = DNARealComplements[j];
	  
	  Residue r = char2residue[c];
	  Residue rComp = char2residue[cComp];
	  
	  icomplements[r] = rComp;
	}
      
      for (unsigned int j = 0; j < strlen(DNAOptionalXBases); j++)
	{
	  char c     = DNAOptionalXBases[j];
	  char cComp = DNAOptionalXComplements[j];
	  
	  Residue r = char2residue[c];
	  if (r != RESIDUE_X)
	    {
	      Residue rComp = char2residue[cComp];
	      if (rComp == RESIDUE_X)
		{
		  cerr << "Warning: complementary bases '" 
		       << c << "' and '" << cComp
		       << "' must both be defined\n";
		  
		  rComp = ++nRealResidues;
		  char2residue[tolower(cComp)] = rComp;
		  char2residue[toupper(cComp)] = rComp;
		  iresidue2char[rComp] = cComp;
		}
	      
	      icomplements[r] = rComp;
	    }
	}
      
      // sanity check: are all residues complemented or X?
      for (Residue r = 0; r < nRealResidues + 1; r++)
	{
	  if (icomplements[r] == INVALID_CHAR)
	    {
	      cerr << "Warning: residue '" 
		   << iresidue2char[r]
		   << "'is not recognized as DNA; it has "
		   << "no defined complement\n";
	      
	      icomplements[r] = RESIDUE_X;
	    }
	}
      
      complements = new Residue [nRealResidues + 1];
      memcpy(complements, icomplements, (nRealResidues + 1) * sizeof(Residue));
    }
  else // type != DNA
    complements = NULL;
  
  _nResidues = nRealResidues + 1;
  
  residue2char = new char [_nResidues];
  memcpy(residue2char, iresidue2char, _nResidues * sizeof(char));
  
  if (type == DNA)
    initPurpyrStatus();
  else
    purpyrStatus = NULL;
}


//
// initPurpyrStatus()
// Decide whether each input residue is a purine or a pyrimidine,
// and save that information so we can look it up quickly.
//
void Alphabet::initPurpyrStatus(void)
{
  purpyrStatus = new PurPyrClass [_nResidues];
  
  for (unsigned int j = 0; j < _nResidues; j++)
    purpyrStatus[j] = NEITHER;
  
  for (unsigned int j = 0; j < strlen(DNAPurines); j++)
    {
      Residue r = fromChar(DNAPurines[j]);
      if (r != RESIDUE_X)
	purpyrStatus[r] = PURINE;
    }
  
  for (unsigned int j = 0; j < strlen(DNAPyrimidines); j++)
    {
      Residue r = fromChar(DNAPyrimidines[j]);
      if (r != RESIDUE_X)
	purpyrStatus[r] = PYRIMIDINE;
    }
}

      
// destructor
Alphabet::~Alphabet(void)
{
  if (residue2char) delete [] residue2char;
  if (char2residue) delete [] char2residue;
  
  if (complements)  delete [] complements;
  if (purpyrStatus) delete [] purpyrStatus;
}


//////////////////////////////////////////////////////////////////////////

//
// file constructor
// Read the sequence alphabet from a score file, which may be either
// BLAST- or FASTA-formatted.
//
Alphabet::Alphabet(const char *fileName, Type defaultType)
{
  ifstream is(fileName);
  char c;
  
  if (!is)
    {
      cerr << "Error: Alphabet could not open file " << fileName << '\n';
      _valid = false;
      return;
    }
  
  is >> c;
  
  if (c == ';') // FASTA score file start character
    {
      _valid = readFromFastaFile(is, defaultType);
    }
  else
    {
      is.putback(c);
      _valid = readFromBlastFile(is, defaultType);
    }
}


inline void discardToEOL(istream &is)
{
  is.ignore(INT_MAX, '\n');
}


//
// readFromFastaFile()
// Read the sequence alphabet from a FASTA-formatted score file.
//
bool Alphabet::readFromFastaFile(istream &is, Alphabet::Type itype)
{
  Type type;
  char c;
  
  is >> c;
  switch (toupper(c))
    {
    case 'P':
      type = PROTEIN;
      break;
      
    case 'D':
      type = DNA;
      break;
      
    default:
      cerr << "Warning: FASTA score function has unknown type '" << c << "'\n";
      cerr << "  (assuming type "
	   << (itype == DNA ? "DNA" : "protein") 
           << ")\n";
      type = itype;
      break;
    }
  discardToEOL(is);
  
  // ignore lines 2-4
  discardToEOL(is);
  discardToEOL(is);
  discardToEOL(is);
  
  char names[257];
  int nNames = 0;
  
  // read the alphabet chars on this line
  while (is)
    {
      c = is.get();
      
      if (c == '\n' || c == EOF)
        break;
      else if (isspace(c))
        continue;
      else
        names[nNames++] = c;
    }
  
  names[nNames] = 0;
  init(type, names, NULL);
  return true;
}


//
// readFromBlastFile()
// Read the sequence alphabet from a BLAST-formatted score file.
//
bool Alphabet::readFromBlastFile(istream &is, Alphabet::Type type)
{
  // ignore any initial comment lines
  for (;;)
    {
      char c;
      
      is >> c;
      if (c == '#')
        discardToEOL(is);
      else
        {
          is.putback(c);
          break;
        }
    }
  
  char names[257];
  int nNames = 0;
  
  while (is)
    {
      char c = is.get();
      
      if (c == '\n' || c == EOF)
        break;
      else if (isspace(c))
        continue;
      else if (c != '*') // ignore terminal * row/column
        names[nNames++] = c;
    }
  
  names[nNames] = 0;
  init(type, names, NULL);
  
  return true;
}

//////////////////////////////////////////////////////////////

void Alphabet::forceLowerCaseToX()
{
  for (char c = 'a'; c <= 'z'; c++)
    if (char2residue[toupper(c)] != INVALID_CHAR)
      char2residue[c] = RESIDUE_X;
}
