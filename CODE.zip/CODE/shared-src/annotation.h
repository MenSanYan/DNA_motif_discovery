//
// ANNOTATION.H
// Description of annotation object
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// An Annotation is a contiguous range of sequence positions with
// information about what's present there.  It includes a feature
// name, a type, a starting index (> 0 if this range is not the
// first in this feature), and a strand (fwd or reverse).
//
#ifndef __ANNOTATION_H
#define __ANNOTATION_H

#include <cstring>

#include "datatypes.h"
#include "direction.h"
#include "interval.h"
#include "vector.h"

class Alignment;

//
// We could make this a full class by hiding all the data members,
// but it doesn't seem worth the effort.  Instead, we expose the data
// members but supply convenient constructors and such so that each
// Annotation can keep its own copy of feature name and type.
//
struct Annotation {
public:
  char *name;              // feature name
  char *type;              // feature type
  SeqNumber seqNum;        // number of sequence in which it appears
  SeqPosn startIdx;        // for multirange features, index of start posn
  
  Interval i;              // low, high, dir == strand
  
  const Alignment *lastAlignment;  // last algn seen involving this annotation
  
  //
  // Default constructor does nothing
  //
  Annotation(void) 
    : name(NULL), type(NULL), startIdx(0), lastAlignment(NULL)
    {}
  
  //
  // Constructor which takes name, type, and optional index for multiple seq
  //
  Annotation(const char *iname, const char *itype, SeqPosn istart = 0)
    : name(NULL), type(NULL), lastAlignment(NULL)
    {
      setName(iname);
      setType(itype);
      startIdx = istart;
    }
  
  //
  // Copy constructor and operator= (very similar)
  //
  Annotation(const Annotation &other)
    : name(NULL), type(NULL)
    {
      copy(other);
    }
  
  Annotation &operator=(const Annotation &other)
    {
      if (this != &other) copy(other);
      return *this;
    }
  
  // Destructor: free strings for name and type
  ~Annotation(void)
    {
      if (name) delete [] name;
      if (type) delete [] type;
    }
  
  
  // Set the name of an Annotation, making it a local copy.
  void setName(const char *iname)
    {
      if (name)	delete [] name;
      
      if (iname)
	{
	  name = new char [std::strlen(iname) + 1];
	  std::strcpy(name, iname);
	}
      else
	name = NULL;
    }
  
  // Set the type of an Annotation, making it a local copy.
  void setType(const char *itype)
    {
      if (type) delete [] type;
      
      if (itype)
	{
	  type = new char [std::strlen(itype) + 1];
	  std::strcpy(type, itype);
	}
      else
	type = NULL;
    }
  
private:
  
  // Common copying code shared by copy constructor & operator=
  void copy(const Annotation &other)
    {
      setName(other.name);
      setType(other.type);
      
      startIdx = other.startIdx;
      seqNum   = other.seqNum;
      i        = other.i;
      
      lastAlignment = other.lastAlignment;
    }
};

typedef Vector<Annotation> AnnotationVector;

#endif
