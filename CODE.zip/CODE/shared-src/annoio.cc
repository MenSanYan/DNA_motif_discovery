//
// ANNOIO.CC
// Read annotation info from a stream.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// Each annotation line is of the form
//
//  <name> <type> <strand> <range> <range>*
//
//  <name>, <type>: strings (possibly quoted with embedded whitspace)
//  <strand>: a string beginning with 'f' (forward) or 'r' or 'c'
//            (reverse complement).  Case is ignored.
//  <range>: <num> <num> indicating start and end on the *forward*
//           strand.
//
// Annotation info is returned as a vector of Annotation structures.
//

#include <iostream>

#include "annoio.h"
#include "parseline.h"

using namespace std;

const int MAXSTRLEN = 256;

//
// local prototypes
//
static void setAnnotationOffsets(AnnotationVector, unsigned int);


//
// readAnnotationsFromStream()
// Read annotations from a stream.  A single annotation is a line of
// the following form:
//
// <name> <type> <strand> [<start> <end>]+
//
//  name   -- name of annotation (arbitrary string)
//  type   -- type of annotation (arbitrary string)
//  strand -- Direction indicating whether anno is on fwd or r/c strand
//  start, end -- range of the annotation on the FORWARD STRAND (1-based)
//
// All annotations read will have their 'seqNum' fields set to the
// passed-in value.
//
// RETURNS: vector of annotations read
//
AnnotationVector readAnnotationsFromStream(istream &is, SeqNumber seqNum)
{
  AnnotationVector annotations;
  int lineNum;
  
  for (lineNum = 1; !is.eof(); lineNum++)
    {
      char name[MAXSTRLEN + 1];
      char type[MAXSTRLEN + 1];
      Annotation baseAnno;
      Direction strand;
      
      baseAnno.seqNum = seqNum;
      
      // Handle empty lines or EOF at beginning of line.
      if (!consumeWhiteSpace(is))
	{
	  if (is.eof())
	    break;
	  else
	    {
	      is.get(); // consume EOL
	      continue;
	    }
	}
      
      if (!parseString(is, name, MAXSTRLEN + 1))
	goto error;
      else
	baseAnno.setName(name);
      
      if (!parseString(is, type, MAXSTRLEN + 1))
	goto error;
      else
	baseAnno.setType(type);
      
      if (!parseDirection(is, &strand))
	goto error;
      else
	baseAnno.i.setDir(strand);
      
      unsigned int nRanges = 0;
      for (;;)
	{
	  SeqPosn start, end;
	  unsigned long val;
	  
	  // If first # in range fails, we may just be out of ranges.
	  // (at EOF or EOL).  If so, that's OK.
	  //
	  if (!parseNumber(is, &val))
	    {
	      int nextChar = is.get();
	      if (nextChar == EOF || nextChar == EOL)
		break;
	      else
		{
		  cerr << "Error: non-range chars at end of line\n";
		  goto error;
		}
	    }
	  else
	    {
	      start = SeqPosn(val);
	      if (start <= 0)
		{
		  cerr << "Error: sequence indices must be >= 1\n";
		  goto error;
		}
	    }
	  
	  if (!parseNumber(is, &val))
	    goto error;
	  else
	    {
	      end = SeqPosn(val);
	      if (end <= 0)
		{
		  cerr << "Error: sequence indices must be >= 1\n";
		  goto error;
		}
	    }
	  
	  Annotation anno = baseAnno;
	  anno.i.setLow(start - 1);
	  anno.i.setHigh(end - 1);
	  annotations.add(anno);
	  
	  nRanges++;
	}
      
      if (nRanges == 0) // annotation with no ranges???
	{
	  cerr << "Error: annotation contains no sequence ranges\n";
	  goto error;
	}
      else
	setAnnotationOffsets(annotations, nRanges);
    }
  
  return annotations;
  
 error:
  cerr << "Error parsing annotation on line " << lineNum << '\n';
  annotations.truncate();
  return annotations;
}


//
// setAnnotationOffsets()
// Set the start indices for each segement of a multisegment annotation.
// The start index counts the number of characters in the annotation
// between its start and the start of the segment.  For annotations
// on the forward strand, we count from 5' to 3', with each start
// labeling the 5' end of a segment.  For annotations on the reverse
// strand, we count from 3' to 5', with each start labeling the
// 3' end of a segment.
//
static void setAnnotationOffsets(AnnotationVector annotations, 
				 unsigned int nRanges)
{
  int firstAnno = int(annotations.length() - nRanges);
  SeqLength runningLength = 0;
  
  if (annotations[firstAnno].i.dir() == FORWARD)
    {
      for (unsigned int j = firstAnno; j < annotations.length(); j++)
	{
	  annotations[j].startIdx = SeqPosn(runningLength);
	  runningLength += annotations[j].i.length();
	}
    }
  else // direction == REVERSE
    {
      // Use signed j here; otherwise, we'll never terminate
      // if firstAnno == 0.
      //
      for (int j = annotations.length() - 1; j >= firstAnno; j--)
	{
	  annotations[j].startIdx = runningLength;
	  runningLength += annotations[j].i.length();
	}
    }
}
