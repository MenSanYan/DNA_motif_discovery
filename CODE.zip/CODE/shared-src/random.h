//
// RANDOM.H
// Utility functions based on supplied PRNG
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __RANDOM_H
#define __RANDOM_H

#include "prng.h"

// Seed the random number generator.  If seed < 0, construct a seed
// from the current system time.
void seedPRNG(long seed = -1);

// return a random double in range [0..1)
inline double rand01() { return genrand_real2(); }

// return a random integer in range [0..2^31)
inline long randInt() { return genrand_int31(); }

// return a random integer in range [0..2^32)
inline unsigned long randUInt() { return genrand_int32(); }

// return a random integer in range [0..max)
inline unsigned long randVal(unsigned long max)
{
  return (unsigned long) (rand01() * max);
}

#endif
