//
// DATATYPES.H
// Types used to store sequence numbers, positions, and LSH values
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __DATATYPES_H
#define __DATATYPES_H

// SeqPosn is the type for a position within a sequence, while SeqLength
// is the type for the length of a sequence.  Both types should be 
// unsigned.
//
// SeqDiffT is a signed type large enough to hold the difference of
// two SeqPosn's.  WARNING: If sizeof(SeqDiffT) == sizeof(SeqPosn),
// and SeqLength can be up to 2^N - 1, SeqPosns should never exceed
// 2^(N-1) - 1 so that the difference of two SeqPosns can always be
// represented in a SeqDiffT.  For 32-bit ints, this means that you
// should keep your *total* sequence length below 2^30, just to be 
// safe.

typedef unsigned int SeqPosn;
typedef unsigned int SeqLength;
typedef          int SeqDiffT;


// SeqNumber indexes the input sequences and need not be signed.
// It should probably be no more than 2^32.
 
typedef unsigned int SeqNumber;


// LSHValue is the type of a hash value.  It may be 32 or 64 bits,
// depending on how many positions are typically chosen per hash
// function.

typedef unsigned int LSHValue;

#endif
