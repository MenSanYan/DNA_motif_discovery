//
// KARLIN.H
// Karlin-Altschul statistics for (ungapped) sequence alignments
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2002 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// This class implements computations of Karlin-Altschul statistics
// for alignments between biosequences.  We provide significance
// estimation functions given the K and lambda parameters of the score
// distribution, as well as analytical computation of the *ungapped* K
// and lambda values given the raw score function.
//
// Karlin-Altschul theory is outlined in
//
//   Karlin S and Altschul SF (1990). "Methods for assessing the statistical
//     significance of molecular sequence features by using general
//     scoring schemes."  PNAS 87:2264-8.
//
// A later, very helpful paper on this topic with more literature pointers
// and extensions to gapped statistics is
//
//    Altschul SF and Gish W (1996). "Local alignment statistics."
//      Methods in Enzymology 266:460-80.
//
// The basic assumptions of ungapped K&A statistics are as follows.
// We are comparing two sequences of lengths N and M to find the
// optimal ungapped *local* alignment between them using a
// substitution score matrix Sigma : residue x residue -> Real.  We want to
// assess whether the alignment produced has a "surprisingly" high
// score, which might indicate that the sequences share some kind of
// homology, or whether the score is so low as to be background noise.
//
// Assume that the two sequences are unrelated and are composed of
// residues sampled independently at random from distributions D1 and D2.
// Assume further that positive local alignment scores are possible
// with Sigma, but that the expected score (given D1 and D2) is
// negative.  Then, for sufficiently large N and M, the probability
// (again over D1 and D2) that the optimal alignment score S exceeds
// some threshold x approximately follows an extreme value
// distribution
//
//                 Pr[S < x] = exp(- KNM exp(-lambda x))
//
// for parameters K and lambda which depend on D1, D2, and the score
// matrix Sigma. Moreover, the number of distinct local alignments
// with score at least x is approximately Poisson-distributed with
// expectation
//
//                      mu = KNM exp(-lambda x)
// 
// In an alignment of two large sequences (or a sequence vs a
// database), we can assess E-values for each local alignment
// individually using the above formula for mu; these are the E-values
// reported by ungapped BLAST.  Given the Poisson assumption, we can
// also assess p-values: the probability that an alignment with score
// at least x occurs at all by chance is simply 1 - exp(-mu).
//
// A note on terminology: Karlin and Altschul call an optimal local
// alignment a "high-scoring segment pair", or HSP.
//

#ifndef __KARLIN_H
#define __KARLIN_H

#include <cmath>

#include "seqinfo.h"
#include "scorefunction.h"
#include "scoredistn.h"

class KarlinAltschulStats {
public:
  KarlinAltschulStats(const SeqInfo &s, const ScoreMatrix &M);
  KarlinAltschulStats(const SeqInfo &s1, const SeqInfo &s2, 
		      const ScoreMatrix &M);
  KarlinAltschulStats(const ScoreDistn &distn);
  KarlinAltschulStats(double lambda, double K);
  
  //
  // Parameter values
  //
  
  double lambda(void) const { return _lambda; }
  double K(void)      const { return _K; }
  double logK(void)   const { return _logK; }
  
  //
  // Score statistics
  //
  
  // Interconversions between expectation and p-value
  // The number of HSP's above a certain score threhsold is approximately
  // Poisson, which makes the conversions trivial.
  //
  double EtoP(double E) const { return 1 - std::exp(- E); }
  double PtoE(double P) const { return - std::log(1 - P); }
  
  
  // Given a score S and two sequence lengths N and M, compute the
  // expected number of HSP's scoring >= S in the comparison of
  // N and M.
  //
  double StoE(double S, SeqLength N, SeqLength M) const
  { return StoE(S, double(N) * double(M)); }
  
  // Given a score S and two sequence lengths N and M, compute the
  // probability that an HSP will score >= S in the comparison of
  // N and M.
  //
  double StoP(double S, SeqLength N, SeqLength M) const
  { return EtoP(StoE(S, double(N) * double(M))); }
  
  // Compute the score threshold S such that at most E HSP matches with
  // score >= S are expected to occur by chance.
  //
  double EtoS(double E, SeqLength N, SeqLength M) const
  { return EtoS(E, double(N) * double(M)); }
  
  // Compute the score threshold S such that an HSP with at least that score
  // occurs by chance with probability at most P.
  //
  double PtoS(double P, SeqLength N, SeqLength M) const
  { return EtoS(PtoE(P), double(N) * double(M)); }
  
  
  //
  // Short versions of the above functions for use w/precomputed N*M.
  //
  
  double StoP(double S, double NM) const { return EtoP(StoE(S, NM)); }
  double PtoS(double P, double NM) const { return EtoS(PtoE(P), NM); }
  
  double StoE(double S, double NM) const;
  double EtoS(double E, double NM) const;
  
private:
  double _lambda;
  double _K;
  double _logK;   
  
  void initParams(const ScoreDistn &sd);
  
  double computeLambda(const ScoreDistn &) const;
  double computeLambdaSlow(const ScoreDistn &) const;
  double computeK(double, double, const ScoreDistn &) const;
};

#endif
