//
// KARLIN.CC
// Karlin-Altschul statistics
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2002 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// The code for computing ungapped K and lambda follows the
// implementation in BLAST's blastkar.c, which in turn came from
// Stephen Altschul's original karlin.c (released along with the 1990
// K&A BLAST paper).
//
// Note: in general, this code tries pretty hard to minimize transcendental
// function calls but does not care much about bumming adds and multiplies.
//

#include <iostream>

#include "karlin.h"

using namespace std;

////////////////////////////////////////////////////////////////////////////
// CONSTANTS FOR PARAMETER ESTIMATION
////////////////////////////////////////////////////////////////////////////

//
// Constants for estimating lambda
//

// Start the estimator from this value.
const double LAMBDA_INITIAL_GUESS = 0.5;

// Try to get this much accuracy from Newton-Raphson.
const double LAMBDA_NR_EPSILON = 1.0e-5;

// Run Newton-Raphson for at most this many iters.
// (should be more than enough in practice)
const int LAMBDA_MAX_NR_ITERS = 20;

// Run bisection for this many iters (== # of bits accuracy in result).
const int LAMBDA_MAX_BS_ITERS = 17;


//
// Constants for estimating K
//

// Compute at most this many terms of the sumation for K the hard way.
const int K_MAX_ITERS = 100;

// Stop computing the hard way when the size of terms falls below threshold.
const double K_SUMMATION_EPSILON = 0.01;

////////////////////////////////////////////////////////////////////////////

//
// Compute the GCD of two integers by Euclid's algorithm.
//
inline int GCD( int a, int b )
{
  if (b < 0) b = -b;
  
  if (b > a) { int temp = a; a = b; b = temp; }
  
  while (b != 0) { int r = a % b; a = b; b = r; }
  
  return a;
}


//
// Constructor given only a single sequence.  Like BLAST, we assume
// that the other sequence has a uniform residue distribution.
// (Note: blastall, bl2seq, and megablast *always* make this assumption,
// even if explicitly given two sequences).
//
KarlinAltschulStats::KarlinAltschulStats(const SeqInfo &s1, 
					 const ScoreMatrix &M)
{
  unsigned int nRealResidues = s1.alphabet->nRealResidues();
  double *d2 = new double [nRealResidues + 1];
  
  double f = 1.0 / double(nRealResidues);
  for (Residue j = 1; j <= nRealResidues; j++)
    d2[j] = f;
  d2[Alphabet::RESIDUE_X] = 0.0;
    
  ScoreDistn sd(s1.freqs, d2, M);
  initParams(sd);
  
  delete [] d2;
}


//
// Constructor given a pair of sequences.  Use the observed residue
// distributions of *both* sequences (unlike BLAST).
//
KarlinAltschulStats::KarlinAltschulStats(const SeqInfo &s1, const SeqInfo &s2,
					 const ScoreMatrix &M)
{
  ScoreDistn sd(s1.freqs, s2.freqs, M);
  initParams(sd);
}


//
// Constructor given a pair of distributions and aggregate lengths.
//
KarlinAltschulStats::KarlinAltschulStats(const ScoreDistn &scoreProbs)
{
  initParams(scoreProbs);
}


//
// Constructor given explicit values of lambda and K.  If you need to
// compute the significance of gapped scores, you'll have to supply
// these parameters yourself.
//
KarlinAltschulStats::KarlinAltschulStats(double lambda, double K)
{
  _lambda = lambda;
  _K      = K;
  _logK = log(_K);
}


//
// KarlinAltschulStats::initParams()
//
// Initialize the parameters for Karlin-Altschul calculations between
// two sequences, given the sequences' residue distributions d1 and d2.
//
void KarlinAltschulStats::initParams(const ScoreDistn &scoreProbs)
{
  if (scoreProbs.low() >= 0 || scoreProbs.high() <= 0)
    {
      cerr << "ERROR: low score must be < 0; high score must be > 0\n";
      return;
    }
  
  // Compute the average score.
  double avgScore = 0.0;
  for (ScoreT m = scoreProbs.low(); m <= scoreProbs.high(); m++)
    avgScore += m * scoreProbs[m];
  
  if (avgScore >= 0.0)
    {
      cerr << "ERROR: average pairwise sim score must be negative!\n";
      return;
    }
  
  _lambda = computeLambda(scoreProbs);
  _K      = computeK(_lambda, avgScore, scoreProbs);
  _logK   = log(_K);
}


//////////////////////////////////////////////////////////////////////////
// E-VALUE COMPUTATIONS
//////////////////////////////////////////////////////////////////////////

//
// KarlinAltschulStats::StoE()
// 
// Given a score S and a search space size NM, compute
// the expected number of HSP's scoring >= S.  According
// to the Poisson model, the expectation is
//
//           E[# >= S] = KNM e^(-lambda S) 
//
double KarlinAltschulStats::StoE(double S, double NM) const
{
  return NM * exp(- _lambda * S + _logK);
}


//
// KarlinAltschulStats::EtoS()
//
// Given an expectation E and a search space size NM, compute
// S such that at most E HSP's with score >= S are expected
// by chance.
//
// This is just the inverse of the StoE() computation.
//
double KarlinAltschulStats::EtoS(double E, double NM) const
{
  return (_logK + log(NM/E)) / _lambda;
}


//////////////////////////////////////////////////////////////////////////
// PARAMETER COMPUTATIONS
//////////////////////////////////////////////////////////////////////////


//
// KarlinAltschulStats::computeLambda()
//
// Compute and return the parameter lambda.  We assume that
// computeScoreDistn() has already been called to initialize the score
// probabilities.
//
double KarlinAltschulStats::computeLambda(const ScoreDistn &scoreProbs) const
{
  double lguess = LAMBDA_INITIAL_GUESS;  // our current guess at lambda
  
  //
  // Lambda is the unique nonzero solution to the equation
  //
  //       Sum_{scores m} Pr[m] exp(lambda m) = 1
  //
  // Below, we estimate lambda by fast Newton-Raphson iteration.  
  // If NR converges to the zero solution or fails to converge,
  // stop and compute lambda the "hard way" (see below).
  //
  
  for (int j = 0; j < LAMBDA_MAX_NR_ITERS; j++) 
    {
      double x   =  -1.0;   // value of above sum - 1
      double dxdl =  0.0;   // 1st derivative of x w/r to lambda
      
      double expLambda  = exp(lguess);
      
      double expLambdaM = exp(lguess * (scoreProbs.low() - 1));
      if (expLambdaM == 0) break;                  // cannot compute x?
      for (ScoreT m = scoreProbs.low(); m <= scoreProbs.high(); m++)
	{
	  expLambdaM *= expLambda;
	  double v = scoreProbs[m] * expLambdaM;
	  
	  x    += v;
	  dxdl += v * m;
	}
      
      double delta = x / dxdl;                     // the NR correction
      lguess -= delta;
      
      if (fabs(delta/lguess) < LAMBDA_NR_EPSILON)     // convergence
	{
	  
	  if (lguess > LAMBDA_NR_EPSILON) // nonzero solution - yea!
	    return lguess;
	  else                            // zero solution - boo!
	    break;
	}
      else if (lguess < 0.01)             // looks to be heading toward 0
	break;
    }
  
  // If here, NR failed. Compute lambda the hard way.
  return computeLambdaSlow(scoreProbs);
}


//
// KarlinAltschulStats::computeLambdaSlow()
//
// Compute and return the parameter lambda by the (slow) bisection method.
// We use this procedure when spiffy fast Newton-Raphson iteration
// doesn't converge or finds the zero solution.
//
// Assumptions are the same as for computeLambda().
//
double 
KarlinAltschulStats::computeLambdaSlow(const ScoreDistn &scoreProbs) const
{
  // These will be our upper and lower bounds on lambda
  double lUpper = LAMBDA_INITIAL_GUESS;
  double lLower = 0;
    
  // We want to find lambda s.t. Sum_m Pr[m] exp(lambda m) = 1.
  // Increase our guess at lambda until the sum exceeds 1, then
  // use the resulting guesses to get better upper and lower
  // bounds.
  //
  for (;;) 
    {
      lUpper *= 2.0;
      
      double expLambda = exp(lUpper);
      double sum = 0;
      
      double expLambdaM = exp(lUpper * (scoreProbs.low() - 1));       
      if (expLambdaM > 0.0) 
	{
	  for (ScoreT m = scoreProbs.low(); m <= scoreProbs.high(); m++)
	    {
	      expLambdaM *= expLambda;
	      sum += scoreProbs[m] * expLambdaM;
	    }
	}
      else // expLambdaM underflowed -- do sum the hard way
	{
	  for (ScoreT m = scoreProbs.low(); m <= scoreProbs.high(); m++)
	    sum += scoreProbs[m] * exp(lUpper * m);
	}
      
      if (sum >= 1.0)
	break;
      
      lLower = lUpper;
    }
  
  
  // We've bracketed lambda between lLower and lUpper.  Now use
  // bisection to improve the bracketing.
  for (int j = 0; j < LAMBDA_MAX_BS_ITERS; j++) 
    {
      double lguess = 0.5 * (lLower + lUpper);
      
      double expLambda = exp(lguess);
      double sum = 0;
      
      double expLambdaM = exp(lguess * (scoreProbs.low() - 1));       
      if (expLambdaM > 0.0) 
	{
	  for (ScoreT m = scoreProbs.low(); m <= scoreProbs.high(); m++)
	    {
	      expLambdaM *= expLambda;
	      sum += scoreProbs[m] * expLambdaM;
	    }
	}
      else // expLambdaM underflowed -- do sum the hard way
	{
	  for (ScoreT m = scoreProbs.low(); m <= scoreProbs.high(); m++)
	    sum += scoreProbs[m] * exp(lguess * m);
	}
            
      if (sum > 1.0)
	lUpper = lguess;
      else
	lLower = lguess;
    }
  
  return 0.5 * (lLower + lUpper);
}


//
// KarlinAltschulStats::computeK()
//
// Compute and return the parameter K, using the formula for K given
// in the appendix of Karlin & Altschul's 1990 paper.
//
// Assumtions are the same as for computeLambda().
//
// RETURNS: K if successful, -1 if failed.
//
double 
KarlinAltschulStats::computeK(double lambda, double avgScore, 
			      const ScoreDistn &scoreProbs) const
{
  double innerSum = 1.0, prevInnerSum = 1.0;
  double expLambda = exp(lambda);
  double innerSumRatio = 1.0;
  double seriesSum = 0.0;
  double avg = 0.0;
  int j;
  
  //
  // Compute avg == E[m exp(lambda m)] over all score values m.
  //
  double expLambdaM = exp(lambda * (scoreProbs.low() - 1));
  for (ScoreT m = scoreProbs.low(); m <= scoreProbs.high(); m++)
    {
      expLambdaM *= expLambda;
      avg += scoreProbs[m] * m * expLambdaM;
    }

  //
  // Why should these estimates hold?  In any case, they're needed
  // to give the same values as Altschul's code.
  //
  if (scoreProbs.high() == 1)
    return avg * (1 - 1.0/expLambda);
  else if (scoreProbs.low() == -1)
    return avgScore * avgScore / avg * (1 - 1.0/expLambda);
  
  //
  // THEORY OF OPERATION
  //
  // Let S_j be the score sum of j independently-chosen random residue pairs.
  // We need estimate the sum of a geometric series whose jth term is
  //
  //       1/j ( E[ exp(lambda S_j); S_j < 0 ] +  Pr[S_j >= 0] )
  //
  // where "E[f(x); x < 0]" denotes the sum of those terms in the expectation
  // for which x < 0.  This is *not* the same as E[f(x) | x < 0] !!!
  //
  // To compute the jth term, we need to know Pr[S_j = s] for all possible 
  // sums s of j scores.  The value of s is bounded by the closed interval
  // [j * low .. j * high].
  //
  // We may compute Pr[S_j = s] recursively as follows.  For the base
  // case, Pr[S_0 = 0] = 1.  Inductively, we have
  //
  //   Pr[S_j = sigma] = Sum_(m=low .. high) Pr[S_(j-1) = sigma - m] * Pr[m]
  //
  // where Pr[m] is the probability of a residue pair with score m.  Note
  // that we must restrict the summation on the right to reference only
  // score values between (j-1) * low and (j-1) * high.  In other words,
  // we require that
  //
  //                 (j-1) * low <= sigma - m <= (j-1) * high 
  //
  // Equivalently, we can further restrict m so that
  //
  //           sigma - (j-1) * high <= m <= sigma - (j-1) * low
  //
  // Finally, we show how to do the computation for successive values of j
  // in-place. It is not obvious how to do this because we need the values
  // Pr[S_(j-1) = t] from the previous iteration to compute Pr[S_j = s].
  //
  // Let Q be a single, sufficiently long array.  In iteration j, define
  // &Pr[S_j = s] = (Q - j * low + s), where r = (high - low) is the range
  // of single-residue-pair scores.  Suppose further that we compute 
  // Pr[S_j = s] for s from j*high downto j*low.
  //
  // Consider the computation for Pr[S_j = sigma].  The result will 
  // overwrite the cell at
  //
  //     &Pr[S_j = sigma] 
  //    = Q - j * low + sigma
  //
  // But the highest-numbered cell possibly read by this computation is
  //
  //     &Pr[S_(j-1) = sigma - low] 
  //    = Q - (j-1) * low + sigma - low
  //    = Q - j * low + sigma
  //
  // Thus, it is always safe to store the result Pr[S_j = sigma] after
  // its computation is finished.
  //
  
  double *Q = new double [K_MAX_ITERS * (scoreProbs.high() - 
					 scoreProbs.low() + 1)];
  double *pPrev = Q;
  
  pPrev[0] = 1.0; // base case
  
  for (j = 1; j <= K_MAX_ITERS; j++)
    {
      double *pCurr = Q - j * scoreProbs.low();
      
      // Update the probabilities Pr[S_j = sigma] for every score sigma.
      //
      for (ScoreT sigma = j * scoreProbs.high(); 
	   sigma >= j * scoreProbs.low(); 
	   sigma--)
	{
	  ScoreT lowBound  = MAX(scoreProbs.low(),
				 sigma - (j - 1) * scoreProbs.high());
	  ScoreT highBound = MIN(scoreProbs.high(),
				 sigma - (j - 1) * scoreProbs.low());
	  
	  double p = 0.0;
	  for (ScoreT m = lowBound; m <= highBound; m++)
	    p += pPrev[sigma - m] * scoreProbs[m];
	  
	  pCurr[sigma] = p;
	}
      
      
      innerSum = 0.0;
      
      // Add the lower expectation...
      
      double expLambdaSj = exp(lambda * (j * scoreProbs.low() - 1));
      for (ScoreT sigma = j * scoreProbs.low(); sigma < 0; sigma++)
	{
	  expLambdaSj *= expLambda;
	  innerSum += pCurr[sigma] * expLambdaSj;
	}
      
      // ... and the upper probability.
      
      for (ScoreT sigma = 0; sigma <= j * scoreProbs.high(); sigma++)
	innerSum += pCurr[sigma];
      
      double term = innerSum / j;
      seriesSum += term;
      
      if (term < K_SUMMATION_EPSILON) // Is this term small enough to quit?
	{
	  innerSumRatio = innerSum / prevInnerSum;
	  break;
	}
      else
	{
	  prevInnerSum = innerSum;
	  pPrev = pCurr;
	}
    }
  
  delete [] Q;
  
  
  // If the terms in the series aren't decreasing fast enough,
  // something is wrong (and we'll spend forever in the next loop),
  // so just die.
  //
  if (innerSumRatio >= 1 - 0.001 * K_SUMMATION_EPSILON)
    {
      cerr << "ERROR: cannot accurately estimate K\n";
      return -1.0;
    }

  // Add a few more terms to the series sum to further increase accuracy.
  // Because the series decreases geometrically, we save the cost of further
  // exact term computations by using the observed ratio between previous 
  // terms to estimate the next few terms.
  //
  if (j < K_MAX_ITERS) j++;
  for (double term = innerSum / j; term > 0.01 * K_SUMMATION_EPSILON; j++)
    {
      innerSum *= innerSumRatio;
      
      term = innerSum / j;
      seriesSum += term;
    }
  
  
  //
  // We've done the hard part (the series sum).  Now finish off the
  // estimate of K.  We use the conservative K+, which requires
  // computing delta, the GCD of the score span.
  //
  // (What does delta mean, anyway? Must check DKK paper; meanwhile,
  // use the computation from Altschul's code).
  //
  
  int delta = -scoreProbs.low();
  for (int i = 1; delta > 1 && i <= scoreProbs.high() - scoreProbs.low(); i++)
    {
      if (scoreProbs[scoreProbs.low() + i] > 0.0)
	delta = GCD(delta, i);
    }
  
  return delta * exp(-2.0 * seriesSum) / (avg * (1.0 - exp(-delta * lambda)));
}
