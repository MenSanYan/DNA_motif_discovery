//
// SEQOPS.CC
// Miscellaneous operations on biosequences
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include "seqops.h"

struct Codon {
  char bases[3];
  char amino;
};

// the mapping from nucleotide triples to amino acids (for nuclear genome)
const struct Codon RawCodonMapping[] = {
  { { 'A', 'A', 'A' }, 'K' },
  { { 'A', 'A', 'C' }, 'N' },
  { { 'A', 'A', 'G' }, 'K' },
  { { 'A', 'A', 'T' }, 'N' },
  { { 'A', 'A', 'X' }, 'X' },
  { { 'A', 'C', 'A' }, 'T' },
  { { 'A', 'C', 'C' }, 'T' },
  { { 'A', 'C', 'G' }, 'T' },
  { { 'A', 'C', 'T' }, 'T' },
  { { 'A', 'C', 'X' }, 'X' },
  { { 'A', 'G', 'A' }, 'R' },
  { { 'A', 'G', 'C' }, 'S' },
  { { 'A', 'G', 'G' }, 'R' },
  { { 'A', 'G', 'T' }, 'S' },
  { { 'A', 'G', 'X' }, 'X' },
  { { 'A', 'T', 'A' }, 'I' },
  { { 'A', 'T', 'C' }, 'I' },
  { { 'A', 'T', 'G' }, 'M' },
  { { 'A', 'T', 'T' }, 'I' },
  { { 'A', 'T', 'X' }, 'X' },
  { { 'A', 'X', 'A' }, 'X' },
  { { 'A', 'X', 'C' }, 'X' },
  { { 'A', 'X', 'G' }, 'X' },
  { { 'A', 'X', 'T' }, 'X' },
  { { 'A', 'X', 'X' }, 'X' },
  { { 'C', 'A', 'A' }, 'Q' },
  { { 'C', 'A', 'C' }, 'H' },
  { { 'C', 'A', 'G' }, 'Q' },
  { { 'C', 'A', 'T' }, 'H' },
  { { 'C', 'A', 'X' }, 'X' },
  { { 'C', 'C', 'A' }, 'P' },
  { { 'C', 'C', 'C' }, 'P' },
  { { 'C', 'C', 'G' }, 'P' },
  { { 'C', 'C', 'T' }, 'P' },
  { { 'C', 'C', 'X' }, 'X' },
  { { 'C', 'G', 'A' }, 'R' },
  { { 'C', 'G', 'C' }, 'R' },
  { { 'C', 'G', 'G' }, 'R' },
  { { 'C', 'G', 'T' }, 'R' },
  { { 'C', 'G', 'X' }, 'X' },
  { { 'C', 'T', 'A' }, 'L' },
  { { 'C', 'T', 'C' }, 'L' },
  { { 'C', 'T', 'G' }, 'L' },
  { { 'C', 'T', 'T' }, 'L' },
  { { 'C', 'T', 'X' }, 'X' },
  { { 'C', 'X', 'A' }, 'X' },
  { { 'C', 'X', 'C' }, 'X' },
  { { 'C', 'X', 'G' }, 'X' },
  { { 'C', 'X', 'T' }, 'X' },
  { { 'C', 'X', 'X' }, 'X' },
  { { 'G', 'A', 'A' }, 'E' },
  { { 'G', 'A', 'C' }, 'D' },
  { { 'G', 'A', 'G' }, 'E' },
  { { 'G', 'A', 'T' }, 'D' },
  { { 'G', 'A', 'X' }, 'X' },
  { { 'G', 'C', 'A' }, 'A' },
  { { 'G', 'C', 'C' }, 'A' },
  { { 'G', 'C', 'G' }, 'A' },
  { { 'G', 'C', 'T' }, 'A' },
  { { 'G', 'C', 'X' }, 'X' },
  { { 'G', 'G', 'A' }, 'G' },
  { { 'G', 'G', 'C' }, 'G' },
  { { 'G', 'G', 'G' }, 'G' },
  { { 'G', 'G', 'T' }, 'G' },
  { { 'G', 'G', 'X' }, 'X' },
  { { 'G', 'T', 'A' }, 'V' },
  { { 'G', 'T', 'C' }, 'V' },
  { { 'G', 'T', 'G' }, 'V' },
  { { 'G', 'T', 'T' }, 'V' },
  { { 'G', 'T', 'X' }, 'X' },
  { { 'G', 'X', 'A' }, 'X' },
  { { 'G', 'X', 'C' }, 'X' },
  { { 'G', 'X', 'G' }, 'X' },
  { { 'G', 'X', 'T' }, 'X' },
  { { 'G', 'X', 'X' }, 'X' },
  { { 'T', 'A', 'A' }, 'X' },
  { { 'T', 'A', 'C' }, 'Y' },
  { { 'T', 'A', 'G' }, 'X' },
  { { 'T', 'A', 'T' }, 'Y' },
  { { 'T', 'A', 'X' }, 'X' },
  { { 'T', 'C', 'A' }, 'S' },
  { { 'T', 'C', 'C' }, 'S' },
  { { 'T', 'C', 'G' }, 'S' },
  { { 'T', 'C', 'T' }, 'S' },
  { { 'T', 'C', 'X' }, 'X' },
  { { 'T', 'G', 'A' }, 'X' },
  { { 'T', 'G', 'C' }, 'C' },
  { { 'T', 'G', 'G' }, 'W' },
  { { 'T', 'G', 'T' }, 'C' },
  { { 'T', 'G', 'X' }, 'X' },
  { { 'T', 'T', 'A' }, 'L' },
  { { 'T', 'T', 'C' }, 'F' },
  { { 'T', 'T', 'G' }, 'L' },
  { { 'T', 'T', 'T' }, 'F' },
  { { 'T', 'T', 'X' }, 'X' },
  { { 'T', 'X', 'A' }, 'X' },
  { { 'T', 'X', 'C' }, 'X' },
  { { 'T', 'X', 'G' }, 'X' },
  { { 'T', 'X', 'T' }, 'X' },
  { { 'T', 'X', 'X' }, 'X' },
  { { 'X', 'A', 'A' }, 'X' },
  { { 'X', 'A', 'C' }, 'X' },
  { { 'X', 'A', 'G' }, 'X' },
  { { 'X', 'A', 'T' }, 'X' },
  { { 'X', 'A', 'X' }, 'X' },
  { { 'X', 'C', 'A' }, 'X' },
  { { 'X', 'C', 'C' }, 'X' },
  { { 'X', 'C', 'G' }, 'X' },
  { { 'X', 'C', 'T' }, 'X' },
  { { 'X', 'C', 'X' }, 'X' },
  { { 'X', 'G', 'A' }, 'X' },
  { { 'X', 'G', 'C' }, 'X' },
  { { 'X', 'G', 'G' }, 'X' },
  { { 'X', 'G', 'T' }, 'X' },
  { { 'X', 'G', 'X' }, 'X' },
  { { 'X', 'T', 'A' }, 'X' },
  { { 'X', 'T', 'C' }, 'X' },
  { { 'X', 'T', 'G' }, 'X' },
  { { 'X', 'T', 'T' }, 'X' },
  { { 'X', 'T', 'X' }, 'X' },
  { { 'X', 'X', 'A' }, 'X' },
  { { 'X', 'X', 'C' }, 'X' },
  { { 'X', 'X', 'G' }, 'X' },
  { { 'X', 'X', 'T' }, 'X' },
  { { 'X', 'X', 'X' }, 'X' }
};

const unsigned int NCodons = sizeof(RawCodonMapping) / sizeof(Codon);

static Residue *codonMapping = NULL;
static Residue *residueMapping = NULL;


inline unsigned int hashDNA(Residue r1, Residue r2, Residue r3)
{
  return residueMapping[r1] + 8 * residueMapping[r2] + 64 * residueMapping[r3];
}


// initCodonMapping()
// Initialize the mapping from DNA codons to amino acids, using the
// residue numbering of the specified DNA and protein alphabets.
//
static void initCodonMapping(const Alphabet *dna, const Alphabet *protein)
{
  residueMapping = new Residue [dna->nResidues()];
  for (Residue j = 0; j < dna->nResidues(); j++)
    residueMapping[j] = Alphabet::RESIDUE_X;
  
  residueMapping[dna->fromChar('A')] = dna->fromChar('A');
  residueMapping[dna->fromChar('C')] = dna->fromChar('C');
  residueMapping[dna->fromChar('G')] = dna->fromChar('G');
  residueMapping[dna->fromChar('T')] = dna->fromChar('T');
  
  codonMapping = new Residue [512];
  
  for (unsigned int j = 0; j < NCodons; j++)
    {
      const char *bases = RawCodonMapping[j].bases;
      
      codonMapping[hashDNA(dna->fromChar(bases[0]),
			   dna->fromChar(bases[1]),
			   dna->fromChar(bases[2]))]
	= protein->fromChar(RawCodonMapping[j].amino);
    }
}


//
// computeComplement()
// Compute the complement of a DNA sequence.
//
SeqInfo computeComplement(const SeqInfo &s)
{
  const Alphabet *a  = s.alphabet;
  
  SeqInfo sC = s;
  
  sC.complement = !s.complement;
  sC.data = new Residue [s.length];
  
  for (SeqPosn p = 0; p < s.length; p++)
    sC.data[s.length - p - 1] = a->complement(s.data[p]);
  
  for (Residue r = 0; r < a->nResidues(); r++)
    sC.freqs[r] = s.freqs[a->complement(r)];
  
  return sC;
}


//
// computeTranslation()
// Compute the translation of a DNA sequence to protein in the
// specified frame (+/- 1,2, or 3).  Use the specified protein
// Alphabet structure.  stop codons are translated as X's.
//
// NOTE: we assume that the same DNA and protein Alphabets
// are used for all calls to this function.
//
SeqInfo computeTranslation(const SeqInfo &sInput, int frame,
			   const Alphabet *aProtein)
{
  unsigned int offset = (frame < 0 ? -frame : frame) - 1;
  const Alphabet *aDNA = sInput.alphabet;
  
  if (codonMapping == NULL)
    initCodonMapping(aDNA, aProtein);
  
  SeqInfo s;
  if (frame < 0)
    s = computeComplement(sInput);
  else
    s = sInput;
  
  
  SeqLength aaLength = (s.length - offset) / 3;
  
  SeqInfo sTr;
  sTr.seqNum = s.seqNum;
  sTr.length = aaLength;
  sTr.alphabet = aProtein;
  sTr.complement = false;
  
  sTr.data = new Residue [aaLength];
  sTr.title = s.title;
  
  sTr.unmaskedLength = 0;
  for (Residue r = 0; r < aProtein->nResidues(); r++)
    sTr.freqs[r] = 1.0 / aProtein->nRealResidues();
  
  for (SeqPosn j = 0; j < aaLength; j++)
    {
      SeqPosn dnaPosn = 3 * j + offset;
      
      Residue aa = codonMapping[hashDNA(s.data[dnaPosn],
					s.data[dnaPosn+1],
					s.data[dnaPosn+2])];
      
      
      sTr.data[j] = aa;
      if (aa != Alphabet::RESIDUE_X)
	{
	  sTr.unmaskedLength++;
	  sTr.freqs[aa]++;
	}
    }
  
  sTr.freqs[Alphabet::RESIDUE_X] = 0.0;
  
  for (Residue r = 1; r <= aProtein->nRealResidues(); r++)
    sTr.freqs[r] /= (sTr.unmaskedLength + 1.0);
  
  return sTr;
}


//
// computeAggregateDistn()
// Compute aggregate residue distributions and effective sequence lengths
// for the sequences in a pairwise alignment.
//
// SETS: all fields of aggDistn
//
void computeAggregateDistn(const SeqVector seqs, SeqNumber partition,
			   const Alphabet *a, SeqPairDistn &aggDistn)
{
  unsigned int nRealResidues = a->nRealResidues();
  unsigned int nResidues     = a->nResidues();
  
  aggDistn.nSeqs     = seqs.length();
  aggDistn.partition = partition;
  
  aggDistn.length1 = 0; aggDistn.length2 = 0;
  for (Residue r = 0; r < nResidues; r++)
    {
      aggDistn.freqs1[r] = 0.0;
      aggDistn.freqs2[r] = 0.0;
    }
  
  if (partition > 0)
    {
      // Compare one set of sequences to another, disjoint set
      
      for (unsigned int j = 0; j < partition; j++)
	{
	  SeqLength len = seqs[j].unmaskedLength;
	  
	  for (Residue r = 1; r <= nRealResidues; r++)
	    aggDistn.freqs1[r] += seqs[j].freqs[r] * len;
	  
	  aggDistn.length1 += len;
	}
      
      for (unsigned int j = partition; j < seqs.length(); j++)
	{
	  SeqLength len = seqs[j].unmaskedLength;
	  
	  for (Residue r = 1; r <= nRealResidues; r++)
	    aggDistn.freqs2[r] += seqs[j].freqs[r] * len;
	  
	  aggDistn.length2 += len;
	}
      
      for (Residue r = 1; r <= nRealResidues; r++)
	{
	  aggDistn.freqs1[r] /= aggDistn.length1;
	  aggDistn.freqs2[r] /= aggDistn.length2;
	}
    }
  else
    {
      // Compare a set of sequences to itself
      
      for (unsigned int j = 0; j < seqs.length(); j++)
	{
	  SeqLength len = seqs[j].unmaskedLength;
	  
	  for (Residue r = 1; r <= nRealResidues; r++)
	    aggDistn.freqs1[r] += seqs[j].freqs[r] * len;
	  
	  aggDistn.length1 += len;
	}
      
      aggDistn.length2 = aggDistn.length1;
      
      for (Residue r = 1; r <= nRealResidues; r++)
	{
	  aggDistn.freqs1[r] /= aggDistn.length1;
	  aggDistn.freqs2[r] = aggDistn.freqs1[r];
	}
    }
}
  
