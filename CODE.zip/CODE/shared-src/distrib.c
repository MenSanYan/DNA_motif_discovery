/*
 * DISTRIB.C
 *
 * Routines to compute the probability associated with various intervals
 * of common cumulative distribution functions.
 *
 * The cumulative probability (P*) routines are adapted from
 *
 * W. Press, B. Flannery, S. Teukolsky, and W. Vetterling.
 * _Numerical_Recipes_In_C_. Ss. 6.1 - 6.3. Cambridge Press,
 * 1988.
 *
 * while the density formulae may be found in any good text on
 * mathematical statistics.
 *
 * We use double precision everywhere because it is the fastest method
 * on most systems; however, the calculations are only good to single 
 * precision (on the order of 1e-7).
 *
 * NOTE FOR FUTURE: it would be nice to handle noncentral distributions
 * as well.
 */

#include <math.h>
#include <stdio.h>

#include "distrib.h"

/* control parameters shared by all the iterative routines */
#define MAXITERS 200
#define EPSILON 3.0e-7

/* local function prototypes */
static double gammaP(double, double);
static double gammaP_s(double, double);
static double gammaQ(double, double);
static double gammaQ_f(double, double);
static double betaI(double, double, double);
static double betaI_f(double, double, double);

/************************************************************************
 * Distributions calculated from incomplete gamma functions
 ************************************************************************/

/*
 * Pnorm()
 * Return the probability associated with the interval [-Inf, x]
 * of the standard normal distribution n(0,1).  This function
 * is adapted from the erf() calculation in the reference.
 */
double Pnorm(double x)
{
  double nval = 0.5 * gammaP(0.5, 0.5 * x * x);
  
  /* nval is the probability associated with the interval [0, fabs(x)].
   * We use the symmetry of the normal about 0 to give the real value */
  if (x < 0.0)
    return (0.5 - nval);
  else
    return (0.5 + nval);
}


/*
 * Dnorm()
 * Return the density at x of the standard normal distribution n(0,1)
 */
double Dnorm(double x)
{
#define INV_SQRT_TWOPI 0.39894228040143
  
  return INV_SQRT_TWOPI * exp(-0.5 * x * x);
}


/*
 * Pchisq()
 * Return the probability associated with the interval [0, x] of a
 * chi square distribution with df degrees of freedom.
 */
double Pchisq(double x, int df)
{
  if (df < 1 || x < 0.0)
    {
      fprintf(stderr, "ERROR (Pchisq): invalid arguments (%g, %d)\n",
	      x, df);
      return 0.0;
    }
  
  return 1.0 - gammaQ(df * 0.5, x * 0.5);
}


/*
 * Dchisq()
 * Return the density at x of a chi square distribution with df degrees
 * of freedom.
 */
double Dchisq(double x, int df)
{
#define LN_2 0.69314718055995
  
  double df2;
  
  if (df < 1 || x < 0.0)
    {
      fprintf(stderr, "ERROR (Dchisq): invalid arguments (%g, %d)\n",
	      x, df);
      return 0.0;
    }
  
  df2 = 0.5 * df;
  return pow(x, df2 - 1) * exp(-0.5 * x - log_gamma(df2) - df2 * LN_2);
}


/*
 * Ppoisson()
 * Return the probability associated with the interval [0, k] of
 * a Poisson distribution with given mean.
 */
double Ppoisson(int k, double mean)
{
  if (k < 0 || mean < 0.0)
    {
      fprintf(stderr, "ERROR (Ppoisson): invalid arguments (%d, %g)\n",
	      k, mean);
      return 0.0;
    }
  
  return gammaQ(k + 1, mean);
}


/*
 * Dpoisson()
 * Return the density at k of a Poission distirbution with given mean.
 */
double Dpoisson(int k, double mean)
{
  if (k < 0 || mean < 0.0)
    {
      fprintf(stderr, "ERROR (Ppoisson): invalid arguments (%d, %g)\n",
	      k, mean);
      return 0.0;
    }
  
  return pow(mean, k) * exp(-mean - log_gamma(k + 1));
}


/************************************************************************
 * Distributions calculated from incomplete beta functions
 ************************************************************************/

/*
 * Pstudent()
 * Return the probability associated with the interval [-Inf, x] of
 * the Student's t distribution with df degrees of freedom.
 */
double Pstudent(double x, int df)
{
  double ddf = df;
  double svar;
  
  if (df < 1)
    {
      fprintf(stderr, "ERROR (Pstudent): invalid arguments (%g, %d)\n",
	      x, df);
      return 0.0;
    }
  
  svar = 0.5 * betaI(ddf * 0.5, 0.5, ddf / (ddf + x * x));
  
  if (x > 0.0)
    return (1.0 - svar);
  else
    return svar;
}


/*
 * Dstudent()
 * Return the density at x of the Student's t distribution with df degrees
 * of freedom.
 */
double Dstudent(double x, int df)
{
  double log_choose, v;
  
  if (df < 1)
    {
      fprintf(stderr, "ERROR (Pstudent): invalid arguments (%g, %d)\n",
	      x, df);
      return 0.0;
    }
  
  log_choose = 
    log_gamma(0.5 * (df + 1)) - log_gamma(0.5 * df) - log_gamma(0.5);
  
  v = pow(1 + x * x / (double) df, 0.5 * (df + 1));
  
  return exp(log_choose) / ( sqrt(df) * v );
}


/*
 * PF()
 * Return the probability associated with the interval [0..x] of
 * the F distribution with df1 and df2 degrees of freedom.
 */
double PF(double x, int df1, int df2)
{
  double ddf1 = df1, ddf2 = df2;
  
  if (df1 < 1 || df2 < 1)
    {
      fprintf(stderr, "ERROR (PF): invalid arguments (%g, %d, %d)\n",
	      x, df1, df2);
      return 0.0;
    }
  
   return betaI(ddf1 * 0.5, ddf2 * 0.5, x * ddf1 / (x * ddf1 + ddf2));
}


/*
 * DF()
 * Return the density at x of the F distribution with df1 and df2
 * degrees of freedom.
 */
double DF(double x, int df1, int df2) 
{
  double dfratio, dfsum, log_choose;
  
  if (df1 < 1 || df2 < 1)
    {
      fprintf(stderr, "ERROR (PF): invalid arguments (%g, %d, %d)\n", 
	      x, df1, df2);
      return 0.0;
    }
  
  dfratio = (double) df1/ (double) df2;
  dfsum   = df1 + df2;
  
  log_choose = 
    log_gamma(0.5 * dfsum) - log_gamma(0.5 * df1) - log_gamma(0.5 * df2);
  
  return 
    exp(log_choose) * pow(dfratio, 0.5 * df1) * 
    pow(x, 0.5 * df1 - 1) * pow(1 + x * dfratio, -0.5 * dfsum);
}


/*
 * Pbinom()
 * Return the probability associated with the interval [0, k] of
 * the binomial distribution B(N, p).
 */
double Pbinom(int k, int N, double p)
{
  if (k < 0 || k > N || p < 0.0 || p > 1.0)
    {
      fprintf(stderr, "ERROR (Pbinom): invalid arguments (%d, %d, %g)\n", 
	      k, N, p);
      return 0.0;
    }
  else if (k == N)                /* a == 0 freaks out betaI */
    return 1.0;
  else if (k < N && p == 1.0)     /* not strictly needed, but nice */
    return 0.0;
  
  return betaI(N - k, k + 1, 1.0 - p);
}


/*
 * Dbinom()
 * Return the density at k of the binomial distribution B(N, p).
 */
double Dbinom(int k, int N, double p)
{
  double log_choose;
  
  if (k < 0 || k > N || p < 0.0 || p > 1.0)
    {
      fprintf(stderr, "ERROR (Pbinom): invalid arguments (%d, %d, %g)\n",
	      k, N, p);
      return 0.0;
    }
  
  /* log of (N choose k) */
  log_choose = log_gamma(N + 1) - log_gamma(k + 1) - log_gamma(N - k + 1);
  
  return exp(log_choose) * pow(p, k) * pow(1 - p, N - k);
}

/************************************************************************/

/*
 * log_gamma()
 * Calculate the approximate log of the gamma function for any a > 0.
 * WARNING: Values returned for a <= 1 are less accurate, except for
 * a = 0.5, which is kept as a common special case.
 */
double log_gamma(double a)
{
#define LOG_SQRT_PI 0.57236494292470
  double x, tmp, ser;
  int j;
  
  const double coeffs[6] = {
    76.18009173,  -86.50532033,   24.01409822,
    -1.231739516, 0.120858003e-2, -0.536382e-5
  };
  
  if (a == 0.5) /* optimize most common case */
    return LOG_SQRT_PI;
  
  x = a - 1.0;
  tmp = x + 5.5;
  tmp -= (x + 0.5) * log(tmp);
  ser = 1.0;
  
  for (j = 0; j < 6; j++)
    {
      x += 1.0;
      ser += coeffs[j] / x;
    }
  
  return -tmp + log(2.50662827465 * ser);
}


/*** NOTHING BELOW HERE IS EXPORTED ***/


/************************************************************************
 * INCOMPLETE GAMMA FUNCTIONS P(a,x) [standard] and Q(a,x) [specific to
 * reference above].  Both functions are calculated by iterative
 * methods.
 ************************************************************************/

/*
 * gammaP()
 *
 * Compute the incomplete gamma function P(a,x) =
 * 1/gamma(a) * Int(0..x) [exp(-t) * t^(a-1)] dt
 */
static double gammaP(double a, double x)
{
  if (x < 0.0 || a <= 0.0)
    {
      fprintf(stderr, "ERROR (gammaP): invalid arguments (%g, %g)\n",
	      a, x);
      return 0.0;
    }
  else if (x == 0) /* the iterative routines don't like 0 */
    return 0.0;
  
  if (x < (a + 1.0)) 
    /* use series representation */
    return gammaP_s(a, x);
  else
    /* use continued fraction representation, and complement */
    return (1.0 - gammaQ_f(a, x));
}

/*
 * gammaQ()
 *
 * Compute the incomplete gamma function Q(a,x) =
 * 1/gamma(a) * Int(x..Inf) [exp(-t) * t^(a-1)] dt
 */
static double gammaQ(double a, double x)
{
  if (x < 0.0 || a <= 0.0)
    {
      fprintf(stderr, "ERROR (gammaQ): invalid arguments (%g, %g)\n",
	      a, x);
      return 0.0;
    }
  else if (x == 0) /* the iterative routines don't like 0 */
    return 1.0;
  
  if (x < (a + 1.0)) 
    /* use series representation */
    return (1.0 - gammaP_s(a, x));
  else
    /* use continued fraction representation, and complement */
    return gammaQ_f(a, x);
}


/*
 * gammaP_s()
 * Compute P(a,x) using its series representation
 */
static double gammaP_s(double a, double x)
{
  double sum, ap, delta;
  int j;
    
  if (x <= 0.0)
    {
      fprintf(stderr, "ERROR (gammaP_s): x less than or equal to 0.0\n");
      return 0.0;
    }
  
  /* iteratively calculate P(a,x) */
  ap = a;
  delta = sum = 1.0 / a;
  
  for (j = 0; j < MAXITERS; j++)
    {
      ap += 1.0;
      delta *= x / ap;
      sum += delta;
      
      if (fabs(delta) < EPSILON * fabs(sum))
	return (sum * exp(-x + a * log(x) - log_gamma(a)));
    }
  
  /* if here, we failed to converge within MAXITERS iterations */
  fprintf(stderr, "ERROR (gammaP_s): failed to converge in %d iterations\n",
	  MAXITERS);
  return 0.0;
}


/*
 * gammaQ_f()
 * Compute Q(a,x) using its continued fraction representation
 */
static double gammaQ_f(double a, double x)
{
  double a0 = 1.0, b0 = 0.0;
  double a1 = x,   b1 = 1.0;
  double prev_g = 0.0, fac = 1.0;
  double curr_g = 0.0;
  int j;
    
  if (x <= 0.0)
    {
      fprintf(stderr, "ERROR (gammaQ_f): x less than or equal to 0.0\n");
      return 0.0;
    }
  
  for (j = 1; j <= MAXITERS; j++)
    {
      double an  = j;
      double ana = an - a;
      double anf = an * fac;
      
      a0 = (a1 + a0 * ana) * fac;
      b0 = (b1 + b0 * ana) * fac;
      
      a1 = a0 * x + a1 * anf;
      b1 = b0 * x + b1 * anf;
      
      if (a1 != 0.0)
	{
	  fac = 1.0 / a1;
	  curr_g = b1 * fac;
	  
	  if (fabs((curr_g - prev_g) / curr_g) < EPSILON)
	    return curr_g * exp(-x + a * log(x) - log_gamma(a));
	}
      
      prev_g = curr_g;
    }
  
  /* if here, we failed to converge within MAXITERS iterations */
  fprintf(stderr, "ERROR (gammaQ_f): failed to converge in %d iterations\n",
	  MAXITERS);
  return 0.0;
}


/************************************************************************
 * INCOMPLETE BETA FUNCTIONS I(a,b,x)
 * These functions are used to calculate distributions such as
 * the binomial, t, and F.
 ************************************************************************/

/*
 * betaI()
 * Calculate the incomplete beta function I_x(a, b).  For values other
 * than 0 and 1, this routine calculates using a continued fraction
 * approximation.
 */
static double betaI(double a, double b, double x)
{
  if (x <= 0.0)
    {
      if (x != 0.0)
	fprintf(stderr, "ERROR (betaI): x < 0\n");
      
      return 0.0;
    }
  else if (x >= 1.0)
    {
      if (x != 1.0)
	fprintf(stderr, "ERROR (betaI): x > 1\n");
      
      return 1.0;
    }
  else
    {
      /* bt is the quantity in front of the continued fraction */
      double bt = exp(log_gamma(a + b) - log_gamma(a) - log_gamma(b) +
		      a * log(x) + b * log(1.0 - x));
      
      /* use symmetry to keep continued fraction in the 
       * high-accuracy regime */
      if (x < (a + 1.0) / (a + b + 2.0))
	return bt * betaI_f(a, b, x) / a;
      else
	return 1.0 - bt * betaI_f(b, a, 1.0 - x) / b;
    }
}


/*
 * betaI_f()
 * Calculate the incomplete beta function I_x(a, b) by the
 * method of continued fractions.
 */
static double betaI_f(double a, double b, double x)
{
  double qap, qam, qab;
  double az, bz, az_prev;
  double am = 1.0, bm = 1.0;
  int j;
  
  /* constant expressions used in the computation loop */
  qab = a + b;
  qap = a + 1.0;
  qam = a - 1.0;
  
  az = 1.0;
  bz = 1.0 - qab * x / qap;
  
  /* evaluate the continued fraction until convergence */
  for (j = 1; j <= MAXITERS; j++)
    {
      double em =  j;
      double tem = j * 2;
      double ap, app, bp, bpp, d;
      
      /* even step of the recurrence */
      d = em * (b - em) * x / ((qam + tem) * (a + tem));
      ap = az + d * am;
      bp = bz + d * bm;
      
      /* odd step of the recurrence */
      d = -(a + em) * (qab + em) * x / ((qap + tem) * (a + tem));
      app = ap + d * az;
      bpp = bp + d * bz;
      
      /* renormalize to prevent overflow */
      am = ap / bpp;
      bm = bp / bpp;
      
      az_prev = az;
      az = app/bpp;
      bz = 1.0;
      
      if (fabs((az - az_prev) < (EPSILON * fabs(az))))
	return az;
    }
  
  
  /* if here, we failed to converge within MAXITERS iterations */
  fprintf(stderr, "ERROR (betaI_f): failed to converge in %d iterations\n",
	  MAXITERS);
  return 0.0;
}
