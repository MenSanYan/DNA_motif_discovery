//
// ALIGNMENT.CC
// Implementation for Alignment type
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include "alignment.h"
#include "interval.h"

//
// ASSUME: the [start, end] indices are for the forward orientation;
// otherwise, we'd have to know the lengths of the two sequences
// in the alignment to do the conversion.
//
Interval Alignment::toInterval(int j) const
{
  return Interval(start(j), end(j), dir(j));
}


//
// transformTo()
// Transform an interval expressed relative to one sequence of an alignment
// into the same interval expressed relative to the other sequence.
// The dstSeq argument is 0 or 1 depending on whether we should target
// the first or second sequence of the alignment.
//
// NOTE: if interval endpoints are unsigned, this method
// is safe iff start(srcSeq) <= iSrc.low().  If you will be
// transforming this interval back and forth between regions, it
// must be inside the interval
//
//          [start(srcSeq) .. end(srcSeq)]
//
Interval Alignment::transformTo(const Interval &iSrc, int dstSeq) const
{
  int srcSeq = 1 - dstSeq;
  Direction dstDir;
  SeqPosn dstLow;
  
  if (dir(srcSeq) == dir(dstSeq))
    {
      dstDir = iSrc.dir();
      dstLow = iSrc.low() - start(srcSeq) + start(dstSeq);
    }
  else
    {
      dstDir = opposite(iSrc.dir());
      dstLow = end(dstSeq) - (iSrc.high() - start(srcSeq));
    }
  
  return Interval(dstLow, dstLow + iSrc.length() - 1, dstDir);
}
