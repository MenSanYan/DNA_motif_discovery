//
// PRINTALIGNMENT.CC
// Routines for printing BLAST-style sequence alignments
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <iomanip>

#include "printalignment.h"
#include "minmax.h"

using namespace std;

//
// local prototypes
//

static void printUngappedSummary(const Residue *, const Residue *,
				 SeqLength, ostream &, unsigned int);

static void printUngappedAlignmentLine(const Residue *, const Residue *,
				       SeqPosn, SeqPosn,
				       SeqPosn, SeqPosn,
				       const Alphabet *,
				       unsigned int, 
				       ostream &, unsigned int);

static void printGappedSummary(const Residue *, const Residue *,
			       const Alignment &, ostream &, unsigned int);

static void computePathLengths(const Alignment::Path,
			       unsigned int, unsigned int,
			       SeqLength *, SeqLength *);

static void printGappedAlignmentLine(const Residue *, const Residue *,
				     const Alignment::Path,
				     SeqPosn, SeqPosn,
				     SeqPosn, SeqPosn,
				     unsigned int, 
				     const Alphabet *,
				     unsigned int,
				     ostream &, unsigned int);



inline void printIndent(ostream &os, unsigned int indent)
{
  for (unsigned int j = 0; j < indent; j++)
    os << ' ';
}


//////////////////////////////////////////////////////////////////////////

//
// printUngappedAlignment()
// Print an ungapped alignment, showing the positions of all matches
// along with a summary of the match content.
//
// INPUTS:
//  * information about two sequences being aligned
//  * starting position of the alignment in each sequence
//  * length of the alignment path
//  * output stream to write on
//  * length of line for printing multiline alignments
//  * number of spaces to indent each line of printout
//
void printUngappedAlignment(const SeqInfo &seq1Info, const SeqInfo &seq2Info,
			    const Alignment &a, ostream &os,
			    unsigned int lineLength,
			    unsigned int indent)
{
  const Residue *seq1 = seq1Info.data, *seq2 = seq2Info.data;
  SeqPosn start1 = a.start(0), start2 = a.start(1);
  unsigned int pathLength = a.length();
  
  printUngappedSummary(seq1 + start1, seq2 + start2, pathLength,
		       os, indent);
  
  printIndent(os, indent);
  
  if (seq1Info.isDNA())
    {
      os << "Strands shown = "
	 << (seq1Info.complement ? '-' : '+')
	 << '/'
	 << (seq2Info.complement ? '-' : '+')
	 << '\n';
    }
  
  unsigned int pathStart = 0;
  while (pathStart < pathLength)
    {
      unsigned int currLineLength = MIN(lineLength, pathLength - pathStart);
      
      SeqPosn currStart1, currStart2, currEnd1, currEnd2;
      
      if (seq1Info.complement)
	{
	  currStart1 = seq1Info.length - start1 - 1;
	  currEnd1   = currStart1 - currLineLength + 1;
	}
      else
	{
	  currStart1 = start1;
	  currEnd1   = currStart1 + currLineLength - 1;
	}
      
      if (seq2Info.complement)
	{
	  currStart2 = seq2Info.length - start2 - 1;
	  currEnd2   = currStart2 - currLineLength + 1;
	}
      else
	{
	  currStart2 = start2;
	  currEnd2   = currStart2 + currLineLength - 1;
	}
      
      os << '\n';
      
      printUngappedAlignmentLine(seq1 + start1, seq2 + start2,
				 currStart1, currEnd1, 
				 currStart2, currEnd2,
				 seq1Info.alphabet, currLineLength,
				 os, indent);
      
      pathStart += currLineLength;
      start1    += currLineLength;
      start2    += currLineLength;
    }
}


//
// printUngappedSummary()
// Summarize the statistics of an ungapped alignment
//
// INPUTS:
//  * two sequences being aligned, starting at the first character of
//    each involved in the alignment
//  * length of the ungapped alignment
//  * output stream on which to print the summary
//  * amount by which to indent each line
//  
static void printUngappedSummary(const Residue *seq1, const Residue *seq2,
				 SeqLength pathLength, 
				 ostream &os, unsigned int indent)
{
  SeqLength nMatches = 0;
  
  for (SeqPosn j = 0; j < pathLength; j++)
    {
      if (Alphabet::isMatch(seq1[j], seq2[j]))
	nMatches++;
    }
  
  printIndent(os, indent);
  
  os << "Identities = " << nMatches << '/' << pathLength
     << " (" << int(double(nMatches)/double(pathLength) * 100.0 + 0.5)
     << "%)\n";
}



//
// printUngappedAlignmentLine()
// Print a single line of the alignment in three lines of text, like
// BLAST does.  The first and third lines show the progress through
// the first and second sequences. The second line shows a '|' for each 
// match and a ':' for each transition mutation in the alignment.  The 
// ends of the first and third lines indicate what range of characters in 
// each sequence was covered by this portion of the alignment. 
//
// INPUTS:
//  * two sequences being aligned, positioned at the start of the portions
//    used in this line
//  * the start and end indices to be printed at the ends of the lines
//    (may be relative to either strand -- computed separately)
//  * alphabet of the input sequences
//  * number of steps in the path printed in this line
//  * output stream on which line is written
//  * amount by which to indent each line of text.
//
static void printUngappedAlignmentLine(const Residue *seq1, 
				       const Residue *seq2,
				       SeqPosn start1, SeqPosn end1,
				       SeqPosn start2, SeqPosn end2,
				       const Alphabet *alphabet,
				       unsigned int lineLength, 
				       ostream &os,
				       unsigned int indent)
{
#if __GNUC__ >= 3
  // the fully standard-compliant way declare format flags
  ios_base::fmtflags oldflags;
#else
  // This definition should be safe for both g++ 2.x and DEC C++.
  unsigned long oldflags;
#endif
  
  //
  // top line: the first sequence
  //
  
  printIndent(os, indent);
  
  oldflags = os.setf(ios::right);
  os << setw(8) << start1 + 1 << ' ';
  os.flags(oldflags);
  
  alphabet->printSeq(seq1, lineLength, os);
  
  oldflags = os.setf(ios::right);
  os << ' ' << setw(8) << end1 + 1 << '\n';
  os.flags(oldflags);
  
  
  //
  // middle line: indicate matches with '|', transitions with a ':'
  //
  
  printIndent(os, indent);
  os << "         ";
  
  for (unsigned int step = 0; step < lineLength; step++)
    {
      if (Alphabet::isMatch(seq1[step], seq2[step]))
	os << '|';
      else if (alphabet->isDNA() &&
	       alphabet->isTransition(seq1[step], seq2[step]))
	os << ':';
      else
	os << ' ';
    }
  os << '\n';
  
  
  //
  // bottom line: second sequence
  //
  
  printIndent(os, indent);
  
  oldflags = os.setf(ios::right);
  os << setw(8) << start2 + 1 << ' ';
  os.flags(oldflags);
  
  alphabet->printSeq(seq2, lineLength, os);
  
  oldflags = os.setf(ios::right);
  os << ' ' << setw(8) << end2 + 1 << '\n';
  os.flags(oldflags);
}


//////////////////////////////////////////////////////////////////////////


//
// printGappedAlignment()
// Print a gapped alignment, showing the positions of all matches and
// gaps along with a summary of the match and gap content.
//
// INPUTS:
//  * information about two sequences being aligned
//  * Alignment object describing the alignment path
//  * output stream to write on
//  * length of line for printing multiline alignments
//  * number of spaces to indent each line of printout
//
void printGappedAlignment(const SeqInfo &seq1Info, const SeqInfo &seq2Info,
			  const Alignment &a, ostream &os,
			  unsigned int lineLength,
			  unsigned int indent)
{
  const Residue *seq1 = seq1Info.data, *seq2 = seq2Info.data;
  SeqPosn start1 = a.start(0), start2 = a.start(1);
  const Alignment::Path path = a.path();
  
  printGappedSummary(seq1 + start1, seq2 + start2, a, os, indent);
  
  printIndent(os, indent);
  
  if (seq1Info.isDNA())
    {
      os << "Strands shown = "
	 << (seq1Info.complement ? '-' : '+')
	 << '/'
	 << (seq2Info.complement ? '-' : '+')
	 << '\n';
    }
  
  unsigned int pathStart = 0;
  while (pathStart < path.length())
    {
      unsigned int currLineLength =
	MIN(lineLength, path.length() - pathStart);
      SeqLength currSeqLength1, currSeqLength2;
      
      computePathLengths(path, pathStart, currLineLength, 
			 &currSeqLength1, &currSeqLength2);
      
      SeqPosn currStart1, currStart2, currEnd1, currEnd2;
      
      if (seq1Info.complement)
	{
	  currStart1 = seq1Info.length - start1 - 1;
	  currEnd1   = currStart1 - currSeqLength1 + 1;
	}
      else
	{
	  currStart1 = start1;
	  currEnd1   = currStart1 + currSeqLength1 - 1;
	}
      
      if (seq2Info.complement)
	{
	  currStart2 = seq2Info.length - start2 - 1;
	  currEnd2   = currStart2 - currSeqLength2 + 1;
	}
      else
	{
	  currStart2 = start2;
	  currEnd2   = currStart2 + currSeqLength2 - 1;
	}
      
      os << '\n';
      
      printGappedAlignmentLine(seq1 + start1, seq2 + start2, path,
			       currStart1, currEnd1, 
			       currStart2, currEnd2,
			       pathStart, seq1Info.alphabet,
			       currLineLength, os, indent);
      
      pathStart += currLineLength;
      start1    += currSeqLength1;
      start2    += currSeqLength2;
    }
}


//
// printGappedSummary()
// Summarize the statistics of a gapped alignment.
//
// INPUTS:
//  * two sequences being aligned, starting at the first character of
//    each involved in the alignment
//  * Alignment object describing the alignment
//  * output stream on which to print the summary
//  * amount by which to indent each line
//
static void printGappedSummary(const Residue *seq1, const Residue *seq2,
			       const Alignment &a,
			       ostream &os,
			       unsigned int indent)
{
  const Alignment::Path path = a.path();
  unsigned int nMatches = 0, nGaps = 0;
  SeqPosn seqIdx1 = 0, seqIdx2 = 0;
  
  for (unsigned int step = 0; step < path.length(); step++)
    {
      switch (path[step])
	{
	case Alignment::MATCH:
	  if (Alphabet::isMatch(seq1[seqIdx1], seq2[seqIdx2]))
	    nMatches++;
	  seqIdx1++;
	  seqIdx2++;
	  break;
	  
	case Alignment::GAP1:
	  nGaps++;
	  seqIdx2++;
	  break;
	  
	case Alignment::GAP2:
	  nGaps++;
	  seqIdx1++;
	  break;
	}
      
    }
  
  printIndent(os, indent);
  
  os << "Alignment Score = " << a.score();
  if (a.eValue() >= 0)
    os << " (E = " << setprecision(3) << a.eValue() << ')'; 
  os << '\n';
  
  printIndent(os, indent);
  
  os << "Identities = " << nMatches << '/' << path.length()
     << " (" << int(double(nMatches)/double(path.length()) * 100.0 + 0.5)
     << "%), ";
  os << "Gaps = " << nGaps << '/' << path.length()
     << " (" << int(double(nGaps)/double(path.length()) * 100.0 + 0.5)
     << "%)\n";
}



//
// computeSeqLengths()
// Compute the lengths of the two sequences traversed by the
// steps in the interval [pathStart, pathStart + lineLength - 1]
// of a gapped alignment.  Return the lengths in the input variables
// *seqLength1 and *seqlength2.
//
static void computePathLengths(const Alignment::Path path,
			       unsigned int pathStart, 
			       unsigned int lineLength,
			       SeqLength *seqLength1, 
			       SeqLength *seqLength2)
{
  *seqLength1 = 0; *seqLength2 = 0;
  
  for (unsigned int step = 0; step < lineLength; step++)
    {
      switch (path[pathStart + step])
	{
	case Alignment::MATCH:
	  (*seqLength1)++; (*seqLength2)++;
	  break;
	  
	case Alignment::GAP1:
	  (*seqLength2)++;
	  break;
	  
	case Alignment::GAP2:
	  (*seqLength1)++;
	  break;
  	}
    }
}


//
// printGappedAlignmentLine()
// Print a single line of the alignment in three lines of text, like
// BLAST does.  The first and third lines show the progress through
// the first and second sequences (with gap chars where appropriate).
// The second line shows a '|' for each match and a ':' for each
// transition mutation in the alignment.  The ends of the first and
// third lines indicate what range of characters in each sequence was 
// covered by this portion of the alignment. 
//
// INPUTS:
//  * two sequences being aligned, positioned at the start of the portions
//    used in this line
//  * the start and end indices to be printed at the ends of the lines
//    (may be relative to either strand -- computed separately)
//  * position in the alignment path at which this line starts
//  * alphabet of the input sequences
//  * number of steps in the path printed in this line
//  * output stream on which line is written
//  * amount by which to indent each line of text.
//
static void printGappedAlignmentLine(const Residue *seq1, const Residue *seq2,
				     const Alignment::Path path,
				     SeqPosn start1, SeqPosn end1,
				     SeqPosn start2, SeqPosn end2,
				     unsigned int pathStart,
				     const Alphabet *alphabet,
				     unsigned int lineLength, 
				     ostream &os,
				     unsigned int indent)
{
  SeqPosn idx1, idx2;
  
#if __GNUC__ >= 3
  // the fully standard-compliant way to declare format flags
  ios_base::fmtflags oldflags;
#else
  // This definition should be safe for both g++ 2.x and DEC C++.
  unsigned long oldflags;
#endif
  
  //
  // top line: the first sequence
  //
  
  printIndent(os, indent);
  
  oldflags = os.setf(ios::right);
  os << setw(8) << start1 + 1 << ' ';
  os.flags(oldflags);
  
  idx1 = 0;
  for (unsigned int step = 0; step < lineLength; step++)
    {
      if (path[pathStart + step] == Alignment::GAP1)
	os << "-";
      else
	os << alphabet->toChar(seq1[idx1++]);
    }
  
  oldflags = os.setf(ios::right);
  os << ' ' << setw(8) << end1 + 1 << '\n';
  os.flags(oldflags);
  
  
  //
  // middle line: indicate matches with '|', transitions with a ':'
  //
  
  printIndent(os, indent);
  os << "         ";
  
  idx1 = 0; idx2 = 0;
  for (unsigned int step = 0; step < lineLength; step++)
    {
      switch (path[pathStart + step])
	{
	case Alignment::MATCH:
	  if (Alphabet::isMatch(seq1[idx1], seq2[idx2]))
	    os << '|';
	  else if (alphabet->isDNA() && 
		   alphabet->isTransition(seq1[idx1], seq2[idx2]))
	    os << ':';
	  else
	    os << ' ';
	  
	  idx1++; idx2++;
	  break;
	  
	case Alignment::GAP1:
	  os << ' ';
	  idx2++;
	  break;
	  
	case Alignment::GAP2:
	  os << ' ';
	  idx1++;
	  break;
	}
    }
  os << '\n';
  
  
  //
  // bottom line: second sequence
  //
  
  printIndent(os, indent);
  
  oldflags = os.setf(ios::right);
  os << setw(8) << start2 + 1 << ' ';
  os.flags(oldflags);
  
  idx2 = 0;
  for (unsigned int step = 0; step < lineLength; step++)
    {
      if (path[pathStart + step] == Alignment::GAP2)
	os << "-";
      else
	os << alphabet->toChar(seq2[idx2++]);
    }
  
  oldflags = os.setf(ios::right);
  os << ' ' << setw(8) << end2 + 1 << '\n';
  os.flags(oldflags);
}
