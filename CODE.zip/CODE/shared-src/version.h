//
// VERSION.H
// Version information for the toolkit
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2002 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __VERSION_H
#define __VERSION_H

#define VERSION "0.42"
#define COPYRIGHT_DATES "2000-2004"

void printVersion(void);

#endif
