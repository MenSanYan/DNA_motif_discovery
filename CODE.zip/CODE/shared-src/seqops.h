//
// SEQOPS.H
// Miscellaneous operations on biosequences
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __SEQOPS_H
#define __SEQOPS_H

#include "seqinfo.h"

// lengths and residue distributions describing a pair of sequences
struct SeqPairDistn {
  SeqNumber nSeqs; 
  SeqNumber partition;
  
  SeqLength length1, length2;
  double freqs1[MAX_RESIDUES];
  double freqs2[MAX_RESIDUES];
};

SeqInfo computeComplement(const SeqInfo &s);

SeqInfo computeTranslation(const SeqInfo &sInput, int frame,
			   const Alphabet *aProtein);

void computeAggregateDistn(const SeqVector seqs, SeqNumber partition,
			   const Alphabet *a, SeqPairDistn &aggDistn);


#endif
