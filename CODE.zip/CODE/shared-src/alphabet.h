//
// ALPHABET.H
// The Alphabet class
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// An Alphabet is a collection of Residues
// (e.g. bases or amino acids).  By convention, there is always
// a RESIDUE_X (with value 0) that means "wildcard, unknown,
// or masked residue", while the values from 1 to nRealResidues()
// represent specific known residues.  Residues are compared
// using ordinary equality, except that an X always mismatches
// anything (even another X).
//
// Alphabets know how to parse and print their residues using
// the fromChar() and toChar() functions.  For convenience,
// the class also provides print() and printSeq() functions
// to print a Residue or string thereof to a specified ostream. 
//
 
#ifndef __ALPHABET_H
#define __ALPHABET_H

#include <iostream>

#include "datatypes.h"

typedef unsigned char Residue;

// Set to largest alphabet size of interest -- used for
// sizing static fields indexed by residue.
const int MAX_RESIDUES = 256;

class Alphabet {
private:
  enum PurPyrClass { PURINE, PYRIMIDINE, NEITHER };

public:
  enum { RESIDUE_X = 0, INVALID_CHAR = 255 };
  enum Type { DNA, PROTEIN };
  
  Alphabet(Type type, const char *residueNames, const char *addlXNames = NULL)
    : _valid(true)
  { init(type, residueNames, addlXNames); }
  
  Alphabet(const char *fileName, Type defaultType = DNA);
  
  ~Alphabet(void);
  
  unsigned int nResidues(void) const { return _nResidues; }
  unsigned int nRealResidues(void) const { return _nResidues - 1; }
  bool         isValid(void) const { return _valid; }
  
  bool isDNA(void) const     { return (_type == DNA); }
  bool isProtein(void) const { return (_type == PROTEIN); }
  
  void forceLowerCaseToX(void);
  
  static int isMatch(Residue r1, Residue r2)
  { return (r1 == r2 && r1 != RESIDUE_X); }
  
  static int isMismatch(Residue r1, Residue r2)
  { return (r1 != r2 || r1 == RESIDUE_X); }
  
  Residue fromChar(char c) const
  { return char2residue[c]; }
  
  char toChar(Residue r) const
  { return residue2char[r]; }
  
  std::ostream &print(Residue r, std::ostream &os) const
  { os << toChar(r); return os; }
  
  std::ostream &printSeq(const Residue *seq, SeqPosn length, 
			 std::ostream &os) const
  { 
    for (SeqPosn j = 0; j < length; j++)
      print(seq[j], os);
    return os;
  }
  
  //
  // operations for DNA only
  //
  Residue complement(Residue r) const { return complements[r]; }
  
  bool isPurine(Residue r) const
  { return (purpyrStatus[r] == PURINE); }
  
  bool isPyrimidine(Residue r) const
  { return (purpyrStatus[r] == PYRIMIDINE); }
  
  bool isTransition(Residue r1, Residue r2) const
  {return ((isPurine(r1)     && isPurine(r2)) || 
	   (isPyrimidine(r1) && isPyrimidine(r2))); }
  
private:
  unsigned int _nResidues;  // total # of Residues (including X)
  Type _type;               // type of alphabet
  bool _valid;              // was alphabet valid as read?
  
  char *residue2char;       // map from residues to characters
  Residue *char2residue;    // map from characters to residues
  
  Residue *complements;      // for DNA, complement of each base
  PurPyrClass *purpyrStatus; // for DNA, purine vs pyrimidine
  
  void init(Type type, const char *, const char *);
  bool readFromFastaFile(std::istream &, Type);
  bool readFromBlastFile(std::istream &, Type);
  void initPurpyrStatus(void);
};

#endif
