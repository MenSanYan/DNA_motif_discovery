//
// ALIGNALGOS.H
// Functions to compute sequence alignments
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __ALIGNALGOS_H
#define __ALIGNALGOS_H

#include "alignment.h"
#include "match.h"

//
// optimal ungapped local alignment; returns endpoints and score
//
ScoreT alignUngappedLocal(const Residue *iseq1, const Residue *iseq2, 
			  const ScoreMatrix &M,
			  SeqPosn s1, SeqPosn s2, SeqLength len,
			  Alignment &result);


//
// optimal ungapped local alignment, BLAST-style; returns endpoints and score
//
ScoreT alignUngappedBlast(const Residue *iseq1, const Residue *iseq2,
			  const ScoreMatrix &M, const Match &match,
			  SeqPosn s2, SeqPosn e2,
			  ScoreT XDrop, Alignment &result);


//
// optimal gapped forward semilocal alignment; returns endpoints and score
//
ScoreT alignGappedBandedFwd(const Residue *iseq1, const Residue *iseq2, 
			    const ScoreFunction &scoreFunction,
			    ScoreT minScore,
			    SeqPosn s1, SeqPosn s2, 
			    SeqPosn e1, SeqPosn e2,
			    SeqDiffT bandwidth,
			    Alignment &result);


//
// optimal gapped reverse semilocal alignment; returns endpoints and score
//
ScoreT alignGappedBandedBck(const Residue *iseq1, const Residue *iseq2, 
			    const ScoreFunction &scoreFunction,
			    ScoreT minScore,
			    SeqPosn s1, SeqPosn s2, 
			    SeqPosn e1, SeqPosn e2,
			    SeqDiffT bandwidth,
			    Alignment &result);

//
// Optimal gapped local alignment, pinned to go through a particular row.
// Returns score and larger endpoint (but not start point).
//
ScoreT alignGappedBandedLPin(const Residue *iseq1, const Residue *iseq2, 
			     const ScoreFunction &scoreFunction,
			     SeqPosn s1, SeqPosn s2, 
			     SeqPosn e1, SeqPosn e2, 
			     SeqDiffT bandwidth,
			     SeqPosn pinnedRow,
			     Alignment &result);

//
// Optimal gapped local alignment, pinned to go through a particular row.
// Returns score and both endpoints.
//
ScoreT alignGappedBandedLPinE(const Residue *iseq1, const Residue *iseq2, 
			      const ScoreFunction &scoreFunction,
			      SeqPosn s1, SeqPosn s2, 
			      SeqPosn e1, SeqPosn e2, 
			      SeqDiffT bandwidth,
			      SeqPosn pinnedRow,
			      Alignment &result);


//
// Optimal gapped local alignment, pinned to go through a particular row.
// Returns score, both endpoints, and alignment path.
//
ScoreT alignGappedBandedLPinA(const Residue *iseq1, const Residue *iseq2, 
			      const ScoreFunction &scoreFunction,
			      SeqPosn s1, SeqPosn s2, 
			      SeqPosn e1, SeqPosn e2, 
			      SeqDiffT bandwidth,
			      SeqPosn pinnedRow,
			      Alignment &result);

#endif
