//
// MATCHUTIL.CC
// Code to sort matches, remove duplicates, and merge overlaps.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <cstdlib>

#include "matchutil.h"

using namespace std;

//
// removeDuplicateMatches()
// Remove any exact duplicates from a match vector.
//
// RETURNS: vector of uniquified matches, which may or may not
// be in the same memory as the input vector.
//
MatchVector removeDuplicateMatches(MatchVector ms)
{
  if (ms.isEmpty())
    return ms;
  
  qsort(ms.elements(), ms.length(), sizeof(Match), cmpMatchesByStart);
  
  Match *mPrev = &(ms[0]);
  
  for (unsigned int currIdx = 1; currIdx < ms.length(); currIdx++)
    {
      const Match *mCurr = &(ms[currIdx]);
      
      // Duplication occurs only if two matches start at the same
      // position in the same two sequences.
      if (mCurr->low(0)   != mPrev->low(0) ||
	  mCurr->low(1)   != mPrev->low(1) ||
	  mCurr->seq(0)   != mPrev->seq(0) || 
	  mCurr->seq(1)   != mPrev->seq(1) ||
	  mCurr->length() != mPrev->length())
	{
	  *(++mPrev)  = *mCurr;
	}
    }
  
  unsigned int oldLength = ms.length();
  ms.truncate(mPrev - &(ms[0]) + 1);
  
  // Should we try to save memory?
  if (ms.length() <= oldLength / 2)
    return ms.copy();
  else
    return ms;
}


//
// mergeOverlappingMatches()
// Copy the matches in ms to an output vector.  If deleteOnly is false,
// merge overlapping matches in a given frame into a single interval.
// Otherwise, eliminate any matches with a left-overlap, that is,
// delete all m s.t. there exists m' in the same frame as m and 
//         start(m') <= start(m) < start(m') + length(m')
//
// RETURNS: vector of merged/uniquified matches.  We may either reuse the 
// current vector or allocate a new vector, depending on how much memory we
// would save by making a smaller copy.
//
MatchVector mergeOverlappingMatches(MatchVector ms, bool deleteOnly)
{
  if (ms.isEmpty())
    return ms;
  
  qsort(ms.elements(), ms.length(), sizeof(Match), cmpMatchesByFrame);
  
  Match *mPrev = &(ms[0]);
  SeqDiffT prevFrame = mPrev->frame();
  
  for (unsigned int currIdx = 1; currIdx < ms.length(); currIdx++)
    {
      const Match *mCurr = &(ms[currIdx]);
      SeqDiffT currFrame = mCurr->frame();
      
      // Don't try to merge matches between different sequences or
      // within different frames of the same pair of sequences.
      // Obviously, don't merge matches that don't overlap.
      //
      if (mCurr->seq(0) != mPrev->seq(0) || 
	  mCurr->seq(1) != mPrev->seq(1) || 
	  currFrame     != prevFrame     ||
	  mCurr->low(0) > mPrev->high(0))
	{
	  *(++mPrev) = *mCurr;
	  prevFrame = currFrame;
	}
      else if (!deleteOnly)                  // merge overlapper
	{
	  // Does new match extend old one?
	  if (mCurr->high(0) > mPrev->high(0))
	    mPrev->setLength(mCurr->high(0) - mPrev->low(0) + 1);
	}
    }
  
  unsigned int oldLength = ms.length();
  ms.truncate(mPrev - &(ms[0]) + 1);
  
  // Should we try to save memory?
  if (ms.length() <= oldLength / 2)
    return ms.copy();
  else
    return ms;
}


//////////////////////////////////////////////////////////////////////////
// match ordering functions
//////////////////////////////////////////////////////////////////////////


//
// cmpMatchesByStart()
// Ordering function on matches suitable for qsort(), inducing
// the following order:
//  * primary by sequence numbers (1st, then 2nd)
//  * secondary by starting position (1st, then 2nd)
//
int cmpMatchesByStart(const void *p0, const void *p1)
{
  const Match *m0 = (const Match *) p0;
  const Match *m1 = (const Match *) p1;
  
  if (m0->seq(0) == m1->seq(0))
    {
      if (m0->seq(1) == m1->seq(1))
	{
	  if (m0->low(0) == m1->low(0))
	    {
	      if (m0->low(1) < m1->low(1))
		return -1;
	      else
		return (m0->low(1) > m1->low(1));
	    }
	  else 
	    return (m0->low(0) < m1->low(0) ? -1 : 1);
	}
      else 
	return (m0->seq(1) < m1->seq(1) ? -1 : 1);
    }
  else 
    return (m0->seq(0) < m1->seq(0) ? -1 : 1);
}


//
// cmpMatchesByFrame()
// Ordering function on matches suitable for qsort(), inducing
// the following order:
//  * primary by sequence numbers (1st, then 2nd)
//  * secondary by frame (aka diagonal)
//  * tertiary by low(0)
//  * quaternary in DECREASING order by length
//
int cmpMatchesByFrame(const void *p0, const void *p1)
{
  const Match *m0 = (const Match *) p0;
  const Match *m1 = (const Match *) p1;
  
  SeqDiffT frame0 = m0->frame();
  SeqDiffT frame1 = m1->frame();
  
  if (m0->seq(0) == m1->seq(0))
    {
      if (m0->seq(1) == m1->seq(1))
        {
          if (frame0 == frame1)
            {
	      if (m0->low(0) == m1->low(0))
		{
		  if (m0->length() > m1->length())
		    return -1;
		  else
		    return (m0->length() < m1->length());
		}
	      else
		return (m0->low(0) < m1->low(0) ? -1 : 1);
	    }
          else 
            return (frame0 < frame1 ? -1 : 1);
        }
      else 
        return (m0->seq(1) < m1->seq(1) ? -1 : 1);
    }
  else 
    return (m0->seq(0) < m1->seq(0) ? -1 : 1);
}
