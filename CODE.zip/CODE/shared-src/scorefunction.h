//
// SCOREFUNCTION.H
// Scoring functions for alignment of biosequences
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2002 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __SCOREFUNCTION_H
#define __SCOREFUNCTION_H

#include <iostream>
#include <cstring>

#include "alphabet.h"
#include "vector.h"

typedef int ScoreT;
const ScoreT INFTY = (1 << 30) - 1;

// ungapped substitution scoring matrix
class ScoreMatrix {
public:
  ScoreMatrix(const Alphabet *a);
  
  ScoreMatrix(const ScoreMatrix &other)
    : values(NULL)
  { copy(other); }
  
  ScoreMatrix &operator=(const ScoreMatrix &other)
  { if (this != &other) copy(other); return *this; }
  
  ~ScoreMatrix(void)
  { if (values) delete [] values; }
  
  const Alphabet *alphabet(void) const   { return _alphabet; } 
  
  const ScoreT *operator[](Residue r) const { return &values[r << logLen]; }
  
  ScoreT xScore(void) const 
  { return (*this)[Alphabet::RESIDUE_X][Alphabet::RESIDUE_X]; }
  
  ScoreT minScore(bool includeX=false) const;
  ScoreT maxScore(bool includeX=false) const;
  
  void setEntry(Residue i, Residue j, ScoreT v)
  { values[(i << logLen) + j] = v; }

  
private:
  ScoreT *values;            // elements of the score matrix
  unsigned int logLen;       // log(smallest power of 2 >= _nResidues)
  
  const Alphabet *_alphabet;  // sequence alphabet labeling the matrix
  
  void copy(const ScoreMatrix &other);
  
  // compute log of next power of 2 >= vIn.
  unsigned int computeLogLen(unsigned int vIn)
  {
    unsigned int vLog = (unsigned int) -1;
    for (unsigned int v = vIn; v != 0; v >>= 1, vLog++);
    return ((1U << vLog) == vIn ? vLog : vLog + 1);
  }
};

std::ostream &operator<<(std::ostream &os, const ScoreMatrix &);


class ScoreFunction {
public:
  struct GappedKAValues {
    ScoreT gapOpen;
    ScoreT gapExt;
    double lambda;
    double K;
  };
  
  
  ScoreFunction(const Alphabet *a, const char *scoreFileName = NULL);
  
  ~ScoreFunction(void) { if (_name) delete [] _name; }
  
  //
  // inspectors
  //
  const char *name(void) const        { return _name;    }
  bool isValid(void) const            { return _valid;   }
  ScoreT gapOpen(void) const          { return _gapOpen; }
  ScoreT gapExt(void) const           { return _gapExt;  }
  const ScoreMatrix &subs(void) const { return S;        }
  
  //
  // mutators for building a score function manually
  //
  void setName(const char *iname) 
  { 
    if (_name) delete [] _name; 
    char *tname = new char [std::strlen(iname)+1];
    std::strcpy(tname, iname);
    _name = tname;
  }

  void setValid(bool v)     { _valid = v; }
  void setGapOpen(ScoreT v) { _gapOpen = v; }
  void setGapExt(ScoreT v)  { _gapExt  = v; }
  
  const GappedKAValues *getGappedKAValues(ScoreT gapOpen, ScoreT gapExt) const;
  
private:
  const char *_name;
  bool _valid;
  ScoreT _gapOpen;
  ScoreT _gapExt;
  
  ScoreMatrix S;
  
  Vector<GappedKAValues> gappedKAValues;
  
  bool readFile(const char *);
  bool readFastaFile(std::istream &);
  bool readBlastFile(std::istream &);
  void readGappedKAValues(const char *);
  
  bool getAlphabetMapping(std::istream &, Vector<Residue> &, const Alphabet *);
};

std::ostream &operator<<(std::ostream &os, const ScoreFunction &);

#endif
