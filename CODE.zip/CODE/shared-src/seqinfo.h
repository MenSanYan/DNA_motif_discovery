//
// SEQINFO.H
// Information about a biosequence
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __SEQINFO_H
#define __SEQINFO_H

#include "datatypes.h"
#include "alphabet.h"
#include "annotation.h"
#include "vector.h"

struct SeqInfo {
  SeqNumber seqNum;             // sequence number
  SeqLength length;             // length of sequence
  const Alphabet *alphabet;     // sequence's alphabet
  bool complement;              // is the sequence reverse-complemented?
  
  Residue *data;                // actual sequence data
  const char *title;            // FASTA one-line title
  AnnotationVector annotations; // sequence annotations
  
  SeqLength unmaskedLength;     // length after removing masked positions
  double freqs[MAX_RESIDUES];   // residue frequencies
  
  bool isDNA(void) const     { return alphabet->isDNA();     }
  bool isProtein(void) const { return alphabet->isProtein(); }
};

typedef Vector<SeqInfo>   SeqVector;
typedef Vector<SeqNumber> SeqNumVector;

#endif
