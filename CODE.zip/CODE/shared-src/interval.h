//
// INTERVAL.H
// A closed, directed interval of a sequence
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// NOTE: this code assumes that low <= high, so that high - low is
// well-defined for an unsigned type.  Don't violate this assumption
// in the constructor or through setLow() and setHigh().
//

#ifndef __INTERVAL_H
#define __INTERVAL_H

#include "datatypes.h"
#include "direction.h"
#include "vector.h"
#include "minmax.h"

class Interval {
public:
  
  Interval(void) : _low(0), _high(0), _dir(FORWARD) {}
  
  Interval(SeqPosn ilow, SeqPosn ihigh, Direction idir = FORWARD)
    : _low(ilow), _high(ihigh), _dir(idir) {}
  
  //
  // Basic inspectors
  //
  
  // Return the lower boundary of the interval in the forward orientation.
  SeqPosn low(void)   const { return _low; }
  
  // Return the upper boundary of the interval in the forward orientation.
  SeqPosn high(void)  const { return _high; }
  
  // Return the interval's native orientation.
  Direction dir(void) const { return _dir; }
  
  //
  // Mutators
  //
  
  void setLow(SeqPosn v)       { _low  = v; }
  void setHigh(SeqPosn v)      { _high = v; }
  void setDir(Direction v)     { _dir  = v; }
  
  //
  // Derived inspectors
  //
  
  SeqLength length (void) const { return _high - _low + 1; }
  
  // Return the starting index of the interval in the forward orientation.
  // This index depends on the interval's direction.
  SeqPosn start(void) const { return (dir() == REVERSE ? high() : low()); }
    
  // Return the ending index of the interval in the forward orientation.
  // This value depends on the interval's direction.
  SeqPosn end(void) const { return (dir() == REVERSE ? low() : high()); }
  
  //
  // Other functions
  //
  
  // Intersect this interval with another interval; return a new
  // interval containing the intersection.
  //
  // NOTE: we arbitrarily set the new interval's direction
  // to that of this interval.
  //
  Interval intersect(const Interval &other) const
  { 
    SeqPosn newLow  = MAX(low(),  other.low());
    SeqPosn newHigh = MIN(high(), other.high());
    
    return Interval(newLow, newHigh, dir());
  }
  
  // Intersect this interval with another interval; modify 
  // this interval in place.
  void trim(const Interval &other)
  { 
    SeqPosn newLow  = MAX(low(),  other.low());
    SeqPosn newHigh = MIN(high(), other.high());
    
    setLow(newLow); setHigh(newHigh);
  }
  
  
  // Merge this interval with another interval; return a new
  // interval containing the union.
  //
  // NOTE: we arbitrarily set the new interval's direction
  // to that of this interval.
  //
  Interval unify(const Interval &other) const
  {
    SeqPosn newLow  = MIN(low(), other.low());
    SeqPosn newHigh = MAX(high(), other.high());
    
    return Interval(newLow, newHigh, dir());
  }
  
  
  // Merge this interval with another interval; modify
  // this interval in place.
  void extend(const Interval &other)
  {
    SeqPosn newLow  = MIN(low(), other.low());
    SeqPosn newHigh = MAX(high(), other.high());
    
    setLow(newLow); setHigh(newHigh);
  }
  
  // Express an interval relative to a base interval.
  Interval relativeTo(const Interval &base) const;
  
private:
  
  SeqPosn _low, _high;   // endpoints of interval in fwd orientation
  Direction _dir;        // true orientation of interval
};

typedef Vector<Interval> IntervalVector;

// returns true iff i1 and i2 have the same extent
inline bool operator==(const Interval &i1, const Interval &i2)
{
  return (i1.low() == i2.low() && i1.high() == i2.high());
}

// returns true iff i1 overlaps i2
inline bool overlaps(const Interval &i1, const Interval &i2)
{
  return (i1.low() <= i2.high() && i1.high() >= i2.low());
}

// returns true iff i1 is contained in i2
inline bool contains(const Interval &i1, const Interval &i2)
{
  return (i1.low() >= i2.low() && i1.high() <= i2.high());
}

///////////////////////////////////////////////////////////////////////////

// A keyed interval is simply an interval aggregated with a "key", which
// is a sequence number (usually representing the sequence from which
// the interval was taken).

class KeyedInterval : public Interval {
public:
  KeyedInterval(void) : Interval() {}
  KeyedInterval(SeqPosn low, SeqPosn high, SeqNumber key)
    : Interval(low, high), _key(key) {}
  
  // default copy constructor and operator= are appropriate
  
  //
  // Copy constructor and operator= for base interval type -- just
  // copy the interval part and set the key to 0.  I'm probably
  // going to OO hell for not aggregating the interval with the
  // key instead of deriving a new type.
  //
  
  KeyedInterval(const Interval &other)
    : Interval(other), _key(0) {}
  
  KeyedInterval &operator=(const Interval &other)
  {
    setDir(other.dir()); setLow(other.low()); setHigh(other.high());
    _key = 0;
    return *this;
  }
  
  SeqNumber      key(void) const { return _key; }
  void setKey(SeqNumber v)       { _key = v;    }
  
private:
  SeqNumber _key;
};

typedef Vector<KeyedInterval> KeyedIntervalVector;

#endif
