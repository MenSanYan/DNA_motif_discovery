//
// FILEOPS.CC
// Operations on filenames
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <cstdlib>
#include <cstring>
#include <cctype>

#include "fileops.h"

using namespace std;

//
// computeFullScorePath()
// Compute the full path to a score file specified on the command line.
// If the filename contains a directory separator, assume that it
// points to an explicit filename.  Otherwise, assume that the file
// is in the canonical DATA_DIR directory, and that its name is
// case-insensitive (must be converted to all upper).
//
// RETURNS: pointer to newly allocated full path string
//
char *computeFullScorePath(const char *scoreFileName)
{
  char *pathName = new char [PATH_MAX + 1 + 4];
  pathName[PATH_MAX] = 0;
  
  if (strchr(scoreFileName, DirSeparator))
    strncpy(pathName, scoreFileName, PATH_MAX);
  else
    {
      const char *dataDir = getenv("PROJECTION_DATA_DIR");
      if(!dataDir)
        dataDir = DATA_DIR;
      strncpy(pathName, dataDir, PATH_MAX - 1);
      strcat(pathName, DirSepString);
      strncat(pathName, scoreFileName, PATH_MAX - strlen(dataDir) - 1);
      
      // convert the score function file name to all upper-case
      char *tail = strrchr(pathName, DirSeparator);
      if (!tail)
	tail = pathName;
      else
	tail++;
      
      for (; *tail != 0; tail++)
	*tail = toupper(*tail);
    }
  
  return pathName;
}
