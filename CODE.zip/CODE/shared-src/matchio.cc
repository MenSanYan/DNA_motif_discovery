//
// MATCHIO.CC
// I/O for Match data
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>

#include "matchio.h"
#include "parseline.h"

using namespace std;

//
// readMatchesFromStream()
// Read a list of matches from a stream. A single match is a line of the
// following form:
//
// <seq #1> <str #1> <idx #1> <seq #2> <str #2> <idx #2> <length>
//
//  seq #1, seq #2 -- sequence numbers (1-based)
//  str #1, str #2 -- strands on which match occurs (ignored)
//  idx #1, idx #2 -- sequence indices of match start (1-based)
//  length         -- length of match
//
// RETURNS: vector of read matches
//
MatchVector readMatchesFromStream(istream &is)
{
  MatchVector matches;
  int lineNum;
  
  for (lineNum = 1; !is.eof(); lineNum++)
    {
      unsigned long val;
      Match match;
      
      if (!consumeWhiteSpace(is))
	{
	  if (is.eof())
	    break;
	  else
	    {
	      is.get(); // consume EOL
	      continue;
	    }
	}
      
      for (int j = 0; j < 2; j++)
	{
	  Direction strand;
	  
	  if (!parseNumber(is, &val))
	    goto error;
	  else if (val == 0)
	    {
	      cerr << "Error: sequence numbers must be >= 1\n";
	      goto error;
	    }
	  else
	    match.setSeq(j, SeqNumber(val) - 1);
	  
	  if (!parseDirection(is, &strand)) // read but ignore strand
	    goto error;
	  
	  if (!parseNumber(is, &val))
	    goto error;
	  else if (val == 0)
	    {
	      cerr << "Error: sequence indices must be >= 1\n";
	      goto error;
	    }
	  else
	    match.setLow(j, SeqPosn(val) - 1);
	}
      
      if (!parseNumber(is, &val))
	goto error;
      else
	match.setLength(SeqLength(val));
      
      // handle any trailing blanks on the line
      if (consumeWhiteSpace(is))
	{
	  cerr << "Error: extraneous fields at end of line\n";
	  goto error;
	}
      else
	is.get(); // consume EOL
      
      matches.add(match);
    }
  
  return matches;
  
 error:
  cerr << "Error parsing match on line " << lineNum << '\n';
  matches.truncate();
  return matches;
}
