//
// ALIGNMENT.H
// Sequence alignment structure
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __ALIGNMENT_H
#define __ALIGNMENT_H

#include "scorefunction.h"
#include "seqinfo.h"
#include "vector.h"

class Interval;

class Alignment {
public:
  
  // We describe gapped alignment paths as a Vector of steps.
  //
  enum Step {
    MATCH, // align next two residues 
    GAP1,  // insert gap in sequence 1
    GAP2   // insert gap in sequence 2
  };
  
  typedef Vector<Step> Path;
  
  Alignment(void) : _eValue(-1) {}
  
  Alignment(SeqNumber seq0, SeqNumber seq1,
	    SeqPosn start0, SeqPosn end0,
	    SeqPosn start1, SeqPosn end1)
    : _eValue(-1)
  {
    seqs[0]   = seq0;     seqs[1] = seq1;
    starts[0] = start0; starts[1] = start1;
    ends[0]   = end0;     ends[1] = end1;
  }
  
  // basic inspectors
  
  SeqNumber  seq(int j)   const { return seqs[j]; }
  SeqPosn    start(int j) const { return starts[j]; }
  SeqPosn    end(int j)   const { return ends[j]; }
  const Path path(void)   const { return _path; }
  
  // basic mutators
  
  void setSeq(int j, SeqNumber v) { seqs[j] = v; }
  void setStart(int j, SeqPosn v) { starts[j] = v; }
  void setEnd(int j, SeqPosn v)   { ends[j] = v; }
  void setPath(Path p)            { _path = p; }
  
  // Set all four endpoints of an alignment at once.
  void setEndpoints(SeqPosn s0, SeqPosn e0, SeqPosn s1, SeqPosn e1)
  { starts[0] = s0; starts[1] = s1; ends[0] = e0; ends[1] = e1; }
    
  // Return length of an alignment, derived from its endpoints
  // (returns the right answer for ungapped and a sensible
  // approximation for gapped alignments).
  //
  SeqLength length(void) const 
  { return (ends[0] - starts[0] + ends[1] - starts[1] + 2)/2; }
  
  ////////////////////////////////////////////////////////////////////
  
  // additional inspectors
  
  Direction  dir(int j)  const         { return dirs[j]; }
  ScoreT    score(void)  const         { return _score; }
  double    eValue(void) const         { return _eValue; }
  SeqLength maxMatchLength(void) const { return _maxMatchLength; }
  
  // additional mutators
  
  void setDir(int j, Direction v)     { dirs[j] = v; }
  void setScore(ScoreT v)             { _score = v; }
  void setEValue(double v)            { _eValue = v; }
  void setMaxMatchLength(SeqLength v) { _maxMatchLength = v; }
  
  // Convert the jth interval of the alignment to an Interval in
  // direction dir(j) [makes sense for gapped or ungapped].
  Interval toInterval(int j) const;
  
  // Transform an interval from one sequence an alignment to the other,
  // taking account of dirs.  Right now, this only works correctly
  // for ungapped alignments.
  //
  Interval transformTo(const Interval &iSrc, int dstSeq) const;
  
private:
  
  SeqNumber   seqs[2];   // numbers of sequences involved in alignment
  SeqPosn   starts[2];   // starting positions of alignment
  SeqPosn     ends[2];   // ending   positions of alignment
  Path _path;            // alignment path (gapped alignments only)
  
  Direction   dirs[2];   // direction of aligned intervals w/r to fwd strand
  ScoreT _score;         // alignment score
  double _eValue;        // alignment E-value
  
  SeqLength _maxMatchLength; // longest exact match length in alignment
};

typedef Vector<Alignment> AlignmentVector;

#endif
