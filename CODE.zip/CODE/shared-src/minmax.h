//
// MINMAX.H
// Shared min and max primitives
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __MINMAX_H
#define __MINMAX_H
template <class T> inline T MIN(T a, T b) { return (a < b ? a : b); }
template <class T> inline T MAX(T a, T b) { return (a > b ? a : b); }

#endif
