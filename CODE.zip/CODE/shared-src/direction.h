//
// DIRECTION.H
// Describes strand direction for a sequence
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __DIRECTION_H
#define __DIRECTION_H

#include <iostream>

enum Direction { FORWARD, REVERSE };

inline Direction opposite(Direction dir) 
{ return (dir == FORWARD ? REVERSE : FORWARD); }

inline std::ostream &operator<<(std::ostream &os, Direction dir)
{
  os << (dir == FORWARD ? 'f' : 'r');
  return os;
}

#endif
