//
// PARSELINE.CC
// Line-oriented stream parsing code
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>
#include <cctype>

#include "parseline.h"

using namespace std;

//
// consumeWhiteSpace()
// Consume characters up to EOL, EOF, or next non-whitespace character.
//
// RETURNS: true iff we terminated on a non-whitespace, non-EOL character
// without reaching EOF.
//
// EFFECTS: stream is positioned at EOL, EOF, or first non-whitespace char.
//
bool consumeWhiteSpace(istream &is)
{
  for (;;)
    {
      int nextChar = is.peek();
      
      switch(nextChar)
	{
	case EOF:
	case EOL:
	  return false;
	  
	default:
	  if (isspace(nextChar))  // eat next space
	    is.get();
	  else                    // found a non-space
	    return true;
	  break;
	}
    }
}


//
// consumeNonWhiteSpace()
// Consume characters up to EOL, EOF, or next whitespace character.
// Return true iff we terminated on a non-EOL whitespace character
// without reaching EOF.
//
// EFFECTS: stream is positioned at EOL, EOF, or first whitespace char.
//
bool consumeNonWhiteSpace(istream &is)
{
  for (;;)
    {
      int nextChar = is.peek();
      
      switch(nextChar)
	{
	case EOF:
	case EOL:
	  return false;
	  
	default:
	  if (!isspace(nextChar))  // eat next non-space
	    is.get();
	  else                     // found a space
	    return true;
	  break;
	}
    }
}


//
// parseChar()
// Parse a single non-whitespace character, which may be preceded by
// arbitrary whitespace.
//
// RETURNS: true iff a character was read successfully.
// EFFECTS: If successful, positions stream at first character after
//          the one returned; otherwise, positions stream at EOF or EOL.
//
bool parseChar(istream &is, char *c)
{
  if (!consumeWhiteSpace(is))
    {
      *c = NIL;
      return false;
    }
  
  int i = char( is.get() );
  if (i == EOF)
    return false;
  else
    {
      *c = char(i);
      return true;
    }
}


//
// ParseString()
// Parse a character string.  If it is quoted, parse up to the end quote;
// otherwise, parse up to the first whitespace character.  The string
// may be preceded by arbitrary whitespace.
//
// RETURNS: true iff we were able to parse up to the end of the string.
// For quoted strings, we must see the closing quote; for others,
// we must reach EOL or EOF or see a whitespace character.
//
// EFFECTS: the buffer is NIL-terminated.  The stream is positioned at
// the character which terminated the string, or at EOF/EOL if a
// quoted string was not properly terminated.
//
bool parseString(istream &is, char *buf, size_t maxLength)
{
  bool foundEOS = false;
  bool quoted = false;
  size_t bufIdx = 0;
  
  if (maxLength < 2) // for very short strings, we can't read anything
    {
      if (maxLength)
	*buf = NIL;
      return true;
    }
  
  if (!consumeWhiteSpace(is))
    {
      *buf = NIL;
      return false;
    }
  
  //
  // The first character determines whether we're reading a quoted
  // or an unquoted string.
  //
  if (is.peek() == '\"')
    {
      is.get();
      quoted = true;
    }
  
  //
  // Read characters until we reach the end of the string, OR we
  // fill the buffer, OR we reach EOF or EOL.
  //
  for (;;)
    {
      int nextChar = is.peek();
      
      if (nextChar == EOF || nextChar == EOL)   // stop at EOF or EOL
	{
	  if (!quoted)
	    foundEOS = true;     // EOS only if we don't need closing quote
	  else
	    cerr << "Error: EOL while searching for closing quote\n";
	  
	  break;
	}
      
      if (quoted)
	{
	  if (nextChar == '\"')              // found closing quote
	    {
	      is.get();
	      foundEOS = true;
	      break;
	    }
	}
      else
	{
	  if (isspace(nextChar))             // found EOS at whitespace
	    {
	      foundEOS = true;
	      break;
	    }
	}
      
      if (bufIdx < maxLength - 1)
	{
	  is.get();
	  buf[bufIdx++] = char(nextChar);
	}
      else                                    // buffer is full
	{
	  buf[bufIdx] = NIL;
	  cerr << "Error: string \"" << buf << "\" exceeds max length "
	       << maxLength - 1 << '\n';
	  break;
	}
    }
  
  buf[bufIdx] = NIL;
  return foundEOS;
}


//
// parseDirection()
// Parse a Direction value, which must be an unquoted string starting with
// with 'f' or 0 (for forward) or 'r', 'c', or 1 (for reverse-complement).
// Case is not significant.  The value may be preceded by arbitrary
// whitespace.
//
// RETURNS: true iff a direction value was read successfully.
// EFFECTS: If successful, positions stream at first whitespace/EOL
//          character after direction string.  If failed, positions stream
//          at character which caused failure.
//
bool parseDirection(istream &is, Direction *direction)
{
  char c;
  
  if (!parseChar(is, &c))
    {
      *direction = FORWARD;
      return false;
    }
  
  switch(tolower(c))
    {
    case 'f':
    case '0':
      *direction = FORWARD;
      break;
      
    case 'r':
    case 'c':
    case '1':
      *direction = REVERSE;
      break;
      
    default:                   // unknown direction type
      cerr << "Error: unknown direction '" << c << "'\n";
      *direction = FORWARD;
      return false;
    }
  
  consumeNonWhiteSpace(is);
  return true;
}

/////////////////////////////////////////////////////////////////////////

//
// _parseNumber()
// Parse an unsigned integer value up to a specified number of digits.
// The value may be preceded by arbitrary whitespace.
//
// RETURNS: true iff we were able to parse a complete number.  If
//          there were too many digits to form a value,
//          or we were unable to read any number at all.
// EFFECTS: positions stream at first character after number, or
//          at first digit which caused the number to be too long.
//
bool _parseNumber(istream &is, unsigned long *value, int MaxDigits)
{
  const int MAXDIGITS = 50; // big enough to hold 2^128 in decimal
  static char numBuf[MAXDIGITS+1];
  int digit;
  
  if (!consumeWhiteSpace(is))
    {
      value = 0;
      return false;
    }
  
  bool foundEnd = false;
  for (digit = 0; digit <= MAXDIGITS; digit++)
    {
      int nextChar = is.peek();
      if (!isdigit(nextChar))
	{
	  if (digit > 0)
	    foundEnd = true;
	  
	  break;
	}
      
      if (digit < MaxDigits)
	{
	  is.get();
	  numBuf[digit] = char(nextChar);
	}
      else                              // stop w/o finding end of number
	{
	  numBuf[digit] = NIL;
	  cerr << "Error: number \"" << numBuf << "...\" is too long "
	       << "(> " << MaxDigits << " digits)\n";
	  break;
	}
    }
  
  numBuf[digit] = NIL;
  
  *value = strtoul(numBuf, NULL, 10);
  return foundEnd;
}
