//
// GENSEQS.CC
// Generate test sequences according to the planted motif model
//

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cstring>

#include <unistd.h> // for getopt()

#include "datatypes.h"
#include "version.h"

#include "basegenerator.h"
#include "random.h"

using namespace std;


const SeqLength DefaultMotifLength = 15; // length of motif
const SeqLength DefaultNErrors     = 4;  // # of errors per instance
const SeqLength DefaultSLength = 600;    // common length of all seqs
const SeqNumber DefaultNSeqs   =  20;    // # of sequences to generate
const SeqNumber DefaultNMotifs =  20;    // # of sequences containing motifs

const double DefaultGCFraction = 0.50; // GC fraction in background seqs
const double MotifProbs[] = {0.0, 0.25, 0.25, 0.25, 0.25};

//////////////////////////////////////////////////////////////////////////////

SeqLength MotifLength = DefaultMotifLength;
SeqLength NErrors = DefaultNErrors;
SeqLength SLength = DefaultSLength;
SeqNumber NSeqs   = DefaultNSeqs;
SeqNumber NMotifs = DefaultNMotifs;
double GCFraction = DefaultGCFraction;


//
// local prototypes
//
static void printUsage(void);
static void parseArgs(int argc, char *argv[]);

static void emitSeq(SeqNumber, SeqLength, const Alphabet *,
		    const ResidueGenerator &,
		    const Residue *, SeqLength, SeqLength,
		    bool plantMotif = true);


int main(int argc, char *argv[])
{
  Alphabet alphabet(Alphabet::DNA, "acgt", "x");
  const Residue BASE_A = alphabet.fromChar('a');
  const Residue BASE_C = alphabet.fromChar('c');
  const Residue BASE_G = alphabet.fromChar('g');
  const Residue BASE_T = alphabet.fromChar('t');
  
  parseArgs(argc, argv);
  
  // initialize the background distribution as directed
  double BackgroundProbs[5];
  BackgroundProbs[BASE_G] = BackgroundProbs[BASE_C] = 0.5 * GCFraction;
  BackgroundProbs[BASE_A] = BackgroundProbs[BASE_T] = 0.5 * (1.0 - GCFraction);
  BackgroundProbs[Alphabet::RESIDUE_X] = 0.0;
  
  ResidueGenerator bgGenerator(&alphabet, BackgroundProbs);
  ResidueGenerator motifGenerator(&alphabet, MotifProbs);
  
  seedPRNG();
  
  Residue *motif = new Residue [MotifLength];
  
  motifGenerator.genSeq(motif, MotifLength);
  
  for (SeqNumber j = 0; j < NSeqs; j++)
    {
      emitSeq(j, SLength, &alphabet, bgGenerator, motif, MotifLength, NErrors,
	      (j < NMotifs));
    }
  
  delete [] motif;
  
  return 0;
}


static void parseArgs(int argc, char *argv[])
{
  int optchar;
  
  opterr = 0; // don't let getopt() print its own error msgs
  
  while ((optchar = getopt(argc, argv, "-l:d:n:g:t:T:h")) >= 0)
    {
      switch (optchar)
	{
	case 'l':
	  MotifLength = SeqLength( strtoul(optarg, NULL, 10) );
	  if (MotifLength == 0)
	    {
	      cerr << "Error: motif length must be > 0\n";
	      exit(1);
	    }
	  break;
	  
	case 'd':
	  NErrors = SeqLength( strtoul(optarg, NULL, 10) );
	  break;
	  
	case 'n':
	  SLength = SeqLength( strtoul(optarg, NULL, 10) );
	  break;
	  
	case 'T':
	  NMotifs = SeqNumber( strtoul(optarg, NULL, 10) );
	  break;
	  
	case 't':
	  NSeqs = SeqLength( strtoul(optarg, NULL, 10) );
	  break;
	  
	case 'g':
	  GCFraction = strtod(optarg, NULL);
	  if (GCFraction < 0.0 || GCFraction > 1.0)
	    {
	      cerr << "Error: GC fraction must be between 0 and 1\n";
	      exit(1);
	    }
	  break;
	  
	case 'h':
	  printUsage();
	  exit(1);
	  
	case 1:
	  cerr << "Error: I don't understand argument '" << optarg << "'\n";
	  printUsage();
	  exit(1);
	  
	case '?':
	default:
	  cerr << "Error: unknown option '"
	       << char(optopt) << "'\n";
	  printUsage();
	  exit(1);
	}
    }
  
  if (NMotifs > NSeqs)
    {
      cerr << "Warning: # of sequences " << NSeqs 
	   << " < # of motifs " << NMotifs << '\n';
      cerr << " (only generating " << NSeqs << " motifs)\n";
      
      NMotifs = NSeqs;
    }
  
  if (SLength < MotifLength)
    {
      cerr << "Error: sequence length must be >= motif length\n";
      exit(1);
    }
  
  return;
}


static void printUsage(void)
{
  printVersion();
  
  cerr << "Syntax: genseqs [-l #] [-d #] [-n #] [-t #] [-T #] [-g #]\n";
  cerr << "   -l #          -- length of motif (default " 
       << DefaultMotifLength << ")\n";
  cerr << "   -d #          -- max # of errors per instance (default "
       << DefaultNErrors << ")\n";
  cerr << "   -n #          -- length of each background sequence (default "
       << DefaultSLength << ")\n";
  cerr << "   -t #          -- number of sequences (default "
       << DefaultNSeqs << ")\n";
  cerr << "   -T #          -- number of seqs WITH MOTIFS (default "
       << DefaultNMotifs << ")\n";
  cerr << "   -g #          -- default G+C fraction in background (default "
       << DefaultGCFraction << ")\n";
  cerr << '\n';
}

////////////////////////////////////////////////////////////////////////
// SEQUENCE GENERATOR
////////////////////////////////////////////////////////////////////////

//
// emitSeq()
// Print a random sequence of specified length, generated according
// to a specified background distribution, to standard output.  If 
// plantMotif is true, insert a copy of the motif at a random position 
// with nErrors errors inserted uniformly at random with replacement.
//
static void emitSeq(SeqNumber seqNum, SeqLength length,
		    const Alphabet *alphabet,
		    const ResidueGenerator &bgGenerator,
		    const Residue *motif, SeqLength motifLength,
		    SeqLength nErrors,
		    bool plantMotif)
{
  ResidueGenerator UniformGenerator(alphabet);
  Residue *seq = new Residue [length];
  
  // generate the background sequence
  bgGenerator.genSeq(seq, length);

  if (plantMotif)
    {
      // plant the motif at a random position in the sequence
      SeqPosn motifStart  = randVal(length - motifLength + 1);
      Residue *motifInstance = seq + motifStart;
      
      memcpy(motifInstance, motif, motifLength);
      
      // Add nErrors mutations uniformly at random w/o replacement.  If a
      // position is set to change, make sure it really changes!
      //
      SeqPosn *eposns = new SeqPosn [nErrors];
      SeqLength errs = 0;
      
      do
        {
          SeqPosn eposn = randVal(motifLength);
          bool add = true;
          
          // make sure we haven't used eposn yet
          for (SeqPosn k = 0; k < errs; k++)
            {
              if (eposns[k] == eposn)
                {
                  add = false;
                  break;
                }
            }
          
          if (add)
            eposns[errs++] = eposn;
        }
      while (errs < nErrors);
      
      for (SeqPosn j = 0; j < nErrors; j++)
        {
          SeqPosn posn = eposns[j];
          Residue b;
          
	  // make sure the residue changes!
          do
            b = UniformGenerator.genResidue();
          while (motifInstance[posn] == b);
          
          motifInstance[posn] = b;
        }
      
      delete [] eposns;
      
      cout << ">Seq " 
	   << setw(3) << seqNum     + 1 << ' ' 
	   << setw(4) << motifStart + 1 << ' ';
      alphabet->printSeq(motifInstance, motifLength, cout);
    }
  else
    cout << "> Seq " 
	 << setw(3) << seqNum + 1 
	 << " NO MOTIF";
  
  if (seqNum == 0) // make sure we record the real motif
    {
      cout << ' ';
      alphabet->printSeq(motif, motifLength, cout);
    }
  
  cout << '\n';
  alphabet->printSeq(seq, length, cout);
  cout << '\n';
  
  delete [] seq;
}
