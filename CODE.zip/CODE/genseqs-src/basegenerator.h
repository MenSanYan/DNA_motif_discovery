//
// RESIDUEGENERATOR.H
// Encapsulated generator for random residues following a given distribution
//
// NOTE: this generator uses random(), so you must call srandom().
//

#ifndef __RESIDUEGENERATOR_H
#define __RESIDUEGENERATOR_H

#include <climits>

#include "datatypes.h"
#include "alphabet.h"
#include "random.h"

class ResidueGenerator {
public:
  ResidueGenerator(const Alphabet *a, const double *probs)  { init(a, probs); }
  ResidueGenerator(const Alphabet *a)                       { init(a); }
  
  ~ResidueGenerator(void)
  { delete [] cdf; }
  
  // Generate a random residue according to our distribution
  Residue genResidue(void) const
  {
    unsigned int v = randUInt();
    unsigned int j = 1;
    
    while (v > cdf[j])
      j++;
    
    return (Residue) j;
  }
  
  // Generate a sequence of length random residues according to our
  // distribution, storing the result in the given string
  //
  void genSeq(Residue *seq, SeqLength length) const
  {
    for (SeqPosn j = 0; j < length; j++)
      seq[j] = genResidue();
  }
  
private:
  
  void init(const Alphabet *a, const double *probs = NULL)
  {
    double cumProb = 0.0;
    double *lprobs = NULL;
    
    cdf = new unsigned int [a->nResidues()];
    cdf[0] = 0;
    
    if (probs == NULL)
      {
	lprobs = new double [a->nResidues()];
	lprobs[0] = 0.0;
	for (Residue j = 1; j <= a->nRealResidues(); j++)
	  lprobs[j] = 1.0 / a->nRealResidues();
	probs = lprobs;
      }
    
    for (Residue j = 1; j < a->nRealResidues(); j++)
      {
	cumProb += probs[j];
	cdf[j] = (unsigned int) (cumProb * UINT_MAX + 0.5);
      }
    
    cdf[a->nRealResidues()] = UINT_MAX;
    
    if (lprobs)
      delete [] lprobs;
  }
  
  unsigned int *cdf;
};

#endif
