//
// EXTEND.CC
// Match extension and assembly
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// Extend and assemble a collection of fixed-length matches into longer
// regions of high similarity.  The resulting regions are not trimmed or
// otherwise cleaned up; that task is left to later alignment code.
//

#include <cstdlib>
#include <cassert>

#include "extend.h"

#include "matchutil.h"
#include "scorechecker.h"

using namespace std;


// Check this many residues to either side of each match.
//
const SeqLength CHECKSIZE = 500;


//
// extendMatches()
//
MatchVector extendMatches(MatchVector ms, 
			  const SeqVector sequences,
			  SeqLength matchLength,
			  ScoreT minScore,
			  const ScoreFunction *F)
{
  if (ms.isEmpty())
    return ms;
  
  // We coalesce the checking intervals for overlapping matches from
  // the same frame to avoid lots of yucky redundant checking.  To make
  // coalescing easy, process the matches in order by frame and within that
  // by starting index.
  //
  qsort(ms.elements(), ms.length(), sizeof(Match), cmpMatchesByFrame);
  
  unsigned int mIdx = 0;
  MatchVector ms2;
  do
    {
      SeqNumber seqNum1 = ms[mIdx].seq(0);
      SeqNumber seqNum2 = ms[mIdx].seq(1);
      
      const SeqInfo &seq1 = sequences[seqNum1];
      const SeqInfo &seq2 = sequences[seqNum2];
      
      ScoreChecker checker(seq1, seq2, matchLength, minScore, F->subs());
      
      SeqDiffT currFrame;
      Interval i;
      
      // initialize current interval/frame for this sequence of Matches
      {
	const Match &m = ms[mIdx];
	
	i.setLow((m.low(1) < CHECKSIZE ? 0 : m.low(1) - CHECKSIZE));
	i.setHigh(m.high(1) + CHECKSIZE);
	
	currFrame = m.frame();
      }
      
      for (mIdx++;
	   mIdx < ms.length() &&
	   ms[mIdx].seq(0) == seqNum1 &&
	   ms[mIdx].seq(1) == seqNum2;
	   mIdx++)
	{
	  const Match &m = ms[mIdx];
	  SeqDiffT frame = m.frame();
	  
	  if (frame != currFrame)                      // start new frame?
	    {
	      checker.checkInterval(i, currFrame);

	      i.setLow((m.low(1) < CHECKSIZE ? 0 : m.low(1) - CHECKSIZE));
	      i.setHigh(m.high(1) + CHECKSIZE);
	      
	      currFrame = frame;
	    }
	  else if (m.low(1) > i.high() + CHECKSIZE)    // start new interval?
	    {
	      checker.checkInterval(i, currFrame);
	      
	      i.setLow(m.low(1)   - CHECKSIZE);
	      i.setHigh(m.high(1) + CHECKSIZE);
	    }
	  else
	    {
	      if (m.high(1) + CHECKSIZE > i.high())    // extend interval?
		i.setHigh(m.high(1) + CHECKSIZE);
	    }
	}
      
      // check last interval
      checker.checkInterval(i, currFrame);
      
      ms2.concat(checker.matches());
    }
  while (mIdx < ms.length());
  
  return ms2;
}
