//
// OUTPUTUNGAPPED.CC
// Print ungapped alignment information
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <iomanip>
#include <cstdlib>

#include "outputungapped.h"

#include "printannos.h"
#include "options.h"

using namespace std;


//
// local prototypes
//
static void normalizeAlignments(AlignmentVector, const SeqVector);
static int aCmpBothIndices(const void *p0, const void *p1);


//
// printUngappedAlignments()
// Print the list of ungapped alignments stored in ms[].  The
// output format depends on the global options PrintFlags.
//
// If the output format is "brief", each line of output has the form
//   <seq1> <str1> <start1> <seq2> <str2> <start2> <length> <score>
// where
//  <seq1> and <seq2> are the sequence numbers used in the alignment
//  <str1> and <str2> are the strands on which the alignment occurs
//  <start1> and <start2> are the starting indices of the alignment
//  <length> is the length of the alignment
//  <score> is the score of the alignment
//
// If the output format is anything else, printing is handed off to
// printAnnotatedAlignments(), which knows how to print BLAST-style
// alignments.
//
void printUngappedAlignments(AlignmentVector as, const SeqVector sequences)
{
  if (!(PrintFlags & PRINT_BRIEF)) // print full alignments w/annotations
    {
      normalizeAlignments(as, sequences);
      
      printAnnotatedAlignments(as, sequences);
    }
  else // brief output only
    {
      for (unsigned int j = 0; j < as.length(); j++)
	{
	  const Alignment &a = as[j];
	  
	  for (int k = 0; k < 2; k++)
	    {
	      SeqNumber seqNum = a.seq(k);
	      const SeqInfo &seq = sequences[seqNum];
	      
	      cout << seqNum + 1 << ' ';
	      
	      // Which strand is the alignment on?
	      cout << (seq.complement ? 'r' : 'f') << ' ';
	      
	      // Give indices w/r to native strand, or forward strand
	      // if outputForwardStrand is defined.
	      //
	      if (outputForwardStrand && seq.complement)
		{
		  cout << seq.length - a.end(k);
		}
	      else
		{
		  cout << a.start(k) + 1;
		}
	      
	      cout << ' ';
	    }
	  
	  cout << a.length() << ' '
	       << a.score()  << ' '
	       << setprecision(3)
	       << a.eValue() << '\n';
	}
    }
}


//
// normalizeAlignments()
//
// Convert endpoints of a list of ungapped alignments to forward strand
// and sort them by their starts. Set the dir() fields
// to reflect the alignments' actual strands.
//
static void normalizeAlignments(AlignmentVector as, const SeqVector sequences)
{
  for (unsigned int j = 0; j < as.length(); j++)
    {
      Alignment &a = as[j];
      
      for (int k = 0; k < 2; k++)
	{
	  SeqInfo &seq = sequences[a.seq(k)];
	  
	  if (seq.complement)
	    {
	      SeqLength seqlength = seq.length;
	      SeqPosn    oldStart = a.start(k);
	      
	      a.setDir(k, REVERSE);
	      a.setStart(k, seqlength - a.end(k) - 1);
	      a.setEnd(k, seqlength - oldStart - 1);
	    }
	  else
	    a.setDir(k, FORWARD);
	}
    }
  
  qsort(as.elements(), as.length(), sizeof(Alignment), aCmpBothIndices);
}


//
// Sort alignments in the following order:
//  * primary by sequences involved
//  * within that, by start(0)
//  * within that, by start(1)
//
static int aCmpBothIndices(const void *p0, const void *p1)
{
  const Alignment *a0 = (const Alignment *) p0;
  const Alignment *a1 = (const Alignment *) p1;
  
  if (a0->seq(0) == a1->seq(0))
    {
      if (a0->seq(1) == a1->seq(1))
	{
	  if (a0->start(0) == a1->start(0))
	    {
	      if (a0->start(1) >= a1->start(1))
		return (a0->start(1) > a1->start(1));
	      else
		return -1;
	    }
	  else
	    return (a0->start(0) < a1->start(0) ? -1 : 1);
	}
      else
	return (a0->seq(1) < a1->seq(1) ? -1 : 1);
    }
  else
    return (a0->seq(0) < a1->seq(0) ? -1 : 1);
}
