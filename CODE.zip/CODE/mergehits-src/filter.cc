//
// FILTER.CC
// Ungapped and gapped postfiltering for alignments
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>

#include "alignalgos.h"
#include "filter.h"

using namespace std;


// Use this bandwidth in gapped filtering to avoid a full N^2 computation.
//
const int GAPPED_BANDWIDTH = 101;

//
// local prototypes
//
static int acmpUngapped(const void *p1, const void *p2);
static int afwdcmp(const void *p1, const void *p2);
static int arevcmp(const void *p1, const void *p2);
static int abothcmp(const void *p1, const void *p2);


//
// filterUngapped()
// Perform ungapped extension and filtering of every Match in the input vector,
// using the score function sfun. Keep only those ungapped alignments
// that score above cutoff.
//
// RETURNS: filtered ungapped alignments
//
AlignmentVector filterUngapped(MatchVector ms, const SeqVector sequences,
			       const ScoreFunction *sfun, ScoreT cutoff)
{
  AlignmentVector as;
  
  for (unsigned int mIdx = 0; mIdx < ms.length(); mIdx++)
    {
      const Match &match = ms[mIdx];
      Alignment a;
      
      SeqNumber seqNum1 = match.seq(0);
      SeqNumber seqNum2 = match.seq(1);
      
      const SeqInfo &seq1 = sequences[seqNum1];
      const SeqInfo &seq2 = sequences[seqNum2];
      
      SeqPosn s2 = SeqPosn( MAX(match.frame(), 0) );
      SeqPosn e2 = SeqPosn( MIN(seq1.length - 1 + match.frame(),
				seq2.length - 1) );
      
      ScoreT score = alignUngappedBlast(seq1.data, seq2.data, 
					sfun->subs(), match,
					s2, e2, -1000, a);
      
      if (score >= cutoff)
	{
	  a.setSeq(0, seqNum1);
	  a.setSeq(1, seqNum2);
	  as.add(a);
	}
    }
  
  
  //
  // Make sure the ungapped alignments returned have *unique* endpoints.
  // The sort order guarantees that the highest-scoring version
  // of an alignment with given endpts is the one returned.
  //
  
  if (!as.isEmpty())
    {
      AlignmentVector as2;
      
      qsort(as.elements(), as.length(), sizeof(Alignment), acmpUngapped);
      
      as2.add(as[0]);
      
      for (unsigned int j = 1; j < as.length(); j++)
	{
	  if (as[j].seq(0)   != as[j-1].seq(0)   ||
	      as[j].seq(1)   != as[j-1].seq(1)   ||
	      as[j].start(0) != as[j-1].start(0) ||
	      as[j].start(1) != as[j-1].start(1) ||
	      as[j].length() != as[j-1].length())
	    as2.add(as[j]);
	}
      
      as = as2;
    }
  
  return as;
}


//
// filterGapped()
// Perform gapped extension and filtering of every ungapped alignment
// in the input vector, using the score function sfun. Keep
// only those alignments that score above cutoff.
//
// RETURNS: filtered gapped alignments
//
AlignmentVector filterGapped(AlignmentVector asUg, const SeqVector sequences,
			     const ScoreFunction *sfun, ScoreT cutoff)
{
  AlignmentVector as;
  
  for (unsigned int aIdx = 0; aIdx < asUg.length(); aIdx++)
    {
      SeqNumber seqNum1 = asUg[aIdx].seq(0);
      SeqNumber seqNum2 = asUg[aIdx].seq(1);
      
      const SeqInfo &s1 = sequences[seqNum1];
      const SeqInfo &s2 = sequences[seqNum2];

      SeqPosn aCenter1 = asUg[aIdx].start(0) + asUg[aIdx].length() / 2;
      SeqPosn aCenter2 = asUg[aIdx].start(1) + asUg[aIdx].length() / 2;
      
      SeqDiffT start1, start2, end1, end2;
      SeqDiffT span;
      Alignment a;
      
#ifdef VERBOSE
      if (aIdx % 50 == 49)
	cerr << "** " << aIdx + 1 << '\n';
#endif
      
      // Do banded Smith-Waterman around the center of the ungapped alignment.
      // Progressively increase the length of the search band until doing
      // so does not improve the alignment.  To keep the alignment
      // from "drifting", we force it to pass through the antidiagonal
      // containing the original center.
      //
      ScoreT score = -1, prevScore = -INFTY;
      for (span = asUg[aIdx].length(); score > prevScore; span *= 2)
	{
	  // If the span passes the end of either sequence, we
	  // must trim it.  Both start / endpoints must be trimmed
	  // by the same amount; otherwise, we end up specifying an
	  // entirely different diagonal band to search!
	  
	  start1 = SeqDiffT(aCenter1) - span;
	  start2 = SeqDiffT(aCenter2) - span;
	  if (start1 < 0 || start2 < 0)
	    {
	      SeqDiffT delta = MIN(start1, start2);
	      start1 -= delta; start2 -= delta;
	    }
	  
	  end1 = aCenter1 + span;
	  end2 = aCenter2 + span;
	  if (end1 >= SeqDiffT(s1.length) || end2 >= SeqDiffT(s2.length))
	    {
	      SeqDiffT delta = MAX(end1 - SeqDiffT(s1.length), 
				   end2 - SeqDiffT(s2.length)) + 1;
	      end1 -= delta; end2 -= delta;
	    }
	  
	  prevScore = score;
	  
	  score = alignGappedBandedLPin(s1.data, s2.data, *sfun,
					start1, start2,
					end1, end2,
					GAPPED_BANDWIDTH,
					(start1 + end1)/2,
					a);
	}
      
      // If the resulting alignment is a keeper, compute its path explicitly.
      //
      if (score >= cutoff)
	{
	  span /= 2;
	  
	  start1 = SeqDiffT(aCenter1) - span;
	  start2 = SeqDiffT(aCenter2) - span;
	  if (start1 < 0 || start2 < 0)
	    {
	      SeqDiffT delta = MIN(start1, start2);
	      start1 -= delta; start2 -= delta;
	    }

	  end1 = aCenter1 + span;
	  end2 = aCenter2 + span;
	  if (end1 >= SeqDiffT(s1.length) || end2 >= SeqDiffT(s2.length))
	    {
	      SeqDiffT delta = MAX(end1 - SeqDiffT(s1.length), 
				   end2 - SeqDiffT(s2.length)) + 1;
	      end1 -= delta; end2 -= delta;
	    }
	  
	  alignGappedBandedLPinA(s1.data, s2.data, *sfun,
				 start1, start2,
				 a.end(0), a.end(1),
				 GAPPED_BANDWIDTH,
				 (start1 + end1)/2,
				 a);
	  
	  a.setSeq(0, seqNum1);
	  a.setSeq(1, seqNum2);
	  as.add(a);
	}
    }
  
  
  //
  // Make sure the alignments returned have *unique* endpoints.
  // First, remove any duplicate alignments that *end* at the same
  // point, then remove any that *start* at the same point.
  // The sort orders guarantee that the highest-scoring version
  // of an alignment with given endpts is the one reported.
  //
  
  if (!as.isEmpty())
    {
      qsort(as.elements(), as.length(), sizeof(Alignment), arevcmp);
      
      {
	AlignmentVector as2;
	as2.add(as[0]);
	
	for (unsigned int j = 1; j < as.length(); j++)
	  {
	    if (as[j].seq(0) != as[j-1].seq(0) || 
		as[j].seq(1) != as[j-1].seq(1) || 
		as[j].end(0) != as[j-1].end(0) ||
		as[j].end(1) != as[j-1].end(1))
	      as2.add(as[j]);
	  }
	
	as = as2;
      }
      
      qsort(as.elements(), as.length(), sizeof(Alignment), afwdcmp);
      
      {
	AlignmentVector as2;
	as2.add(as[0]);
	
	for (unsigned int j = 1; j < as.length(); j++)
	  {
	    if (as[j].seq(0)   != as[j-1].seq(0)   || 
		as[j].seq(1)   != as[j-1].seq(1)   || 
		as[j].start(0) != as[j-1].start(0) ||
		as[j].start(1) != as[j-1].start(1))
	      as2.add(as[j]);
	  }
	
	as = as2;
      }
      
      // sort in the right order for output
      qsort(as.elements(), as.length(), sizeof(Alignment), abothcmp);
    }
  
  return as;
}


//////////////////////////////////////////////////////////////////////////


//
// Sort ungapped alignments as follows:
//  * primary by sequences involved
//  * within same set of seqs, by starting indices
//  * within same indices, by length of the alignment
//  * within same length, highest score first
//
static int acmpUngapped(const void *p1, const void *p2)
{
  const Alignment *a1 = (const Alignment *) p1;
  const Alignment *a2 = (const Alignment *) p2;
  
  if (a1->seq(0) == a2->seq(0))
    {
      if (a1->seq(1) == a2->seq(1))
	{
	  if (a1->start(0) == a2->start(0))
	    {
	      if (a1->start(1) == a2->start(1))
		{
		  if (a1->length() == a2->length())
		    {
		      if (a1->score() == a2->score())
			return 0;
		      else
			return 
			  (a1->score() > a2->score() ? -1 : 1);
		    }
		  else
		    return (a1->length() > a2->length() ? -1 : 1);
		}
	      else
		return (a1->start(1) < a2->start(1) ? -1 : 1);
	    }
	  else
	    return (a1->start(0) < a2->start(0) ? -1 : 1);
	}
      else
	return (a1->seq(1) < a2->seq(1) ? -1 : 1);
    }
  else
    return (a1->seq(0) < a2->seq(0) ? -1 : 1);
}


//
// Sort Alignments in the following order:
//  * primary by sequences involved
//  * within that, by *LOWER* endpoint in sequence 1
//  * within that, by *LOWER* endpoint in sequence 2
//  * within that, highest score first
//
static int afwdcmp(const void *p1, const void *p2)
{
  const Alignment *a1 = (const Alignment *) p1;
  const Alignment *a2 = (const Alignment *) p2;
  
  if (a1->seq(0) == a2->seq(0))
    {
      if (a1->seq(1) == a2->seq(1))
	{
	  if (a1->start(0) == a2->start(0))
	    {
	      if (a1->start(1) == a2->start(1))
		{
		  if (a1->score() == a2->score())
		    return 0;
		  else
		    return (a1->score() > a2->score() ? -1 : 1);
		}
	      else
		return (a1->start(1) < a2->start(1) ? -1 : 1);
	    }
	  else
	    return (a1->start(0) < a2->start(0) ? -1 : 1);
	}
      else
	return (a1->seq(1) < a2->seq(1) ? -1 : 1);
    }
  else
    return (a1->seq(0) < a2->seq(0) ? -1 : 1);
}


//
// Sort Alignments in the following order:
//  * primary by sequences involved
//  * within that, by *HIGHER* endpoint in sequence 1
//  * within that, by *HIGHER* endpoint in sequence 2
//  * within that, highest score first
//
static int arevcmp(const void *p1, const void *p2)
{
  const Alignment *a1 = (const Alignment *) p1;
  const Alignment *a2 = (const Alignment *) p2;
  
  if (a1->seq(0) == a2->seq(0))
    {
      if (a1->seq(1) == a2->seq(1))
	{
	  if (a1->end(0) == a2->end(0))
	    {
	      if (a1->end(1) == a2->end(1))
		{
		  if (a1->score() == a2->score())
		    return 0;
		  else
		    return (a1->score() > a2->score() ? -1 : 1);
		}
	      else
		return (a1->end(1) < a2->end(1) ? -1 : 1);
	    }
	  else
	    return (a1->end(0) < a2->end(0) ? -1 : 1);
	}
      else
	return (a1->seq(1) < a2->seq(1) ? -1 : 1);
    }
  else
    return (a1->seq(0) < a2->seq(0) ? -1 : 1);
}


//
// Sort Alignments in the following order:
//  * primary by sequences involved
//  * within that, by *BOTH* endpoints in sequence 1
//  * within that, by *BOTH* endpoints in sequence 2
//  * within that, highest score first
//
static int abothcmp(const void *p1, const void *p2)
{
  const Alignment *a1 = (const Alignment *) p1;
  const Alignment *a2 = (const Alignment *) p2;
  
  if (a1->seq(0) == a2->seq(0))
    {
      if (a1->seq(1) == a2->seq(1))
	{
	  if (a1->start(0) == a2->start(0))
	    {
	      if (a1->end(0) == a2->end(0))
		{
		  if (a1->start(1) == a2->start(1))
		    {
		      if (a1->end(1) == a2->end(1))
			{
			  if (a1->score() == a2->score())
			    return 0;
			  else
			    return (a1->score() > a2->score() ? -1 : 1);
			}
		      else
			return (a1->end(1) < a2->end(1) ? -1 : 1);
		    }
		  else
		    return (a1->start(1) < a2->start(1) ? -1 : 1);
		}
	      else
		return (a1->end(0) < a2->end(0) ? -1 : 1);
	    }
	  else
	    return (a1->start(0) < a2->start(0) ? -1 : 1);
	}
      else
	return (a1->seq(1) < a2->seq(1) ? -1 : 1);
    }
  else
    return (a1->seq(0) < a2->seq(0) ? -1 : 1);
}
