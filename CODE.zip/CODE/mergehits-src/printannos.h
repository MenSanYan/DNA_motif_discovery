//
// PRINTANNOS.H
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// Print a list of alignments to standard output.  For each
// alignment, find all the annotations that overlap it in either
// sequence, and print any aligned pairs of annotations.
//

#ifndef __PRINTANNOS_H
#define __PRINTANNOS_H

#include "alignment.h"
#include "seqinfo.h"

void printAnnotatedAlignments(const AlignmentVector, SeqVector);

#endif
