//
// MAIN.CC
// Main program for merging and extending match files and filtering the
// resulting matches using ungapped and/or gapped alignment
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2002 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <cstdlib>

#include "loadsequences.h"
#include "fileops.h"
#include "karlin.h"
#include "matchio.h"
#include "matchutil.h"
#include "options.h"
#include "seqops.h"
#include "timer.h"
#include "version.h"

#include "extend.h"
#include "filter.h"
#include "outputungapped.h"
#include "outputgapped.h"

using namespace std;


/////////////////////////////////////////////////////////////////////
// RUNTIME-SETTABLE PARAMETERS
/////////////////////////////////////////////////////////////////////

unsigned int PrintFlags = (PRINT_ALIGNED_ANNOTATIONS   |
			   PRINT_ALIGNMENTS            |
			   PRINT_ANNOTATION_ALIGNMENTS);
bool outputForwardStrand = false;

const SeqLength DefaultMatchLength = 69;
const SeqLength DefaultMinScore    = 23;
const SeqNumber DefaultPartition   =  1;
const double    DefaultUngappedSignificanceThreshold = 0.05;
const double    DefaultGappedSignificanceThreshold   = 0.05;
const char     *DefaultDNAOutputScoreFunctionName = "TRIVIAL";
const char     *DefaultProteinOutputScoreFunctionName = "BLOSUM-62";

static SeqLength MatchLength = DefaultMatchLength;
static SeqLength MinScore    = DefaultMinScore;
static SeqNumber Partition   = DefaultPartition;
static double UngappedSignificanceThreshold = DefaultUngappedSignificanceThreshold;
static double GappedSignificanceThreshold = DefaultGappedSignificanceThreshold;

static StringVector matchFileNames;
static bool alignGapped = false;
static const char *InputScoreFunctionName  = NULL;
static const char *OutputScoreFunctionName = NULL;
static const Alphabet *InputAlphabet       = NULL;

static ScoreT GapOpen = 0, GapExt = 0;

//////////////////////////////////////////////////////////////////////

//
// local prototypes
//
static void printUsage(void);
static bool checkSanity(const MatchVector, const SeqVector);
static double filterAndEmit(MatchVector, const SeqVector,
			    const ScoreFunction *);

int main(int argc, char *argv[])
{
  const ScoreFunction *inputScoreFunction, *outputScoreFunction;
  double mergeTime = 0.0, filterTime = 0.0; 
  unsigned int matchesRead = 0;
  bool countingMismatches;
  
  SeqVector sequences = loadSequences(argc, argv, "l:gd:M:o:F:G:p:q:P:x:y:Rh",
				      true);
  
  if (sequences.isEmpty())
    {
      cerr << "* Error: at least one sequence file is required\n";
      printUsage();
      exit(1);
    }
  else if (sequences.length() == 1)
    {
      Partition = 0; // indicates self-comparison
    }
  
  if (matchFileNames.isEmpty())
    {
      cerr << "* Error: at least one match file is required\n";
      printUsage();
      exit(1);
    }
  
  InputAlphabet = sequences[0].alphabet;
  if (outputForwardStrand && !InputAlphabet->isDNA())
    {
      cerr << "* Warning: ignoring -R for non-DNA sequences\n";
      outputForwardStrand = false;
    }
  
  if (!alignGapped && (PrintFlags & PRINT_PIPMAKER))
  {
    cerr << "* Error: PipMaker-style output not supported for "
	 << "ungapped alignments\n";
    exit(1);
  }
      
  // Get the input score function.  If none specified, assume we're
  // counting mismatches.
  //
  {
    countingMismatches = (InputScoreFunctionName == NULL);
    
    if (countingMismatches)
      {
        InputScoreFunctionName = (InputAlphabet->isDNA() 
				  ? "MISMATCHES-D"
				  : "MISMATCHES-P");
      }
    
    const char *inputScoreFileName = 
      computeFullScorePath(InputScoreFunctionName);
    
    inputScoreFunction = new ScoreFunction(InputAlphabet, inputScoreFileName);
    delete [] inputScoreFileName;
    
    if (!inputScoreFunction->isValid())
      exit(1);
  }
  
  // Get the output score function.  If none specified, assume it's
  // the same as the input, or the trivial fcn if no input was specified.
  //
  if (OutputScoreFunctionName == NULL && !countingMismatches)
    {
      OutputScoreFunctionName = InputScoreFunctionName;
      outputScoreFunction = inputScoreFunction;
    }
  else
    {
      if (OutputScoreFunctionName == NULL) // input just counts mismatches
	{
	  if (InputAlphabet->isDNA())
	    OutputScoreFunctionName = DefaultDNAOutputScoreFunctionName;
	  else
	    OutputScoreFunctionName = DefaultProteinOutputScoreFunctionName;
	}
      
      const char *outputScoreFileName = 
	computeFullScorePath(OutputScoreFunctionName);
      
      outputScoreFunction = 
	new ScoreFunction(InputAlphabet, outputScoreFileName);
      delete [] outputScoreFileName;
      
      if (!outputScoreFunction->isValid())
	exit(1);
    }
  
  //
  // Print parameters
  //
  cerr << "*** PARAMS: l = " << MatchLength
       << ", d = "           << MinScore
       << ", P = "           << Partition;
  
  if ((PrintFlags & PRINT_BRIEF) && outputForwardStrand)
    cerr << " [positions w/r to fwd strand]";
  
  cerr << '\n';
  
  if (!countingMismatches)
    cerr << "*** inputscore  = " << inputScoreFunction->name() << '\n';
  
  cerr << "*** outputscore = " << outputScoreFunction->name() << '\n';
  cerr << "*** p(ungapped) = " << UngappedSignificanceThreshold;
  
  if (alignGapped)
    {
      cerr << ", p(gapped) = " << GappedSignificanceThreshold
	   << '\n';
      cerr << "*** gap open = " 
	   << (GapOpen ? GapOpen : outputScoreFunction->gapOpen())
	   << ", gap extend = "
	   << (GapExt ? GapExt : outputScoreFunction->gapExt());
    }
  cerr << '\n' << '\n';
  
  if (countingMismatches)
    {
      // TEMPORARY HACK: if we're just counting mismatches, -d specifies
      // the number of MISMATCHES, not the number of matches.  This is
      // for historical compatibility and should eventually be removed.
      //
      MinScore = MatchLength - MinScore;
    }
  
#ifdef VERBOSE
  cerr << "** Reading match files\n";
#endif
  
  MatchVector ms;
  for (unsigned int j = 0; j < matchFileNames.length(); j++)
    {
      MatchVector matches;
      
      // Read matches from next file
      {
	ifstream matchFile(matchFileNames[j]);
	if (!matchFile)
	  {
	    cerr << "* Error: could not open match file " 
		 << matchFileNames[j] << '\n';
	    exit(1);
	  }
	
	matches = readMatchesFromStream(matchFile);
      }
      
      if (matches.isEmpty())
	{
	  cerr << "* Warning: could not read any matches from file " 
	       << matchFileNames[j] << '\n';
	}
      else
	{
	  matchesRead += matches.length();
	  
	  checkSanity(matches, sequences);
	  
	  ms.concat(matches);
	  matches.truncate();
	  
	  startTimer();
	  
	  // Merge adjacent matches from same seqs in same frame.
	  ms = mergeOverlappingMatches(ms);
	  //ms = removeDuplicateMatches(ms);
	  
	  mergeTime += stopTimer();
	}
    }
  
  if (ms.isEmpty())
    exit(1);
  else
    {
      cerr << "Read " << matchesRead << " total matches\n";
      cerr << "After merging: " << ms.length() << " intervals\n";
    }
  
  if (!countingMismatches || MinScore < MatchLength)
    {      
      startTimer();
      
      ms = extendMatches(ms, sequences, MatchLength, 
			 MinScore, inputScoreFunction);
      cerr << "After expansion: " << ms.length() << " intervals\n";
      
      mergeTime += stopTimer();
    }
  
  filterTime = filterAndEmit(ms, sequences, outputScoreFunction);
  
  cerr << "*** Merge/expansion time: " << mergeTime << '\n';
  cerr << "*** Filtering time:       " << filterTime << '\n';
  return 0;
}


//
// filterAndEmit()
// Perform extension, filtering, and printing of matches using
// the specified output score function.
//
static double filterAndEmit(MatchVector ms, const SeqVector sequences,
			    const ScoreFunction *outputScoreFunction)
{
  double filterTime = 0.0;
  AlignmentVector as;
  ScoreT cutoff;
  
  // obtain aggregate freqs and total lengths from input seqs and partition
  SeqPairDistn aggDistn;
  computeAggregateDistn(sequences, Partition, InputAlphabet, aggDistn);
  
  if (UngappedSignificanceThreshold <= 0.5)
    {
      ScoreDistn sd(aggDistn.freqs1, aggDistn.freqs2, 
		    outputScoreFunction->subs());
      KarlinAltschulStats kaUngapped(sd);
      
      cutoff = 
	ScoreT( ceil(kaUngapped.PtoS(UngappedSignificanceThreshold, 
				     aggDistn.length1, aggDistn.length2)) );
    }
  else // disable filtering, but at least require positive scores
    {
      cutoff = 1;
    }
  
  cerr << "* Ungapped cutoff = " << cutoff << '\n';
  
  startTimer();
  
  as = filterUngapped(ms, sequences, outputScoreFunction, cutoff);
  
  filterTime += stopTimer();
  
  cerr << "After ungapped filtering: " << as.length() << " alignments\n";
  
  if (alignGapped)
    {
      if (GapOpen == 0) GapOpen = outputScoreFunction->gapOpen();
      if (GapExt == 0)  GapExt = outputScoreFunction->gapExt();
      
      const ScoreFunction::GappedKAValues *v = 
	outputScoreFunction->getGappedKAValues(GapOpen, GapExt);
      
      if (v != NULL) // we have Karlin-Altschul parameters!
	{
	  if (GappedSignificanceThreshold <= 0.05)
	    {
	      KarlinAltschulStats kaGapped(v->lambda, v->K);
	      
	      cutoff = 
		ScoreT( ceil(kaGapped.PtoS(GappedSignificanceThreshold,
					   aggDistn.length1, 
					   aggDistn.length2)) );
	    }
	  else // no threshold, but require scores > 0
	    {
	      cutoff = 1;
	    }
	  
	}
      else
	{
	  cerr << "* Warning: no gapped KA stats found -- treating gapped\n"
	       << "           threshold as an explicit score value\n";
	  
	  cutoff = ScoreT( MAX(1.0, GappedSignificanceThreshold) );
	}
      
      cerr << "* Gapped cutoff = " << cutoff << '\n';
      
      startTimer();
      
      as = filterGapped(as, sequences, outputScoreFunction, cutoff);
      
      filterTime += stopTimer();
      
      cerr << "After gapped filtering: " << as.length() << " alignments\n";
      
      if (v != NULL)
	{
	  KarlinAltschulStats kaGapped(v->lambda, v->K);
	  
	  for (unsigned int j = 0; j < as.length(); j++)
	    as[j].setEValue(kaGapped.StoE(as[j].score(), 
					  aggDistn.length1, 
					  aggDistn.length2));
	}
      
      printGappedAlignments(as, sequences);
    }
  else
    {
      ScoreDistn sd(aggDistn.freqs1, aggDistn.freqs2,
		    outputScoreFunction->subs());
      KarlinAltschulStats kaUngapped(sd);
      
      for (unsigned int j = 0; j < as.length(); j++)
	as[j].setEValue(kaUngapped.StoE(as[j].score(), 
					aggDistn.length1, 
					aggDistn.length2));
      
      printUngappedAlignments(as, sequences);
    }
  
  return filterTime;
}


//
// checkSanity()
// Validate a set of input matches against the set of sequences used.  In 
// particular, make sure that all matches in a vector refer to sequences 
// that we know about, and that none run off the ends of their sequences.
//
static bool checkSanity(const MatchVector ms, const SeqVector sequences)
{
  for (unsigned int j = 0; j < ms.length(); j++)
    {
      const Match &m = ms[j];
      SeqNumber seq0 = m.seq(0), seq1 = m.seq(1);
      
      if (seq0 >= sequences.length() ||
	  seq1 >= sequences.length())
	{
	  cerr << "* Error: match #" << j+1 << " refers to sequences "
	       << seq0 + 1 << " and " << seq1 + 1
	       << ", but only " << sequences.length()
	       << " sequences were read.\n";
	  return false;
	}
      else if (m.high(0) >= sequences[seq0].length)
	{
	  cerr << "* Error: in match #" << j+1 << ", endpoint " << m.high(0)+1
	       << " exceeds length of sequence " << seq0 + 1
	       << '\n';
	  return false;
	}
      else if (m.high(1) >= sequences[seq1].length)
	{
	  cerr << "* Error: in match #" << j+1 << ", endpoint " << m.high(1)+1
	       << " exceeds length of sequence " << seq1 + 1
	       << '\n';
	  return false;
	}
    }
  
  return true;
}


//
// handleArgument()
// Pass-through argument handler from loadSequences()
//
void handleArgument(int optchar, const char *optarg)
{
  switch (optchar)
    {
    case 1:   // match file (non-GNU getops may need an explicit flag)
    case 'M': 
      matchFileNames.add(optarg);
      break;
      
    case 'l': // match length
      {
	MatchLength = SeqLength( strtoul(optarg, NULL, 10) );
	if (MatchLength == 0)
	  {
	    cerr << "* Error: match length must be > 0\n";
	    exit(1);
	  }
      }
      break;
      
    case 'F': // use named score function on input
      InputScoreFunctionName = optarg;
      break;
      
    case 'G': // use named score function on output
      OutputScoreFunctionName = optarg;
      break;
      
    case 'g': // do gapped alignment
      alignGapped = true;
      break;
      
    case 'd': // minimum alignment score
      MinScore = SeqLength( strtoul(optarg, NULL, 10) );
      break;
      
    case 'o': // output options
      
      PrintFlags = 0; 
      for (; *optarg != 0; optarg++)
	{
	  switch (*optarg)
	    {
	    case 'b': // override: print just the raw matches
	      PrintFlags = PRINT_BRIEF;
	      break;
	      
	    case 'S': // print sequence annotatiation alignments too
	      PrintFlags |= PRINT_ANNOTATION_ALIGNMENTS;
	      // fall through
	      
	    case 's': // print sequence alignments for matches
	      PrintFlags |= PRINT_ALIGNMENTS;
	      break;
	      
	    case 'A': // print any annotation that overlaps an alignment
	      PrintFlags |= PRINT_UNALIGNED_ANNOTATIONS;
	      // fall through
	      
	    case 'a': // print aligned pairs of annotations
	      PrintFlags |= PRINT_ALIGNED_ANNOTATIONS;
	      break;
	      
	    case 'p': // PipMaker-style output
	      PrintFlags |= PRINT_PIPMAKER;
	      break;
	      
	    default:
	      cerr << "Unrecognized output option '" << *optarg << "'\n";
	      printUsage();
	      exit(1);
	    }
	}
      break;
      
    case 'p': // ungapped significance threshold
      UngappedSignificanceThreshold = strtod(optarg, NULL);
      break;
      
    case 'q': // gapped significance threshold
      GappedSignificanceThreshold = strtod(optarg, NULL);
      break;
      
    case 'P': // partition point
      Partition = SeqNumber( strtoul(optarg, NULL, 10) );
      break;
      
    case 'R': // force brief output to print indices w/r to forward strand
      outputForwardStrand = true;
      break;
    
    case 'x':
      GapOpen = - strtol(optarg, NULL, 10);
      break;
      
    case 'y':
      GapExt = - strtol(optarg, NULL, 10);
      break;
      
    case 'h': // usage or unknown
    default:
      printUsage();
      exit(1);
    }
}


static void printUsage(void)
{
  printVersion();
  
  cerr << "Syntax: mergehits [sequence options] [-l #] [-d #] [-P #] [-R]\n"
       << "                  [-F <name>] [-G <name>] [-p #] [-g] [-x #] [-y #]\n"
       << "                  [-q #] [-o b|[A|a][S|s]|p] -M matchfile "
       << "[-M matchfile...]\n";
  cerr << '\n';
  
  cerr << "   -l #          -- length of inexact match (default " 
       << DefaultMatchLength << ")\n";
  cerr << "   -d #          -- minimum score threshold (default "
       << DefaultMinScore << ")\n";
  cerr << "   -P #          -- last sequence before partition (default "
       << DefaultPartition << ")\n";
  cerr << "   -R            -- force output sequence posns to be w/r to"
       << " forward strand\n"
       << "                    (applies to brief output only)\n";
  cerr << "   -F <name>     -- input was found using named score function\n"
       << "                    (default -- count mismatches)\n";
  cerr << "   -G <name>     -- use named score function in postfilter\n"
       << "                    (default -- same as input; if none, "
       << DefaultDNAOutputScoreFunctionName << " for DNA,\n"
       << "                    "
       << DefaultProteinOutputScoreFunctionName << " for protein)\n";
  cerr << "   -p #          -- ungapped significance threshold\n"
       << "                    (default " 
       << DefaultUngappedSignificanceThreshold
       << ", > 0.5 disables testing)\n";
  cerr << "   -g            -- perform gapped alignments\n";
  cerr << "   -x #, -y #    -- gap opening, gap extension penalties\n";
  cerr << "   -q #          -- gapped significance threshold\n"
       << "                    (default "
       << DefaultGappedSignificanceThreshold << ")\n"
       << "(default " << DefaultGappedSignificanceThreshold << ")\n";
  cerr << "   -o            -- output specification\n"
       << "     b  -- brief tabular output only (overrides others)\n"
       << "     s  -- show seq alignments of matches (default)\n"
       << "    [ungapped alignments only]\n"
       << "     S  -- show seq alignments of annotation matches\n"
       << "     a  -- show matches between annotations\n"
       << "     A  -- show unmatched annotations\n"
       << "    [gapped alignments only]\n" 
       << "     p  -- produce PipMaker-style list of segments output\n";
  cerr << '\n';
  
  printSequenceUsage();
}
