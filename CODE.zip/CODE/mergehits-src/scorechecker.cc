//
// SCORECHECKER.CC
// Check for ungapped high-scoring regions in a given frame within a given
// interval.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include "scorechecker.h"

// If defined, the score checker will merge consecutive
// matches into single, longer intervals.
//
#define ALLOW_MERGING

//
// constructor
//
ScoreChecker::ScoreChecker(const SeqInfo &seqInfo1, const SeqInfo &seqInfo2,
			   SeqLength imatchLength, ScoreT iminScore,
			   const ScoreMatrix &iM)
  : matchLength(imatchLength),
    minScore(iminScore),
    M(iM)
{
  seq1    = seqInfo1.data;   seq2    = seqInfo2.data;
  seqNum1 = seqInfo1.seqNum; seqNum2 = seqInfo2.seqNum;
  length1 = seqInfo1.length; length2 = seqInfo2.length;
}


//
// ScoreChecker::backup()
//
// Given a match starting at index 'end' in sequence 2, move the starting
// index of the match backwards while doing so does not decrease the
// match score, and while the starting index is > start.  Return the
// lowest starting point satisfying both criteria.
//
// ASSUMPTION: we never call this function with start >= end
//
inline SeqPosn
ScoreChecker::backup(SeqPosn end, SeqDiffT frame, SeqPosn start) const
{
  SeqPosn posn = end - 1;
  
  // Advance the string pointer until either string ends or
  // we encounter a nonpositive residue pair
  //
  while (posn != start && 
	 M[ seq1[posn - frame] ][ seq2[posn] ] >=
	 M[ seq1[posn - frame + matchLength] ][ seq2[posn + matchLength] ])
    posn--;
  
  return posn + 1;
}


//
// ScoreChecker::checkInterval()
// Scan an interval (specified w/r to sequence 2) in a particular
// frame (w/r to sequence 1).  Store ALL matches of length
// matchLength with score at least minScore that we find.
// Coalesce consecutive matches into one longer hit.
//
// All matches found can be accessed through the Vector matches().
//
void ScoreChecker::checkInterval(const Interval &iIn, SeqDiffT frame)
{
  SeqPosn start = SeqPosn( MAX(-1L + frame, -1L) ); 
  SeqPosn end   = MIN(length1 + frame, length2);
  Interval i = iIn.intersect(Interval(start + 1, end - 1));
  
  SeqPosn lowIdx2 = backup(i.low(), frame, start);
  
  ScoreT score = 0;
  for (SeqPosn j = lowIdx2; j < lowIdx2 + matchLength - 1; j++)
    score += M[ seq1[j - frame] ][ seq2[j] ];
  
#ifdef ALLOW_MERGING
  SeqPosn   currStart  = 0;
  SeqLength currLength = 0;
#endif

  for (SeqPosn highIdx2 = lowIdx2 + matchLength - 1; 
       highIdx2 <= i.high(); 
       highIdx2++)
    {
      SeqPosn highIdx1 = highIdx2 - frame;
      SeqPosn lowIdx1  = highIdx1 - matchLength + 1;
      SeqPosn lowIdx2  = highIdx2 - matchLength + 1;
      
      score += M[ seq1[highIdx1] ][ seq2[highIdx2] ];

#ifdef ALLOW_MERGING      
      if (score >= minScore)
	{
	  if (currLength == 0)
	    {
	      currLength = matchLength;
	      currStart  = lowIdx2;
	    }
	  else
	    currLength++;
	}
      else if (currLength > 0)
	{
	  addMatch(currStart, currLength, frame, end);
	  currLength = 0;
	}
#else
      if (score >= minScore)
	addMatch(lowIdx2, matchLength, frame, end);
#endif
      
      score -= M[ seq1[lowIdx1] ][ seq2[lowIdx2] ];
    }
  
#ifdef ALLOW_MERGING
  if (currLength > 0)
    addMatch(currStart, currLength, frame, end);
#endif
}


//
// ScoreChecker::addMatch()
// Add the match at [start2 - frame, start2] with given length to
// the end of our match vector.  We don't do any merging here because
// checkInterval() already merges adjacent matches, and we conservatively
// decline to merge overlapping but nonadjacent matches.
//
// NOTE: this function assumes that the match being passed in has at
// least one pair of residues with a positive score!
//
void ScoreChecker::addMatch(SeqPosn start2, SeqLength length, 
			    SeqDiffT frame, SeqPosn end)
{
  SeqPosn start1 = start2 - frame;
  
  // trim off any leading nonpositive residue pairs
  while (M[ seq1[start1] ][ seq2[start2] ] <= 0)
    { start1++; start2++; length--; }
  
  // trim off any trailing nonpositive residue pairs
  while (M[ seq1[start1 + length - 1] ][ seq2[start2 + length - 1] ] <= 0)
    length--;
  
  Match m(seqNum1, start1, seqNum2, start2, length);
  
  _matches.add(m);
}
