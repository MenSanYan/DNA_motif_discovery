//
// FILTER.H
// Ungapped and gapped postfiltering for alignments
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __FILTER_H
#define __FILTER_H

#include "scorefunction.h"
#include "alignment.h"
#include "match.h"
#include "seqinfo.h"

AlignmentVector filterUngapped(MatchVector ms, const SeqVector sequences,
			       const ScoreFunction *sfun, ScoreT cutoff);

AlignmentVector filterGapped(AlignmentVector ms, const SeqVector sequences,
			     const ScoreFunction *sfun, ScoreT cutoff);

#endif
