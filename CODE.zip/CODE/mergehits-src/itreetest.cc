//
// ITREETEST.CC
// Unit test for interval trees
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>
#include <ctime>

#include "intervaltree.h"
#include "random.h"

using namespace std;


// #define TEST_CORRECTNESS

const unsigned int size    = 1000000;
const unsigned int nTrials = 1000000;

int main(int argc, char *argv[])
{
  unsigned int seed;
  time_t t0, t1;
  
  if (argc > 1)
    {
      seed = (unsigned int) strtoul(argv[1], NULL, 10);
      cout << seed << '\n';
      seedPRNG(seed);
    }
  else
    {
      cout << "random seed\n";
      seedPRNG();
    }
  
  KeyedInterval *is = new KeyedInterval [size];
  
  for (unsigned int j = 0; j < size; j++)
    {
      is[j].setLow(randUInt() & 0x7FFFFF);
      is[j].setHigh(is[j].low() + 100 + randVal(1000));
      is[j].setKey(j);
    }
  
#ifdef TEST_CORRECTNESS
  // test correctness of overlap
  cout << overlaps(Interval(10, 20), Interval(0, 9))  << ' '
       << overlaps(Interval(10, 20), Interval(21,30)) << ' '
       << overlaps(Interval(10, 20), Interval(10,20)) << ' '
       << overlaps(Interval(10, 20), Interval(5,10))  << ' '
       << overlaps(Interval(10, 20), Interval(5,15))  << ' '
       << overlaps(Interval(10, 20), Interval(10,15)) << ' '
       << overlaps(Interval(10, 20), Interval(12,18)) << ' '
       << overlaps(Interval(10, 20), Interval(15,20)) << ' '
       << overlaps(Interval(10, 20), Interval(15,25)) << ' '
       << overlaps(Interval(10, 20), Interval(20,25)) << '\n';
#endif
  
  t0 = time(NULL);
  
  IntervalTree tree(is, size);
  
  for (unsigned int trial = 0; trial < nTrials; trial++)
    {
      Interval i;
      
      i.setLow(randUInt() & 0x7FFFFF);
      i.setHigh(i.low() + 100 + randValue(400));
      
      tree.findAllOverlaps(i);
      
      // KeyedIntervalVector isfound = tree.findAllOverlaps(i);
      // cout << isfound.length() << '\n';
      
#ifdef TEST_CORRECTNESS
      // CORRECTNESS TESTS
      
      for (unsigned int j = 0; j < isfound.length(); j++)
	{
	  if (!overlaps(i, isfound[j]))
	    {
	      cerr << "Error: intervals " // << i << " and " << isfound[j]
		   << " do not overlap!\n";
	      exit(1);
	    }
	}

      unsigned int ocount = 0;
      for (unsigned int j = 0; j < size; j++)
	{
	  if (overlaps(i, is[j]))
	    ocount++;
	}
      
      if (ocount != isfound.length())
	{
	  cerr << "Error: search found " << isfound.length()
	       << " overlapping intervals, but there are really "
	       << ocount << '\n';
	  exit(1);
	}
#endif
    }
  
  t1 = time(NULL);
  
  cout << "Running time: " << (t1 - t0) << " seconds\n";
  return 0;
}
