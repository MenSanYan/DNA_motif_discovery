//
// STACK.H
// It's a stack.  As Keanu would say, "Whoa."
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////


#ifndef __STACK_H
#define __STACK_H

template <class T>
class Stack {
public:
  Stack(int size) { data = new T [size]; top = -1;}
  ~Stack(void) { delete [] data; }
  
  void push(T v) { data[++top] = v; }
  T pop(void) { return data[top--]; }
  
  bool isEmpty(void) const { return (top == -1); }
  
  void reset(void) { top = -1; } // delete everything on the stack
  
private:
  T *data;
  int top;
};

#endif
