//
// INTERVALTREE.H
// An ordered tree of closed intervals supporting overlap searches.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __INTERVALTREE_H
#define __INTERVALTREE_H

#include "interval.h"

template <class T> class Stack;

class IntervalTree {
public:
  
  // The default constructor makes an empty tree which must be filled
  // in later via a call to build().  isBuilt() will return false until
  // build() is called.
  IntervalTree(void) 
    : tree(NULL), stack(NULL), built(false) 
  {}
  
  IntervalTree(KeyedInterval *is, unsigned int length)
    : tree(NULL), stack(NULL), built(false)
  { build(is, length); }
  
  IntervalTree(KeyedIntervalVector iv)
    : tree(NULL), stack(NULL), built(false)
  { build(iv.elements(), iv.length()); }
  
  ~IntervalTree(void);
  
  // Return true iff we've built the tree
  bool isBuilt(void) const { return built; }
  
  // Build a tree from an array of intervals
  void build(KeyedInterval *, unsigned int);
  void build(KeyedIntervalVector iv) { build(iv.elements(), iv.length()); }
  
  // Return an interval, if any, which overlaps the query i
  const KeyedInterval *findOverlap(const Interval &i) const;
  
  // Return a vector of all intervals overlapping the query i
  KeyedIntervalVector findAllOverlaps(const Interval &i) const;
  
private:
  struct TreeNode {
    KeyedInterval i;          // interval at node
    TreeNode *left, *right;   // children of node
    SeqPosn min;              // minimum left endpoint in tree
    SeqPosn max;              // maximum right endpoint in tree
    
    TreeNode(const KeyedInterval &i0) : i(i0) {}
  };
  
  TreeNode *tree;                  // root of tree
  Stack<const TreeNode *> *stack;  // stack for find recursion
  
  bool built;                      // has tree been built yet?
  
  //
  // internal functions
  //
  
  void deleteTree(TreeNode *);
  TreeNode *insertInOrder(const KeyedInterval *, unsigned int);
};

#endif
