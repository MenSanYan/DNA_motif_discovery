//
// OPTIONS.H
// Option flags needed by multiple files
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __OPTIONS_H
#define __OPTIONS_H

const unsigned int PRINT_ALIGNED_ANNOTATIONS   = 0x01;
const unsigned int PRINT_UNALIGNED_ANNOTATIONS = 0x02;
const unsigned int PRINT_ALIGNMENTS            = 0x04;
const unsigned int PRINT_ANNOTATION_ALIGNMENTS = 0x08;
const unsigned int PRINT_BRIEF                 = 0x10;
const unsigned int PRINT_PIPMAKER              = 0x20;

extern unsigned int PrintFlags;

extern bool outputForwardStrand; // force brief output to print on fwd strand

#endif
