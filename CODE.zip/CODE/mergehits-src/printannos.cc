//
// PRINTANNOS.CC
// Print alignments between two sequences, along with any annotations
// that they overlap.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <iomanip>
#include <cstdlib>

#include "printannos.h"

#include "printalignment.h"
#include "annotation.h"
#include "seqinfo.h"
#include "minmax.h"

#include "options.h"
#include "intervaltree.h"

using namespace std;


//
// local prototypes
//

static KeyedIntervalVector
computeHits(const Interval &, const SeqInfo &, IntervalTree *);

static void printAlignedAnnotations(KeyedIntervalVector[2],
				    const Alignment &,
				    const SeqInfo &, const SeqInfo &);

static void printUnalignedAnnotations(const KeyedIntervalVector,
				      const Alignment &, int which,
				      const SeqInfo &, const SeqInfo &);

static void printAlignment(const Interval &, const Interval &,
			   const SeqInfo &, const SeqInfo &);

static void printRange(const Interval &, const Annotation &);

static int intervalCmp2(const void *, const void *);


//
// printAnnotatedAlignments()
// Print a list of all alignments to standard output.  For each
// alignment, find all the annotations that overlap it in either
// sequence, and print the correspondences (if any) between 
// the annotated regions.
//
// SIDE EFFECT: munges annotation vectors' lastAlignment fields
//
// NOTE: all indices are assumed to be 0-based internally
// but are printed as 1-based.
//
void printAnnotatedAlignments(const AlignmentVector alignments,
			      SeqVector sequences)
{
  IntervalTree *trees = new IntervalTree [sequences.length()];
  
  for (unsigned int a = 0; a < alignments.length(); a++)
    {
      const Alignment &alignment = alignments[a];
      Interval intervals[2];
      
      // Print alignment header
      cout << "Alignment #" << a + 1 << ':';
      
      for (int j = 0; j < 2; j++)
	{
	  intervals[j] = alignment.toInterval(j);
	  
	  cout << ' ' 
	       << alignment.seq(j)     + 1 << " ["
	       << intervals[j].start() + 1 << ".." 
	       << intervals[j].end()   + 1 << ']';
	}
      cout << '\n';
      
      const SeqInfo &seq0 = sequences[alignment.seq(0)];
      const SeqInfo &seq1 = sequences[alignment.seq(1)];
      
      if (PrintFlags & PRINT_ALIGNMENTS)
	{
	  cout << "     Alignment Score = " << alignment.score()
	       << " (E = " << setprecision(3) << alignment.eValue() << ')';
	  printAlignment(intervals[0], intervals[1], seq0, seq1);
	}
      
      if (PrintFlags & PRINT_ALIGNED_ANNOTATIONS)
	{
	  KeyedIntervalVector hits[2];
	  
	  for (int j = 0; j < 2; j++)
	    hits[j] = 
	      computeHits(intervals[j], sequences[alignment.seq(j)], trees);
	  
	  if (!hits[0].isEmpty())
	    {
	      if (!hits[1].isEmpty())
		printAlignedAnnotations(hits, alignment, seq0, seq1);
	      
	      if (PrintFlags & PRINT_UNALIGNED_ANNOTATIONS)
		printUnalignedAnnotations(hits[0], alignment, 0, seq0, seq1);
	    }
	  
	  if (!hits[1].isEmpty() && (PrintFlags & PRINT_UNALIGNED_ANNOTATIONS))
	    {
	      qsort(hits[1].elements(), hits[1].length(),
		    sizeof(KeyedInterval), intervalCmp2);
	      
	      printUnalignedAnnotations(hits[1], alignment, 1, seq0, seq1);
	    }
	}
    }
  
  delete [] trees;
}


//
// Given an interval i associated with a sequence, find all overlapping
// hits in the interval tree of the sequence's annotations.  Trim
// each hit to just the part contained in the query interval.
//
// RETURNS: vector of hits against the query interval
//
// EFFECTS: If the annotation tree associated with the sequence
//          does not exist, build it.
//
static KeyedIntervalVector
computeHits(const Interval &i, const SeqInfo &sequence, IntervalTree *trees)
{
  SeqNumber seqNum = sequence.seqNum;
  
  if (!trees[seqNum].isBuilt())
    {
      AnnotationVector annotations = sequence.annotations;
      
      // Construct an array of intervals, one for each annotation
      // in the sequence's annotation list.  Each interval's key
      // points back to its annotation.
      //
      KeyedInterval *intervals = new KeyedInterval [annotations.length()];
      for (unsigned int j = 0; j < annotations.length(); j++)
	{
	  intervals[j] = annotations[j].i;
	  intervals[j].setKey(j);
	}
      
      // Build the sequence's interval tree of annotations.
      trees[seqNum].build(intervals, annotations.length());
      
      delete [] intervals;  
    }
  
  KeyedIntervalVector hits = trees[seqNum].findAllOverlaps(i);
  
  // Trim each interval to the portion contained in the hit.
  for (unsigned int j = 0; j < hits.length(); j++)
    hits[j].trim(i);
  
  return hits;
}

////////////////////////////////////////////////////////////////////////////

// move to annotation.h?
inline void printAnnotation(const Annotation &anno)
{
  cout << '\"' << (anno.name ? anno.name : "*") << "\" "
       << (anno.type ? anno.type : "*") << ' '
       << anno.i.dir();
}

//
// printAlignedAnnotations()
// Print all the correspondences between annotated features within
// a single Alignment.
//
// SIDE-EFFECTS:
//  * munges the "lastAlignment" fields of the annotation vectors
//  * permutes the elements of the vectors in hits[]
//
static void printAlignedAnnotations(KeyedIntervalVector hits[2],
				    const Alignment &alignment,
				    const SeqInfo &seq0, const SeqInfo &seq1)
{
  AnnotationVector annotations0 = seq0.annotations;
  AnnotationVector annotations1 = seq1.annotations;
  KeyedIntervalVector hits0 = hits[0];
  IntervalTree hits1Tree(hits[1]);
  
  // Check the hits in increasing order by start, with ties broken by length
  qsort(hits0.elements(), hits0.length(), sizeof(KeyedInterval), intervalCmp2);
  
  for (unsigned int j = 0; j < hits0.length(); j++)
    {
      const KeyedInterval &hit0 = hits0[j];
      Annotation &anno0 = annotations0[hit0.key()];
      
      // Find all features in seq 1 which overlap the feature from seq 0
      
      Interval transHit0 = alignment.transformTo(hit0, 1);
      KeyedIntervalVector matchingHits = hits1Tree.findAllOverlaps(transHit0);
      
      qsort(matchingHits.elements(), matchingHits.length(), 
	    sizeof(KeyedInterval), intervalCmp2);
      
      bool printedHeader = false;
      for (unsigned int k = 0; k < matchingHits.length(); k++)
	{
	  const KeyedInterval &hit1 = matchingHits[k];
	  Annotation &anno1 = annotations1[hit1.key()];
	  
	  Interval hit1Trimmed = hit1.intersect(transHit0);
	  Interval hit0Trimmed = alignment.transformTo(hit1Trimmed, 0);
	  
	  // FIXME: Check that the feature alignment is sufficiently long
	  // and of sufficiently high similarity.  If yes, print;
	  // else continue w/o printing.
	  
	  if (!printedHeader) // print feature header for hit from seq 0
	    {
	      cout << "  * Feature ";
	      printAnnotation(anno0);
	      cout << ' ';
	      printRange(hit0, anno0);
	      cout << '\n';
	      
	      printedHeader = true;
	    }
	  
	  // Print alignment info for hit from seq 1, including the
	  // range of overlap between the features.
	  cout << "   * Overlaps ";
	  printAnnotation(anno1);
	  cout << " over ";
	  printRange(hit0Trimmed, anno0);
	  cout << ", ";
	  printRange(hit1Trimmed, anno1);
	  cout << '\n';
	  
	  if (PrintFlags & PRINT_ANNOTATION_ALIGNMENTS)
	    {
	      if (hit0Trimmed.length() == alignment.length())
		cout << "     (feature match covers entire alignment)\n\n";
	      else
		printAlignment(hit0Trimmed, hit1Trimmed, seq0, seq1);
	    }
	  
	  anno1.lastAlignment= &alignment;
	}
      
      if (printedHeader)  // mark anno0 as used only if we printed it
	{
	  cout << '\n';
	  anno0.lastAlignment = &alignment;
	}
    }
}


//
// printUnalignedAnnotations()
// Print all annotated ranges that overlap one sequence in an alignment
// but do not align with any annotations from the other sequence.
//
static void printUnalignedAnnotations(const KeyedIntervalVector hits,
				      const Alignment &alignment, int which,
				      const SeqInfo &seq0, const SeqInfo &seq1)
{			     
  const AnnotationVector annotations = 
    (which == 0 ? seq0.annotations : seq1.annotations);
  bool printedHeader = false;
  
  for (unsigned int j = 0; j < hits.length(); j++)
    {
      const KeyedInterval &hit = hits[j];
      const Annotation   &anno = annotations[hit.key()];
      
      if (anno.lastAlignment != &alignment) // annotation has not been used
	{
	  if (!printedHeader)
	    {
	      cout << "  * Other features from sequence " 
		   << anno.seqNum + 1 << ":\n";
	      printedHeader = true;
	    }
	  
	  cout << "   * ";
	  printAnnotation(anno);
	  cout << ' ';
	  printRange(hit, anno);
	  cout << '\n';
	  
	  if (PrintFlags & PRINT_ANNOTATION_ALIGNMENTS)
	    {
	      if (hit.length() == alignment.length())
		cout << "     (feature match covers entire alignment)\n\n";
	      else
		{
		  Interval other = alignment.transformTo(hit, 1 - which);
		  
		  if (which == 0)
		    printAlignment(hit, other, seq0, seq1);
		  else
		    printAlignment(other, hit, seq0, seq1);
		}
	    }
	}
    }
  
  if (printedHeader)
    cout << '\n';
}


//
// printRange()
// Print a single interval which falls in the annotated range a.
//
static void printRange(const Interval &i, const Annotation &anno)
{
  Interval iRelative = i.relativeTo(anno.i);
  
  cout << '[' 
       << iRelative.start() + anno.startIdx + 1 
       << ".."
       << iRelative.end()   + anno.startIdx + 1 
       << ']';
}


///////////////////////////////////////////////////////////////////////////

//
// strandLow()
// Given an interval i in the forward orientation (i.e. forward strand),
// and a sequence which may be complemented, return the lowest index of
// the interval on the strand contained in the sequence object.
// 
inline SeqPosn strandLow(const Interval &i, const SeqInfo &seq)
{
  if (seq.complement)
    return seq.length - i.high() - 1;
  else
    return i.low();
}

//
// printAlignment()
// Print an alignment over the region covered by two intervals
// (assumed to have common length).  The strands printed are
// those stored in the sequence objects, regardless of the interval
// direction. [this may need to change]
//
static void printAlignment(const Interval &i0, const Interval &i1,
			   const SeqInfo &seq0, const SeqInfo &seq1)
{
  SeqPosn start0 = strandLow(i0, seq0);
  SeqPosn start1 = strandLow(i1, seq1);
  SeqPosn length = i0.length();
  
  Alignment a;
  a.setSeq(0, seq0.seqNum); a.setSeq(1, seq1.seqNum);
  a.setEndpoints(start0, start0 + length - 1, start1, start1 + length - 1);
  
  cout << '\n';
  printUngappedAlignment(seq0, seq1, a, cout, 50, 5);
  cout << '\n';
}

///////////////////////////////////////////////////////////////////////////


//
// intervalCmp2()
// An Interval comparator for qsort().  Intervals are sorted
// primarily by their starting index.  In case of a tie,
// the longer interval sorts first.
//
static int intervalCmp2(const void *p0, const void *p1)
{
  const Interval *i0 = (const Interval *) p0;
  const Interval *i1 = (const Interval *) p1;
  
  if (i0->low() >= i1->low())
    {
      if (i0->low() == i1->low())
	{
	  if (i0->high() >= i1->high())
	    return (- int(i0->high() > i1->high()));
	  else
	    return 1;
	}
      else
	return 1;
    }
  else
    return -1;
}
