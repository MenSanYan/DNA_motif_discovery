//
// SCORECHECKER.H
// Check for ungapped high-scoring regions in a given frame within a given 
// interval.
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __SCORECHECKER_H
#define __SCORECHECKER_H

#include "seqinfo.h"
#include "scorefunction.h"
#include "interval.h"
#include "match.h"

class ScoreChecker {
public:
  ScoreChecker(const SeqInfo &seqInfo1, const SeqInfo &seqInfo2,
	     SeqLength matchLength, ScoreT minScore,
	     const ScoreMatrix &M);
  
  ~ScoreChecker(void) {}
  
  // i is with respect to seq2
  void checkInterval(const Interval &i, SeqDiffT frame);
  
  MatchVector matches(void) const { return _matches; }
  
private:
  const Residue *seq1, *seq2;     // sequences to scan
  SeqLength length1, length2;     // sequence lengths
  SeqNumber seqNum1, seqNum2;     // seq numbers to put in Match
  SeqLength matchLength;
  ScoreT minScore;
  const ScoreMatrix &M;
  
  MatchVector _matches;
  
  inline SeqPosn backup(SeqPosn end, SeqDiffT frame, SeqPosn start) const;
  void addMatch(SeqPosn start1, SeqLength length, 
		SeqDiffT frame, SeqPosn seqEnd);

};

#endif
