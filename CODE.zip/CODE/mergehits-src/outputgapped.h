//
// OUTPUTGAPPED.H
// Print gapped alignment information
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __OUTPUTGAPPED_H
#define __OUTPUTGAPPED_H

#include "seqinfo.h"
#include "alignment.h"

void printGappedAlignments(AlignmentVector as, const SeqVector sequences);

#endif
