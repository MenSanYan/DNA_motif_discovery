//
// OUTPUTGAPPED.CC
// Print gapped alignment information
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <iomanip>

#include "outputgapped.h"

#include "printalignment.h"
#include "options.h"

using namespace std;


// Define to compute maximum word match length for each ungapped
// segment in PipMaker output mode.
// #define COMPUTE_MML

//
// local prototypes
//
static void printAlignmentSegments(const Alignment &a, 
				   const SeqInfo &seq1, 
				   const SeqInfo &seq2);

static void printSegment(const SeqInfo &seq1, const SeqInfo &seq2,
			 SeqPosn start1, SeqPosn end1, 
			 SeqPosn start2, SeqPosn end2,
			 SeqLength nMatches);


#ifdef COMPUTE_MML
static int findMML(const Residue *, const Residue *,
		   SeqPosn, SeqPosn, SeqLength);
#endif

//
// printGappedAlignments()
// Print gapped alignments in any of brief, full, or PipMaker styles.
//
void printGappedAlignments(AlignmentVector as, const SeqVector sequences)
{
  for (unsigned int j = 0; j < as.length(); j++)
    {
      const Alignment &a = as[j];
      
      if (PrintFlags & PRINT_BRIEF)
	{
	  for (int k = 0; k < 2; k++)
	    {
	      SeqNumber seqNum = a.seq(k);
	      const SeqInfo &seq = sequences[seqNum];
	      
	      cout << seqNum + 1 << ' ';
	      
	      // Which strand is the alignment on?
	      cout << (seq.complement ? 'r' : 'f') << ' ';
	      
	      // Give indices w/r to native strand, or forward strand
	      // if outputForwardStrand is defined.
	      //
	      if (outputForwardStrand && seq.complement)
		{
		  cout << seq.length - a.end(k)   << ' ' 
		       << seq.length - a.start(k);
		}
	      else
		{
		  cout << a.start(k) + 1 << ' '
		       << a.end(k)   + 1;
		}
	      
	      cout << ' ';
	    };
	  
	  cout << a.score();
	  if (a.eValue() >= 0)
	    cout << ' ' << setprecision(3) << a.eValue();
	  cout << '\n';
	}
      else if (PrintFlags & PRINT_PIPMAKER)
	{
	  const SeqInfo &seq0 = sequences[a.seq(0)];
	  const SeqInfo &seq1 = sequences[a.seq(1)];
	  
	  cout << "a {"               << '\n';
	  cout << "  s " << a.score() << '\n';
	  cout << "  x " << a.seq(0) + 1 << ' ' << a.seq(1) + 1 << '\n';
	  
	  cout << "  b " 
	       << (seq0.complement 
		   ? seq0.length - a.start(0)
		   : a.start(0) + 1)
	       << ' ' 
	       << (seq1.complement
		   ? seq1.length - a.start(1)
		   : a.start(1) + 1) 
	       << '\n';
	  
	  cout << "  e " 
	       << (seq0.complement
		   ? seq0.length - a.end(0)
		   : a.end(0) + 1) 
	       << ' ' 
	       << (seq1.complement
		   ? seq1.length - a.end(1)
		   : a.end(1) + 1) 
	       << '\n';
	  
	  printAlignmentSegments(a, seq0, seq1);
	  
	  cout << "}\n";
	}
      else // not brief, not Pipmaker; try to match output in printmatches.cc
	{
	  // Print match header
	  cout << "Alignment #" << j + 1 << ':';
	  
	  for (int k = 0; k < 2; k++)
	    {
	      SeqNumber seqNum = a.seq(k);
	      const SeqInfo &seq = sequences[seqNum];
	      
	      cout << ' ' << seqNum + 1 << " [";
	      if (seq.complement)
		{
		  cout << seq.length - a.end(k)
		       << ".." 
		       << seq.length - a.start(k);
		}
	      else
		{
		  cout << a.start(k) + 1
		       << ".."
		       << a.end(k) + 1;
		}
	      
	      cout << ']';
	    }
	  cout << '\n';
	  
	  if (PrintFlags & PRINT_ALIGNMENTS)
	    {
	      printGappedAlignment(sequences[a.seq(0)], 
				   sequences[a.seq(1)], 
				   a, cout, 50, 5);
	    }
	  
	  cout << '\n';
	}
    }
}


//
// printAlignmentSegments()
// Print the list of ungapped segments in a gapped alignment for
// Pipmaker-style output.  Each ungapped segment is printed as
//   <start1> <start2> <end1> <end2> <%id> <mml>
// where
//  <start{1,2}>/<end{1,2}> are the endpoints of the segment in sequence {1,2}
//  <%id> is the percent identity of the segment
//  <mml> is the maximum exact match length occurring in the segment
//
// INPUTS:
//   alignment with path to print
//   sequences being aligned
//
static void printAlignmentSegments(const Alignment &a, 
				   const SeqInfo &seq1, 
				   const SeqInfo &seq2)
{
  SeqPosn i = a.start(0), j = a.start(1);
  SeqPosn i0 = i, j0 = j;
  const Alignment::Path p = a.path();
  Alignment::Step prevStep = Alignment::GAP1;
  SeqLength nMatches = 0;
  
  for (unsigned int step = 0; step < p.length(); step++)
    {
      if (p[step] == Alignment::MATCH)
	{
	  if (prevStep != Alignment::MATCH) // reached start of a segment
	    {
	      i0 = i; j0 = j; nMatches = 0;
	    }
	  
	  if (Alphabet::isMatch(seq1.data[i], seq2.data[j]))
	    nMatches++;
	  
	  i++; j++;
	}
      else // GAP1 or GAP2
	{
	  if (prevStep == Alignment::MATCH) // reached end of a segment
	    printSegment(seq1, seq2, i0, i - 1, j0, j - 1, nMatches);
	  
	  if (p[step] == Alignment::GAP1)
	    j++;
	  else // GAP2
	    i++;
	}
      
      prevStep = p[step];
    }
  
  // handle last segment, if any
  if (prevStep == Alignment::MATCH)
    printSegment(seq1, seq2, i0, i - 1, j0, j - 1, nMatches);
}


//
// printSegment()
// Print an ungapped segment of an alignment in PipMaker mode
//
static void printSegment(const SeqInfo &seq1, const SeqInfo &seq2,
			 SeqPosn start1, SeqPosn end1, 
			 SeqPosn start2, SeqPosn end2,
			 SeqLength nMatches)
{
  SeqLength len = end1 - start1 + 1;
  
  cout << "  l " 
       << (seq1.complement
	   ? seq1.length - start1
	   : start1 + 1)
       << ' ' 
       << (seq2.complement
	   ? seq2.length - start2
	   : start2 + 1) 
       << ' '
       << (seq1.complement
	   ? seq1.length - end1
	   : end1 + 1)
       << ' ' 
       << (seq2.complement
	   ? seq2.length - end2
	   : end2 + 1)
       << ' '
       << int(100.0 * double(nMatches)/double(len) + 0.5);
  
#ifdef COMPUTE_MML
  int mml = findMML(seq1.data, seq2.data, stat1, start2, len);
  cout << ' ' << mml;
#endif
  
  cout << '\n';
}


#ifdef COMPUTE_MML

//
// findMML()
// Find the longest run of matching residues between two sequences
// in the interval [s1 .. s1 + length - 1], [s2 .. s2 + length - 1]
//
static int findMML(const Residue *seq1, const Residue *seq2,
		   SeqPosn s1, SeqPosn s2, SeqLength length)
{
  int ml = 0, mml = 0;
  
  for (unsigned int j = 0; j < length; j++)
    {
      if (Alphabet::isMatch(seq1[s1 + j], seq2[s2 + j]))
	ml++;
      else
	{
	  if (ml > mml)
	    mml = ml;
	  ml = 0;
	}
    }
  if (ml > mml)
    mml = ml;
  
  return mml;
}

#endif
