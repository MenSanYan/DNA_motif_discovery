//
// INTERVALTREE.CC
// Implementation of simple interval trees
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <cstdlib>

#include "intervaltree.h"
#include "stack.h"
#include "minmax.h"

using namespace std;


template <class T> inline T MAX3(T a, T b, T c) { return MAX(MAX(a, b), c); }

//
// local prototypes
//
static int intervalCmp(const void *, const void *);


//
// build()
// Build a tree from an array of intervals
// SIDE EFFECT: sorts interval array 'is' in order by low endpoint
//
void IntervalTree::build(KeyedInterval *is, unsigned int length)
{
  // Don't leak memory if build() is called multiple times.
  if (tree)  { deleteTree(tree); tree = NULL;  }
  if (stack) { delete stack;     stack = NULL; }
  
  if (length > 0)
    {
      qsort(is, length, sizeof(KeyedInterval), intervalCmp);
      tree = insertInOrder(is, length);
      
      // Allocate a stack tall enough to hold elements up to
      // the height of the tree, plus a bit of slop.
      unsigned int height;
      for (height = 0; length > 0; length >>= 1, height++);
      stack = new Stack<const TreeNode *>(height + 1);
    }
  
  built = true;
}


//
// Destructor
//
IntervalTree::~IntervalTree(void)
{
  if (tree)  deleteTree(tree);
  if (stack) delete stack;
}


//
// insertInOrder()
// Create a balanced interval tree from the sorted array of intervals 'is'.
// Fill in the 'min' and 'max' fields of the tree's root with the lowest
// left endpoint and highest right endpoint, respectively, of any interval
// in the tree.
//
// RETURNS: pointer to root of tree
//
IntervalTree::TreeNode *
IntervalTree::insertInOrder(const KeyedInterval *is, unsigned int length)
{
  unsigned int rootIdx = length/2;
  TreeNode *root = new TreeNode(is[rootIdx]);
  
  switch(length)
    {
    case 1:
      {
	root->left  = NULL;
	root->right = NULL;
	
	root->min = root->i.low();
	root->max = root->i.high();
      }
      break;
      
    case 2:
      {
	root->left  = insertInOrder(is, 1);
	root->right = NULL;
	
	root->min = root->left->min;
	root->max = MAX(root->left->max, root->i.high());
      }
      break;
      
    default: // length > 2
      {
	root->left  = insertInOrder(is, rootIdx);
	root->right = insertInOrder(&is[rootIdx + 1], length - rootIdx - 1);
	
	root->min = root->left->min;
	root->max = MAX3(root->left->max, root->right->max, root->i.high());
      }
      break;
    }
  
  return root;
}


//
// deleteTree()
// Recursively delete the interval tree rooted at root.
//
void IntervalTree::deleteTree(TreeNode *root)
{
  if (root->left)  deleteTree(root->left);
  if (root->right) deleteTree(root->right);
  delete root;
}


//
// findOverlap()
// Find an interval, if any, which overlaps the query interval.
// If an overlapping interval is found, return a pointer to it;
// otherwise, return NULL.
//
const KeyedInterval *IntervalTree::findOverlap(const Interval &i) const
{
  const TreeNode *root = tree;
  
  while (root != NULL)
    {
      if (overlaps(i, root->i))
	return &(root->i);
      else if (root->left && root->left->max >= i.low())
	root = root->left;
      else
	root = root->right;
    }
  
  return NULL; // if here, no overlap found
}


//
// findAllOverlaps()
// Return a vector of all intervals in the tree which overlap the
// query interval.
//
// NOTE: It's to our advantage to use an explicit stack here to
// keep from passing the query interval repeatedly and to avoid
// unnecessary copies while building up the vector of hits.
// The stack is allocated statically in the class so we don't have
// to keep rebuilding it on every query.
//
KeyedIntervalVector IntervalTree::findAllOverlaps(const Interval &i) const
{
  const TreeNode *root = tree;
  KeyedIntervalVector vec;
  
  if (root == NULL)       // if tree empty, stack isn't allocated!
    return vec;
  
  stack->push(NULL);
  while(root != NULL)     // stops when stack is empty
    {
      if (overlaps(i, root->i))
	vec.add(root->i);
      
      bool goLeft = (root->left && root->left->max >= i.low());
      
      if (root->right && root->right->min <= i.high())   // go right?
	{
	  if (goLeft)
	    stack->push(root->left);
	  
	  root = root->right;
	}
      else if (goLeft)
	root = root->left;
      else
	root = stack->pop();
    }
  
  return vec;
}


//
// Interval comparator for qsort(). We sort on left endpoints only.
//
static int intervalCmp(const void *p0, const void *p1)
{
  const Interval *i0 = (const Interval *) p0;
  const Interval *i1 = (const Interval *) p1;
  
  SeqPosn v0 = i0->low(), v1 = i1->low();
  
  if (v0 >= v1)
    return (v0 > v1);
  else 
    return -1;
}
