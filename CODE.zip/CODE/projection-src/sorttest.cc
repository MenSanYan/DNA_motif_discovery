//
// SORTTEST.CC
// Unit test for sorting code
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>
#include <ctime>

#include "memsort.h"
#include "timer.h"

using namespace std;

inline bool lessThan(const Record &r0, const Record &r1)
{
  LSHValue k0 = r0.key(), k1 = r1.key();
  
  if (k0 == k1)
    return (r0.seqNum() < r1.seqNum());
  else
    return (k0 < k1);
}


int main(int argc, char *argv[])
{
  unsigned long nMegs;
  SeqLength size;
  
  if (argc == 1)
    nMegs = 1;
  else
    nMegs = strtoul(argv[1], NULL, 10);
  
  size = SeqLength( nMegs * 1024 * 1024 / sizeof(Record) );
  
  cout << "Memory size: " << nMegs << " megabytes\n";
  cout << "Number of records: " << size << '\n';
  
  Record *records = new Record [size];
  
  seedPRNG();
  
  // initialize with random keys but sequential positions
  for (SeqPosn j = 0; j < size; j++)
    records[j].init(randUInt(), j, (j & 0x01));
  
  cout << "Sorting... " << '\n';
  
  startTimer();
  sortRecords(records, size);
  double runTime = stopTimer();
  
  cout << "Running time: " << runTime << " seconds\n";
  
  // make sure the output is correct!
  for (SeqPosn j = 0; j < size - 1; j++)
    {
      if (lessThan(records[j+1], records[j]))
	{
	  cout << "ERROR: inversion at positions ("
	       << j << ',' << j+1 << ")\n";
	  exit(1);
	}
    }
  
  return 0;
}
