//
// MEMSORT.CC
// A Record sort suitable for main memory
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// This implementation uses a quicksort which in outline follows the
// _quicksort() function in the GNU C Library (v2.1.3).  The major
// implementation decisions are the same:
//
//  1. use an explicit stack rather than recursive calls
//
//  2. use the median-of-three heuristic to select the pivot
//
//  3. leave the array "almost" sorted and use insertion sort to finish
//
// This version is specialized to a fixed record size and a static lessThan()
// function which can be inlined for a big performance win.  It also
// improves over _quicksort() by using a more careful partitioning loop
// invariant.
//

#include "memsort.h"

/////////////////////////////////////////////////////////////////////////
// COMPILE-TIME PARAMETERS
/////////////////////////////////////////////////////////////////////////

// Define if we must sort by sequence number within equal key values.
//
#ifndef ONE_SEQ_ONLY
#define SUBSORT_BY_SEQNUM
#endif

// Partitions less than this size are sorted with insertion sort.
// For correctness of the quicksort code, this value must be
// at least 4, but it may be made larger if doing so would improve
// efficiency.
//
const SeqLength MinQSortSize = 21; // chosen for a Pentium III/550
//const SeqLength MinQSortSize = 6; // chosen for an Alpha 21264/666

////////////////////////////////////////////////////////////////////////

//
// We use an explicit stack to keep track of subranges of array
// elements waiting to be sorted.
//
class RangeStack {
public:
  RangeStack(int size) { data = new Range [size]; top = -1;}
  ~RangeStack(void) { delete [] data; }
  
  void push(SeqPosn low, SeqPosn high)  
  { top++; data[top].low = low; data[top].high = high; }
  
  void pop(SeqPosn *low, SeqPosn *high) 
  { *low = data[top].low; *high = data[top].high; top--; }
  
  bool empty(void) const { return (top == -1); }
  
private:
  struct Range { SeqPosn low, high; };
  Range *data;
  int top;
};


#ifdef SUBSORT_BY_SEQNUM

//
// lessThan() - the Record comparator
// Sort primarily by key, secondarily by sequence number.
//
inline bool lessThan(const Record &r0, const Record &r1)
{
  LSHValue k0 = r0.key(), k1 = r1.key();
  
  if (k0 == k1)
    return (r0.seqNum() < r1.seqNum());
  else
    return (k0 < k1);
}

#else

//
// lessThan() - the Record comparator
// Sort by key only
//
inline bool lessThan(const Record &r0, const Record &r1)
{
  return (r0.key() < r1.key());
}

#endif

//
// swap() -- swap two records
//
inline void swap(Record *r0, Record *r1)
{
  Record tmp = *r0;
  *r0 = *r1;
  *r1 = tmp;
}


//
// insertionSort()
//
// An almost-sorted array (partition size bounded by O(1)) can be 
// sorted in O(n) time because we must check and move at most O(1)
// elements per insertion step.  We assume that the input to the
// insertion sort has been partially sorted down to a partition size
// of at most MinQSortSize.
//
static void insertionSort(Record A[], SeqLength nRecords)
{
  // Unroll the first iteration of the insertion sort to
  // avoid having to test 'j >= 0' in later iterations.
  // Take advantage of the known max partition size.
  //
  SeqLength minBound = (nRecords < MinQSortSize ? nRecords : MinQSortSize);
  SeqPosn minIdx = 0;
  
  for (SeqPosn j = 1; j < minBound; j++)
    {
      if (lessThan(A[j], A[minIdx]))
	minIdx = j;
    }
  if (minIdx > 0)
    swap(&A[0], &A[minIdx]);
  
  
  // ye olde insertion sort
  //
  for (SeqPosn srcIdx = 2; srcIdx < nRecords; srcIdx++)
    {
      SeqPosn targetIdx = srcIdx;
      
      do
	targetIdx--;
      while (lessThan(A[srcIdx], A[targetIdx]));
      targetIdx++;                     // point to first element >= source
      
      if (targetIdx < srcIdx)
	{
	  Record src = A[srcIdx];
	  for (SeqPosn j = srcIdx - 1; j >= targetIdx; j--)
	    A[j+1] = A[j];
	  
	  A[targetIdx] = src;
	}
    } 
}


//
// sortRecords()
// An optimized quicksort for Record objects.
//
void sortRecords(Record *A, SeqLength nRecords)
{
  RangeStack stack(8 * sizeof(SeqPosn)); // enough to sort max # of elements
  SeqPosn low, high;
  
  if (nRecords <= 1) // must handle 0 specially because indices are unsigned
    return;
  else if (nRecords < MinQSortSize) // just use insertion sort
    goto finish_sort;
  
  // push a dummy element so that stack doesn't become empty until
  // the *end* of the last loop iteration.
  stack.push(0, 0);
  
  low = 0; high = nRecords - 1;
  while (!stack.empty())
    {
      Record pivotElt;
      
      //
      // Choose the partition element by a median-of-three computation.
      // Yes, the keys are initially random, but at lower levels
      // of the sort, we're likely to encounter subarrays with the
      // keys already approximately sorted, which would cause
      // pathological behavior if we always took the pivot to be, say, 
      // the zeroth element.
      //
      // Note: we ensure that the low, mid, and high elements are sorted
      // in A once the pivot is chosen; that way, we can avoid
      // redundant comparisons involving the low and high elts.
      //
      
      if (lessThan(A[high], A[low]))
	swap(&A[low], &A[high]);
      
      SeqPosn mid = (low + high)/2;
      if (lessThan(A[mid], A[low]))
	{
	  pivotElt = A[low];
	  swap(&A[low], &A[mid]);
	}
      else if (lessThan(A[high], A[mid]))
	{
	  pivotElt = A[high];
	  swap(&A[mid], &A[high]);
	}
      else
	{
	  pivotElt = A[mid];
	}
      
      
      // Partition around the pivot element.  Yes, we swap
      // elements with equal-valued keys, but it's easier
      // than doing explicit array-bounds tests on the
      // two inner while loops. 
      //
      SeqPosn lowPtr = low + 1, highPtr = high - 1;
      do
	{
	  while (lessThan(A[lowPtr], pivotElt))   lowPtr++;
	  while (lessThan(pivotElt,  A[highPtr])) highPtr--;
	  
	  if (lowPtr >= highPtr)
	    break;
	  
	  swap(&A[lowPtr], &A[highPtr]);
	  lowPtr++; highPtr--;
	}
      while (lowPtr < highPtr);
      
      // If we stopped with lowPtr == highPtr, the disposition of the
      // pointed-to element is uncertain: it could be greater than,
      // less than, or equal to the pivot element.  So, handle
      // this case specially.
      if (lowPtr == highPtr)
	{
	  if (lessThan(A[lowPtr], pivotElt))
	    lowPtr++;
	  else if (lessThan(pivotElt, A[highPtr]))
	    highPtr--;
	}
      
      // Partitions are now [low .. lowPtr - 1], [highPtr + 1 .. high]
      // If lowPtr == highPtr, we simply skip the pivot element because
      // it's already in the right place!
      
      SeqLength leftSize  = lowPtr - low, rightSize = high - highPtr;
      
      // Push the *larger* of the two partitions and recur on the
      // smaller one (keeps the stack-size bounded by lg(nRecords)).
      // Ignore partitions too small for quicksort -- we'll handle all
      // of those at once by insertion sort later.
      //
      if (leftSize < MinQSortSize)
	{
	  if (rightSize < MinQSortSize)  // both partitions too small
	    stack.pop(&low, &high);
	  else                           // only left partition too small
	    low = highPtr + 1;
	}
      else if (rightSize < MinQSortSize) // only right partition too small
	{
	  high = lowPtr - 1;
	}
      else if (leftSize <= rightSize)
	{
	  stack.push(highPtr + 1, high);
	  high = lowPtr - 1;
	}
      else
	{
	  stack.push(low, lowPtr - 1);
	  low = highPtr + 1;
	}
    }
  
 finish_sort:
  insertionSort(A, nRecords);
}
