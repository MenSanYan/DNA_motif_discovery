//
// LSHCOMMON.CC
// Common code for performing projection on a collection of sequences
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// We implement two hacks to filter out sequences with too many masked
// residues (RESIDUE_X's) during the hashing step.  Because large fractions
// of a eukaryotic sequence (40%+) are often masked by RepeatMasker,
// we really don't want to have to discard these enormous runs of X's
// during the quadratic comparison stage.  Instead, we take a
// two-pronged approach:
//
//  1. Don't bother hashing any string with too many RESIDUE_X's to
//     pass the desired score threshold. See init/updateMaskedCount() below,
//     and lsh-src/lsh.cc for computation of the max # of allowed X's.
//
//  2. Hashing a RESIDUE_X should produce a "unique" LSH value that cannot
//     participate in a candidate pair, so the lshFunction() sets
//     a flag when it sees a RESIDUE_X in a hashed position.  We
//     simply discard such values without sorting them.
//

#include <iostream>

#include "lshcommon.h"
#include "lshfunction.h"
#include "memsort.h"

using namespace std;

///////////////////////////////////////////////////////////////////////////

// number of X residues (assumed to be masked) in last sequence seen
static SeqLength maskedCount;

//
// initMaskedCount()
// Initialize maskedCount prior to calling isMasked() on the first 
// 'length'-mer of the sequence s.
//
inline void initMaskedCount(const Residue *s, SeqLength length)
{
  maskedCount = 0;
  
  for (SeqPosn j = 0; j < length - 1; j++)
    if (s[j] == Alphabet::RESIDUE_X)
      maskedCount++;
}


//
// updateMaskedCount()
// Return number of masked (X) positions in the first 'length'
// residues starting at 's'.
//
// ASSUMPTION: we call this function once for each maximally overlapping
// 'length'-mer of a sequence from left to right, after first calling
// initMaskedCount() on the leftmost 'length'-mer.  This allows us to
// use the static maskedCount to find each count in O(1) time.
//
inline SeqLength updateMaskedCount(const Residue *s, SeqLength length)
{
  SeqLength mc;
  
  if (s[length - 1] == Alphabet::RESIDUE_X)
    maskedCount++;
  
  mc = maskedCount;
  
  if (s[0] == Alphabet::RESIDUE_X)
    maskedCount--;
  
  return mc;
}

//////////////////////////////////////////////////////////////////////

//
// computeProjections()
// Apply a projection function "hasher" to a collection of sequences,
// storing all the records produced by the hashing operation in
// the array records[].  Sort the records by their LSH values.
// Filter out records with too many RESIDUE_X's as described above.
//
// For hash functions that care about which side of the comparison each
// sequence is on, sequences 0 .. partition - 1 are assumed to be
// on side 0, while the rest are on side 1.
//
// RETURNS: number of records created
// SETS: records[] to a sorted array of all records from sequences[]
//
// FIXME: we do not yet deal with the case of self-alignments (P == 0).
//
SeqLength computeProjections(const SeqVector sequences, 
			     const LSHFunction *hasher,
			     SeqLength maxXResidues,
			     Record *records,
			     SeqNumber partition)
{
  SeqLength matchLength = hasher->seqLength();
  SeqPosn recordIdx = 0;
  
  for (unsigned int s = 0; s < sequences.length(); s++)
    {
      const Residue *seq  = sequences[s].data;
      SeqNumber seqNum    = sequences[s].seqNum;
      SeqLength seqLength = sequences[s].length;
      
      if (seqLength < matchLength)
	continue;
      
      initMaskedCount(seq, matchLength);
      
      for (SeqPosn j = 0; j <= seqLength - matchLength; j++)
	{
	  int side = (j < partition ? 0 : 1); // always 1 if partition == 0
	  bool isUnique;
	  
	  if (updateMaskedCount(&seq[j], matchLength) > maxXResidues)
	    continue;
	  
	  LSHValue key = hasher->hash(&seq[j], &isUnique, side);
	  
	  if (!isUnique)
	    {
	      records[recordIdx].init(key, j, seqNum);
	      recordIdx++;
	    }
	}
    }
  
#ifdef VERBOSE
  cerr << "** Sorting sequences\n";
#endif
  
  SeqLength nRecords = recordIdx;
  
  sortRecords(records, nRecords);
  
  return nRecords;
}


//
// allocRecords()
// Allocate enough space to perform LSH on the records in the input.
// Return the allocated space. If space cannot be allocated, return 
// NULL.
//
Record *allocRecords(const SeqVector sequences,
		     SeqLength matchLength,
		     SeqLength maxXResidues,
		     SeqLength *onRecords,
		     SeqNumber partition)
{
  Record *records = NULL;
  SeqLength nRecords = 0;
  
  for (unsigned int s = 0; s < sequences.length(); s++)
    {
      if (sequences[s].length >= matchLength)
        {
          const Residue *seq = sequences[s].data;
          SeqLength length = 0;

          initMaskedCount(seq, matchLength);

          // Count non-redundant positions of the input sequence.
          //
          for (SeqPosn j = 0; j <= sequences[s].length - matchLength; j++)
            {
              if (updateMaskedCount(&seq[j], matchLength) <= maxXResidues)
                length++;
            }
          
          nRecords += length;
        }
    }
  
#ifdef VERBOSE
  unsigned long memSize = (nRecords + 1) * sizeof(Record);
  
  cerr << "** allocating ";
  
  if (memSize < (1024*1024))
    cerr << memSize/1024 << "KB";
  else
    cerr << memSize/(1024*1024) << "MB";
  
  cerr << " of working storage\n";
#endif
  
  records = new Record [nRecords + 1];
  
  if (onRecords)
    *onRecords = nRecords;
  
  return records;
}
