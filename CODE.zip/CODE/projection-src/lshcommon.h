//
// LSHCOMMON.H
// Common code for performing projection on a collection of sequences
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#ifndef __LSHCOMMON_H
#define __LSHCOMMON_H

#include "seqinfo.h"
#include "lshfunction.h"
#include "record.h"

Record *allocRecords(const SeqVector sequences,
		     SeqLength matchLength,
		     SeqLength maxXResidues,
		     SeqLength *onRecords = NULL,
		     SeqNumber partition = 1);

SeqLength computeProjections(const SeqVector sequences, 
			     const LSHFunction *hasher,
			     SeqLength maxXResidues,
			     Record *records,
			     SeqNumber partition = 1);

#endif
