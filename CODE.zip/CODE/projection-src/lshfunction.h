//
// LSHFUNCTION.H
// implementation of Indyk's locality-sensitive hash functions
// for the Hamming metric
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// Each new instance of this class is a randomly-chosen member of the
// family LSH(l,k), the functions sampling k of l positions of the input
// at random with replacement. Each function maps a length-d sequence to
// an unsigned long integer value; similar sequences are more likely to
// map to the same value.
//
// Hashing an X residue always creates a "unique" LSH value, since an
// X never matches another character.  We cannot easily reserve a
// return value to communicate such cases, so the hash function
// returns an out-of-band value *isUnique to flag X-containing LSH
// values.
//

#ifndef __LSHFUNCTION_H
#define __LSHFUNCTION_H

#include <cstdlib>

#include "datatypes.h"
#include "alphabet.h"
#include "simulation.h"
#include "random.h"

//
// Base class: common LSH functionality
//  - management of hash factor array
//  - common interface functions
//  - pure virtual interface for hash function
//
class LSHFunction {
public:
  LSHFunction(SeqLength l, SeqLength k)
    : _seqLength(l), _nHashPosns(k)
  {
    LSHValue *__hashFactors = new LSHValue [_nHashPosns];
    
    // Note: might it be better to use random large primes from
    // randomPrime() here, so that all hash factors are relatively 
    // prime?
    for (SeqPosn j = 0; j < _nHashPosns; j++)
      {
	do
	  __hashFactors[j] = (LSHValue) randUInt();
	while (__hashFactors[j] == 0);
      }
    
    _hashFactors = __hashFactors;
  }
  
  virtual ~LSHFunction(void) { delete [] _hashFactors; }
  
  // Property inspectors
  SeqLength seqLength(void)        const { return _seqLength; }
  SeqLength nHashPosns(void)     const { return _nHashPosns; }
  
  virtual LSHValue hash(const Residue *seq, bool *isUnique, 
			int side = 0) const = 0;
  
protected:
  SeqLength _seqLength;              // l, the length of the input seqs
  SeqLength _nHashPosns;             // k, the number of positions to hash
  const LSHValue *_hashFactors;      // list of k random factors for hash fcn
};

/////////////////////////////////////////////////////////////////////////

//
// LSH function for mismatch-counting code
//
class SimpleLSHFunction : public LSHFunction {
public:
  SimpleLSHFunction(SeqLength l, SeqLength k)
    : LSHFunction(l, k)
  {
    SeqPosn *__hashPosns = new SeqPosn [_nHashPosns];
    
    SeqPosn hashIdx = 0;
    
    // Although our hash function conceptually chooses positions with
    // replacement, there's no point in actually reading a given
    // sequence position twice when computing the hash value.
    // Thus, we only generate *unique* positions.  To simulate the
    // effect of selection with replacement, we limit the number
    // of attempts to find a unique position, some of which may fail
    // (or equivalently would provide redundant positions).
    //
    for (SeqPosn attempt = 0;
#ifdef HASH_UNIQUE_POSITIONS
	 hashIdx < _nHashPosns;
#else
	 attempt < _nHashPosns;
#endif
	 attempt++)
      {
	__hashPosns[hashIdx] = // special case: if l == k, use all indices
	  (_seqLength == _nHashPosns ? hashIdx : randVal(_seqLength));
	
	// Is this position unique?
	//
	bool unique = true;
	for (SeqPosn j = 0; j < hashIdx; j++)
	  {
	    if (__hashPosns[j] == __hashPosns[hashIdx])
	      {
		unique = false;
		break;
	      }
	  }
	
	// If the position *is* unique, add it to the hash function
	// and allocate another hash factor.  (Note: might it be
	// better to use random large primes from randomPrime()
	// here, so that all hash factors are relatively prime?).
	if (unique)
	  hashIdx++;
      }
    
    _nHashPosns = hashIdx; // update to reflect # of posns actually used
    
    // For best spatial locality, sort the hash indices in increasing order.
    std::qsort(__hashPosns, _nHashPosns, sizeof(SeqPosn), compareSeqPosn);
    
    _hashPosns = __hashPosns;
  }
  
  virtual ~SimpleLSHFunction(void)
  {
    delete [] _hashPosns;
  }
  
  
  // Property inspectors
  const SeqPosn *hashPosns(void) const { return _hashPosns; }
  
  
  // The hash function: sample the required k positions of the input,
  // then hash them together using the random hash factors to get
  // an integer value.
  //
  // NOTE: we ensure that every residue hashes to a nonzero value
  // so that every hash factor contributes to the randomness of
  // the combined hash value.
  //
  virtual LSHValue hash(const Residue *seq, bool *isUnique, int) const
  {
    LSHValue hash = 0;
    *isUnique = false;
    
    for (SeqPosn j = 0; j < _nHashPosns; j++)
      {
	Residue nextResidue = seq[_hashPosns[j]];
	
	if (nextResidue == Alphabet::RESIDUE_X)
	  *isUnique = true;
	
	LSHValue hashResidue = LSHValue(nextResidue) + 1;
	
	hash += hashResidue * _hashFactors[j];
      }
    
    return hash;
  }
  
private:
  const SeqPosn  *_hashPosns;      // list of indices to hash
  
  // for qsort()
  static int compareSeqPosn(const void *p1, const void *p2)
  {
    SeqPosn i1 = *((const SeqPosn *) p1);
    SeqPosn i2 = *((const SeqPosn *) p2);
    
    if (i1 < i2)
      return -1;
    else
      return (i1 > i2);
  }
  
};

/////////////////////////////////////////////////////////////////////////

//
// LSH function for a general simulation
//
class GeneralLSHFunction : public LSHFunction {
  struct HashPosn {
    SeqPosn seqPosn;
    SeqPosn simPosn;
    const LSHValue *column;
    
    bool operator==(const HashPosn &other) const
    { return (seqPosn == other.seqPosn && simPosn == other.simPosn); }
  };
  
public:
  
  GeneralLSHFunction(SeqLength l, SeqLength k, const Simulation &sim)
    : LSHFunction(l, k)
  {
    HashPosn *__hashPosns = new HashPosn [_nHashPosns];
    nResidues = sim.alphabet()->nResidues();
    
    SeqPosn hashIdx = 0;
    
    for (SeqPosn attempt = 0;
#ifdef HASH_UNIQUE_POSITIONS
	 hashIdx < _nHashPosns;
#else
	 attempt < _nHashPosns;
#endif
	 attempt++)
      {
	HashPosn &hp = __hashPosns[hashIdx];
	hp.seqPosn   = randVal(_seqLength);
	hp.simPosn   = randVal(sim.dimension());
	
	// Is this position unique?
	//
	bool unique = true;
	for (SeqPosn j = 0; j < hashIdx; j++)
	  {
	    if (hp == __hashPosns[j])
	      {
		unique = false;
		break;
	      }
	  }
	
	// If the position *is* unique, add it to the hash function.
	if (unique)
	  hashIdx++;
      }
    
    _nHashPosns = hashIdx; // update to reflect # of posns actually used
    
    // For best spatial locality, sort the hash indices in increasing order.
    std::qsort(__hashPosns, _nHashPosns, sizeof(HashPosn), compareHashPosn);
    
    // Lookup the columns for each simPosn, removing any redundancies.
    //
    unsigned int dst = 0;
    __hashPosns[dst].column = sim[sim.getColumn(__hashPosns[dst].simPosn)];
    for (SeqPosn src = 1; src < _nHashPosns; src++)
      {
	const LSHValue *srcColumn = 
	  sim[sim.getColumn(__hashPosns[src].simPosn)];
	
	if (__hashPosns[dst].seqPosn == __hashPosns[src].seqPosn &&
	    __hashPosns[dst].column  == srcColumn)
	  continue;
	
	++dst;
	__hashPosns[dst].seqPosn = __hashPosns[src].seqPosn;
	__hashPosns[dst].column  = srcColumn;
      }
    _nHashPosns = dst + 1;
    
    _hashPosns = __hashPosns;
  }
  
  virtual ~GeneralLSHFunction(void)
  {
    delete [] _hashPosns;
  }
  
  virtual LSHValue hash(const Residue *seq, bool *isUnique, int side) const
  {
    LSHValue hash = 0;
    *isUnique = false;
    
    for (SeqPosn j = 0; j < _nHashPosns; j++)
      {
	Residue nextResidue = seq[_hashPosns[j].seqPosn];
	
	if (nextResidue == Alphabet::RESIDUE_X)
	  *isUnique = true;
	
	LSHValue hashResidue = 
	  _hashPosns[j].column[nextResidue + (side ? nResidues : 0)] + 1;
	
	hash += hashResidue * _hashFactors[j];
      }
    
    return hash;
  }
  
private:
  const HashPosn  *_hashPosns;    // list of (generalized) positions to hash
  unsigned int nResidues;         // number of residues offset between sides
  
  static int compareHashPosn(const void *p1, const void *p2)
  {
    const HashPosn *hp1 = (const HashPosn *) p1;
    const HashPosn *hp2 = (const HashPosn *) p2;
    
    if (hp1->seqPosn == hp2->seqPosn)
      {
	if (hp1->simPosn == hp2->simPosn)
	  return 0;
	else
	  return (hp1->simPosn < hp2->simPosn ? -1 : 1);
      }
    else
      return (hp1->seqPosn < hp2->seqPosn ? -1 : 1);
  }
};

#endif
