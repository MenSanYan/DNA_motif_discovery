//
// RECORD.H
// A sequence Record describes a single, fixed-length substring of a
// sequence by its position and LSH value.  The paper calls these
// "tuples".
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// If only one sequence is being analyzed, AND we're not copying the
// sequence for a score simulation, then we don't need to store sequence
// numbers.  In this case, #define ONE_SEQ_ONLY saves about 1/3 of the
// total working memory cost (8 bytes rather than 12 bytes per record)
// and also makes the code run a bit faster.
//
// Someday, we'll use one-sequence mode for multi-sequence all-vs-all 
// comparisons by concatenating the input sequences together, but this will
// require allocating sufficient virtually contiguous memory (to avoid 
// computing offsets during checking) at load time.  Meanwhile, the 
// concatenation can always be done externally.
//

#ifndef __RECORD_H
#define __RECORD_H

#include "datatypes.h"

// Note: at 12 bytes/record, 344 MB holds just over 30 million records.
class Record {
private:
  
  LSHValue       _key;
  SeqPosn   _position;

#ifndef ONE_SEQ_ONLY
  SeqNumber _seqNum;
#endif

public:
  
  LSHValue key(void) const { return _key; }
  void setKey(LSHValue ikey) { _key = ikey; }
  
  SeqPosn position(void) const { return _position; }
  void setPosition(SeqPosn iposition) { _position = iposition; }
  
#ifndef ONE_SEQ_ONLY
  SeqNumber seqNum(void) const { return _seqNum; }
  void setSeqNum(SeqNumber iseqNum) { _seqNum = iseqNum; }
#else
  SeqNumber seqNum(void) const { return 0; }
  void setSeqNum(SeqNumber iseqNum) {}
#endif
  
  void init(LSHValue ikey, SeqPosn iposition, SeqNumber iseqNum = 0)
  { setKey(ikey); setPosition(iposition), setSeqNum(iseqNum); }
  
  // Constructors
  
  Record(void) {}
  
  Record(LSHValue ikey, SeqPosn iposition, SeqNumber iseqNum = 0)
  { init(ikey, iposition, iseqNum); }
};

#endif
