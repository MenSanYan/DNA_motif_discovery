//
// SIMULATION.H
// Simulations that map arbitrary score functions into the Hamming metric. 
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <cstring>
#include <cctype>

#include "simulation.h"
#include "vector.h"

using namespace std;

const int MAXLINELEN = 4096;

//
// File constructor
// Note: we can have at most a->nResidues() nonunique values per
// column, since each group specified in the input covers at least
// two residues.  So, unique values are assigned consecutive integers
// starting with a->nResidues().
//
Simulation::Simulation(const Alphabet *a, const char *simFileName)
  : _alphabet(a)
{
  unsigned int columnSize = 2 * _alphabet->nResidues();
  ifstream is(simFileName);
  
  if (!is)
    {
      cerr << "Error: could not open simulation file " << simFileName << '\n';
      _valid = false;
      return;
    }
  
  is >> _offset; is.ignore(MAXLINELEN, '\n');
  if (!is)
    {
      _valid = false;
      return;
    }
  
  Vector<unsigned int> iweights;
  Vector<LSHValue *>   icolumns;
  char *linebuf = new char [MAXLINELEN+1];
  
  bool success = true;
  while (is)
    {
      unsigned int shift = 0;
      LSHValue simR = 0;
      unsigned int weight;
      
      is >> weight;
      if (is.eof())
	break;
      else if (!is)
	{
	  cerr << "Error: could not read weight of column " 
	       << icolumns.length() + 1 << '\n';
	  success = false;
	  goto finish;
	}
      
      is.getline(linebuf, MAXLINELEN+1);
      if (!is)
	{
	  cerr << "Error: could not read entries for column "
	       << icolumns.length() + 1 << '\n';
	  success = false;
	  goto finish;
	}
      
      LSHValue *column = new LSHValue [columnSize];
      for (unsigned int j = 0; j < columnSize; j++)
	column[j] = j + _alphabet->nResidues();
      
      icolumns.add(column);
      iweights.add(weight);
      
      for (const char *parsePtr = linebuf;
	   *parsePtr != 0;
	   parsePtr++)
	{
	  char c = *parsePtr;
	  
	  if (isspace(c))
	    continue;
	  
	  switch (c)
	    {
	    case '(':           // beginning of a comb rectangle
	    case '[':
	    case '{':
	      shift = 0;
	      break;
	      
	    case ')':           // end of a comb rectangle
	    case ']':
	    case '}':
	      simR++;
	      break;
	      
	    case ',':           // switch from 1st to 2nd dimension
	      shift = _alphabet->nResidues();
	      break;
	      
	    case '*':           // match ALL residues on this side
	      for (Residue r = 0; r < _alphabet->nResidues(); r++)
		{
		  if (column[r + shift] < _alphabet->nResidues())
		    {
		      cerr << "Error in simulation: same residue cannot "
			   << "be used twice in the same column!\n";
		      success = false;
		      goto finish;
		    }
		  else
		    column[r + shift] = simR;
		}
	      break;
	      
	    default:            // a residue
	      {
		Residue r = _alphabet->fromChar(c);
		if (r == Alphabet::INVALID_CHAR)
		  {
		    cerr << "Error: unknown residue '" << c 
			 << "' in simulation\n";
		    success = false;
		    goto finish;
		  }
		else
		  {
		    if (column[r + shift] < _alphabet->nResidues())
		      {
			cerr << "Error in simulation: same residue cannot "
			     << "be used twice in the same column!\n";
			success = false;
			goto finish;
		      }
		    else
		      column[r + shift] = simR;
		  }
	      }
	      break;
	    }
	}
    }
  
  //
  // now allocate the permanent data structures
  //
  _nColumns = icolumns.length();
  logLen = computeLogLen(columnSize);
  
  columns = new LSHValue     [_nColumns << logLen];
  weights = new unsigned int [_nColumns];

  for (unsigned int j = 0; j < _nColumns; j++)
    {
      LSHValue *column = icolumns[j];
      
      for (unsigned int r = 0; r < columnSize; r++)
	columns[(j << logLen) + r] = column[r];
      
      delete [] column;
      
      weights[j] = iweights[j];
    }
  
  cdf = new unsigned int [_nColumns];
  cdf[0] = weights[0];
  
  for (unsigned int j = 1; j < _nColumns; j++)
    cdf[j] = cdf[j-1] + weights[j];
  
 finish:
  delete [] linebuf;
  _valid = success;
}


//
// code shared by copy constructor and operator=
//
void Simulation::copy(const Simulation &other)
{
  if (cdf)     delete [] cdf; 
  if (weights) delete [] weights;
  if (columns) delete [] columns;
  
  _alphabet = other._alphabet;
  _valid    = other._valid;
  _nColumns = other._nColumns;
  _offset   = other._offset;
  logLen    = other.logLen;
  
  if (other.columns)
    {
      columns = new LSHValue [_nColumns << logLen];
      memcpy(columns, other.columns, (_nColumns << logLen) * sizeof(LSHValue));
    }
  else
    columns = NULL;
  
  if (other.weights)
    {
      weights = new unsigned int [_nColumns];
      memcpy(weights, other.weights, _nColumns * sizeof(unsigned int));
    }
  else
    weights = NULL;
  
  if (other.cdf)
    {
      cdf = new unsigned int [_nColumns];
      memcpy(cdf, other.cdf, _nColumns * sizeof(unsigned int));
    }
  else
    cdf = NULL;
}


//
// sanityCheck()
// Verify that this simulation reconstructs the score function Strue
// on the non-X residues of its alphabet.
//
bool Simulation::sanityCheck(const ScoreMatrix &Strue) const
{
  const Alphabet *a = Strue.alphabet();
  ScoreMatrix S(a);
  bool isMatch = true;
  
  for (Residue i = 0; i < a->nResidues(); i++)
    for (Residue j = 0; j < a->nResidues(); j++)
      S.setEntry(i, j, offset());
  
  for (unsigned int j = 0; j < nColumns(); j++)
    {
      const LSHValue *column = (*this)[j];
      ScoreT w = weight(j);
      
      for (Residue simR = 0; simR < a->nResidues(); simR++)
	{
	  for (unsigned int i = 0; i < a->nResidues(); i++)
	    {
	      if (column[i] == simR)
		{
		  for (unsigned int j = 0; j < a->nResidues(); j++)
		    {
		      if (column[j + a->nResidues()] == simR)
			S.setEntry(i, j, S[i][j] + w);
		    }
		}
	    }
	}
    }
  
  for (Residue i = 1; i <= a->nRealResidues(); i++)
    for (Residue j = 1; j <= a->nRealResidues(); j++)
      {
	if (S[i][j] != Strue[i][j])
	  {
	    cerr << "Error: simulation does not match score fcn in posn ("
		 << i+1 << ',' << j+1 << ")\n";
	    isMatch = false;
	  }
      }
  
  return isMatch;
}


// print a simulation in the internal form stored by the structure
ostream &operator<<(ostream &os, const Simulation &S)
{
  const Alphabet *a = S.alphabet();
  
  os << S.dimension() << ' ' << S.offset() << '\n';
  
  for (unsigned int j = 0; j < S.nColumns(); j++)
    {
      const LSHValue *column = S[j];
      
      os << S.weight(j) << ':';

      for (unsigned int r = 0; r < 2 * a->nResidues(); r++)
	{
	  os << ' ';
	  if (column[r] >= a->nResidues())
	    os << '*';
	  else
	    os << column[r];
	}
      os << '\n';
    }
      
  return os;
}
