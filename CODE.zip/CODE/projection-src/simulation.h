//
// SIMULATION.H
// Simulations that map arbitrary score functions into the Hamming metric. 
//
//////////////////////////////////////////////////////////////////////////////
// Projection Genomics Toolkit
// Copyright (C) 2000-2001 by Jeremy Buhler, all rights reserved.
// For licensing terms, please see the accompanying LICENSE file.
// For information and bug reports, please contact jbuhler@cse.wustl.edu.
//////////////////////////////////////////////////////////////////////////////
//
// The basic theory of score simulation is covered in chapter 4
// of my PhD thesis.  This class knows how to read simulations
// and how to map dimensions of a simulation to its columns but
// does not actually compute the simulations themselves -- that's
// a hard problem in general.
//
// A Simulation is read from a file of the following form:
// <offset>
// <dimension>
// [<dimension>...]
//
// The first line of the file specifies a numeric offset; all elements
// of the original score matrix have been shifted up by -offset to
// make them non-negative.  The following lines specify the dimensions of
// a weighted Hamming embedding that reproduces the (shifted) score 
// matrix.  Each dimension is given on its own line and has the form
// <weight> <group> [<group>...]
// 
// <weight> is the weight of the dimension.  The dimension's contents are 
// specified by one or more groups of residues, all of which have the same
// value.  Every residue in the ith group gets value i in this dimension,
// while any unspecified residues get a unique value.  Groups are specified
// as (<r1>...<rk>,<r1'>...<rj'>), where <r1>...<rk> are
// residues from alphabet 1 and <r1'>...<rj'> are residues from alphabet 2.
// Using '*' on either side of the comma indicates all residues from that
// alphabet.
//
// Use checkSanity() to determine if a simulation models a particular
// score function on its non-X residue pairs.
//


#ifndef __SIMULATION_H
#define __SIMULATION_H

#include <iostream>

#include "scorefunction.h"
#include "datatypes.h"
#include "alphabet.h"

class Simulation {
public:
  Simulation(const Alphabet *a, const char *simFileName);
  Simulation(const Simulation &other)
    : columns(NULL), weights(NULL), cdf(NULL)
  {
    copy(other);
  }
  
  Simulation &operator=(const Simulation &other)
  {
    if (this != &other) copy(other);
    return *this;
  }
  
  virtual ~Simulation(void)
  {
    if (cdf)     delete [] cdf; 
    if (weights) delete [] weights;
    if (columns) delete [] columns;
  }
  
  const Alphabet *alphabet(void) const { return _alphabet;          }
  unsigned int dimension(void)   const { return cdf[_nColumns - 1]; }
  unsigned int nColumns(void)    const { return _nColumns;          }
  ScoreT offset(void)            const { return _offset;            }
  bool isValid(void)             const { return _valid;             }
  
  const LSHValue *operator[](unsigned int j) const 
  { return &(columns[j << logLen]); }
  
  unsigned int weight(unsigned int j) const { return weights[j]; }  
  
  // return the column of the score function corresponding to the
  // indicated dimension.
  //
  unsigned int getColumn(unsigned int v) const
  {
    unsigned int idx = 0;
    while (v >= cdf[idx])
      idx++;
    
    return idx;
  }
  
  bool sanityCheck(const ScoreMatrix &Strue) const;
  
private:
  
  LSHValue *columns;           // simulation data
  unsigned int logLen;
  
  unsigned int *weights;       // weight of each column
  unsigned int *cdf;           // cumulative partial sums of weights
  
  const Alphabet *_alphabet;   // simulation alphabet
  unsigned int _nColumns;      // # of columns in sim
  ScoreT _offset;              // global offset subtracted from score matrix
  bool _valid;                 // was simulation read successfully?
  
  // compute log of next power of 2 >= vIn.
  unsigned int computeLogLen(unsigned int vIn)
  {
    unsigned int vLog = (unsigned int) -1;
    for (unsigned int v = vIn; v != 0; v >>= 1, vLog++);
    return ((1U << vLog) == vIn ? vLog : vLog + 1);
  }
  
  void copy(const Simulation &other);
};

std::ostream &operator<<(std::ostream &, const Simulation &);

#endif
