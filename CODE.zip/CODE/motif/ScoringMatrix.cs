using System;
using System.Windows.Forms;

namespace SeqAlign
{
	public class ScoringMatrix
	{
		private int mySize;
		private int [,] myScores;
		private char [] myHeadings;
		private int myGap;
		private int myGapOpen;
		private int myGapExtend;

		public ScoringMatrix()
		{
		}
		public ScoringMatrix(int matrixSize)
		{
			mySize = matrixSize;
			myScores = new int [mySize, mySize];
			myHeadings = new char [mySize];
			myGap = myGapOpen = myGapExtend = 0;
		}
		public bool SetScores( int[,] scores)
		{
			int rows = scores.GetLength(0);
			int columns = scores.GetLength(1);
			if ( ( rows != mySize ) || (columns != mySize ) )
			{
				MessageBox.Show("Error: Score matrix size does not match previously declared size."); 
				return false;
			}
			for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < columns; j++)
				{
					myScores[i,j] = scores[i,j];
				}
			}
			return true;
		}
		public bool SetHeadings(char[] headings)
		{
			int columns = headings.GetLength(0);
			if ( columns != mySize )
			{
				MessageBox.Show("Error: Score titles size does not match previously declared size."); 
				return false;
			}
			for (int i = 0; i < columns; i++)
			{
				myHeadings[i] = headings[i];
			}
			return true;
		}
		public string DisplayMatrix()
		{
			string msg = "";
			msg += "Scoring matrix\n";
			for (int i = 0; i < mySize; i++)
				msg += ( "\t" + myHeadings[i] );
			msg += "\n";
			for (int i = 0; i < mySize; i++)
			{
				msg+= myHeadings[i];
				for (int j = 0; j < mySize; j++)
				{
					msg+= ( "\t" + myScores[i,j] ) ;
				}
				msg += "\n";
			}
			msg += ("\n\nGap Penalty = " + myGap);
			return msg;
		}

		public int Score(char c1, char c2)
		{
			int row = -1, col = -1;
			for (int i = 0; i < mySize; i++)
			{
				if (myHeadings[i] == c1)
				{
					row = i;
					break;
				}
			}
			for (int i = 0; i < mySize; i++)
			{
				if (myHeadings[i] == c2)
				{
					col = i;
					break;
				}
			}
			if ( ( row < 0 ) || ( col < 0 ) )
				return Int32.MinValue;
			else
				return myScores[row,col];
		}

		public int GapScore
		{
			get
			{
				return myGap;
			}
			set
			{
				myGap = value;
			}
		}
		
		public int GapOpen
		{
			get
			{
				return myGapOpen;
			}
			set
			{
				myGapOpen = value;
			}
		}
		
		public int GapExtend
		{
			get
			{
				return myGapExtend;
			}
			set
			{
				myGapExtend = value;
			}
		}
	}
}
