using System;

namespace SeqAlign
{
	public class Swarm
	{
		private Database myDB;
		private int qtyParticles;
		//private int maxIterations;
		private double deltaMin, deltaMax;
		private double iWeight, iMin, iMax;
		private double sWeight, sMin, sMax;
		private int dim;
		private int minSeqLength, maxSeqLength;
		private double globalBestScore;
		private Particle globalBestParticle;
		private string[] mySeqs;
		private int myMotifLength;
		private Random rand;
		private Particle[] p;
		private int[] ResidueCount;
		private char [,] CharArray;
		private double [,] myFreqTable;
		private char [] myAlphabet;
		public string outputString;

		public Swarm()
		{
		}

		public Swarm(Database db, int ParticleQty, int motifLength, double SocialFactor, double IndivFactor)
		{
			myDB = db;
			iWeight = IndivFactor;
			sWeight = SocialFactor;
			dim = myDB.SeqCount;
			myMotifLength = motifLength;
			mySeqs = new string[dim];
			qtyParticles = ParticleQty;
			minSeqLength = Int32.MaxValue/2;
			maxSeqLength = 0;
			for ( int i = 0; i < dim; i++)
			{
				mySeqs[i] = myDB.Sequences[i];
				if (mySeqs[i].Length < minSeqLength) minSeqLength = mySeqs[i].Length;
				if (mySeqs[i].Length > maxSeqLength) maxSeqLength = mySeqs[i].Length;
			}
			rand = new Random(); // don't forget to change seed -------------------------------
			myAlphabet = db.Alphabet;
			// initialize particles and global best
			initializeControlVariables();
			initializeParticles();
			initializeGlobalBest(p[0]);
			CharArray = initializeCharArray();
			ResidueCount = countCharacters();
			for (int i = 0; i < qtyParticles; i++)
			{
				double f = fitness(p[i]);
				p[i].updatePersonalBest(f);
				if ( f > this.globalBestScore )
				{
					this.globalBestScore = f;
					this.globalBestParticle = p[i].Copy();
				}
			}
			// run PSO ------------------------------------------

			int improveCycles = 0;
			int stopCycles = 1000;
			 
			while (improveCycles < stopCycles)
			{
				for ( int i = 0 ; i < qtyParticles ; i++ )
				{
					p[i].Fly(this);
					double f = fitness(p[i]);
					p[i].updatePersonalBest(f);
					if ( f > this.globalBestScore )
					{
						this.globalBestScore = f;
						this.globalBestParticle = p[i].Copy();
						improveCycles = 0;		//reset cycle counter
					}
				}
				improveCycles++;
			}
			outputString = formatOutput(this.globalBestParticle);
		}

		private string formatOutput(Particle p)
		{
			// print sequences
			string output = "SEQUENCES:\n";
			for (int r = 0; r < dim; r++)
			{
				for ( int c = 0; c < this.maxSeqLength; c++)
				{
					if (CharArray[r,c] == '\0') CharArray[r,c] = ' ';
					output += Char.ToString(CharArray[r,c]);
				}
				output += "\n";
			}
			output += "\n";
			// print motif starting positions
			output += "Motif = {";
			for ( int r = 0; r < dim; r++)
			{
				output += " " + p.Motif[r].ToString();
			}
			output += " }\n\n";
			// format sequence alignments
			int maxPos = 0;
			for (int d = 0; d < dim ; d++)
			{
				if (p.Motif[d] > maxPos) maxPos = p.Motif[d];
			}
			char[,] outArray = new char[dim, this.maxSeqLength + maxPos];
			for (int r = 0; r < dim; r++)
			{
				int rowOffset = maxPos - p.Motif[r];
				for (int c = 0; c < this.maxSeqLength ; c++)
				{
					outArray[r,c+rowOffset] = Char.ToLower(this.CharArray[r,c]);
				}
				for (int c = maxPos; c < maxPos + this.MotifLength; c++)
				{
					outArray[r,c] = Char.ToUpper(outArray[r,c]);
				}
			}
			// print alignment
			for ( int r = 0; r < dim; r++)
			{
				for ( int c = 0; c < this.maxSeqLength+maxPos; c++)
				{
					if (outArray[r,c] == '\0') outArray[r,c] = ' ';
					output += outArray[r,c].ToString();
				}
				output += "\n";
			}
			// print score
			output += this.globalBestScore.ToString("\n\nBest Score = ######.##\n\n");
			return output;
          
		}

		double fitness (Particle p) //need to complete the fitness function
		{
			myFreqTable = freqTable( p );
			double score = 0.0;
			score = Score(p);			
			return score;
		}

		double Score (Particle p)
		{
			double oddsRatio, logRatio;
			double sumLogRatio = 0;
			for (int d = 0 ; d < dim ; d++)
			{
				double motif = 1.0;
				double backg = 1.0;
				for (int pos = 0 ; pos < myMotifLength ; pos++)
				{
					int location = pos + p.Motif[d];
					for (int c = 0; c < myAlphabet.Length; c++)
					{
						if ( CharArray [d,location] == myAlphabet[c] )
						{
							char dummy = myAlphabet[c];
							motif *= myFreqTable[c,pos+1];
							backg *= myFreqTable[c,0];
							break;
						}
					}
				}
				oddsRatio = motif/backg;
				logRatio = Math.Log(oddsRatio,2.0);
				sumLogRatio += logRatio;
			}
			return sumLogRatio;
		}

		double [,] freqTable (Particle p) //ok
		{
			double [,] f = new double [ResidueCount.Length+1, myMotifLength+1];
			for (int a = 0; a < myAlphabet.Length; a++)
			{
				f[a,0] = ResidueCount[a];
			}
			for (int d = 0; d < dim; d++)
			{
				for (int i = 0; i < myMotifLength; i++)
				{
					int pos = i + p.Motif[d];
			
					for (int a = 0; a < myAlphabet.Length; a++)
					{
						if ( CharArray[d,pos] == myAlphabet[a] )
						{
							f[a, i+1]++;	// increment freq count table
							f[a, 0]--;		// decrement background
							break;
						}
					}
				}
				
			}
			for (int a = 0; a < myAlphabet.Length; a++)
			{
				for (int pos = 0; pos <= myMotifLength; pos++)
				{
					f[a,pos]++;			// add pseudo counts
					f[myAlphabet.Length, pos] += f[a,pos];	// sum columns
				}
			}
			for (int a = 0; a <= myAlphabet.Length; a++)
			{
				for (int pos = 0; pos <= myMotifLength; pos++)
				{
					f[a,pos] = (double)f[a,pos] / (double)f[myAlphabet.Length, pos];	// convert count to frequency
				}
			}
			return f;
		}

		private int[] countCharacters() //ok
		{
			char[] alphabet = new char[myDB.Alphabet.Length];
			myDB.Alphabet.CopyTo(alphabet,0);
			int [] count = new int[alphabet.Length];
			for (int d = 0; d < dim; d++)
			{
				for (int s = 0 ; s < maxSeqLength; s++ )
				{
					for (int a = 0; a < alphabet.Length; a++)
					{
						if ( CharArray[d,s] == alphabet[a] )
						{
							count[a] ++;
							break;
						}
					}
				}
			}
			return count;
		}

		private char[,] initializeCharArray() //ok
		{
			char[,] cArray = new char[dim,maxSeqLength];
			char[] temp;
			for (int d = 0; d < dim; d++)
			{
				temp = mySeqs[d].ToCharArray();
				for (int s = 0; s < temp.Length; s++)
				{
					cArray[d,s] = temp[s];
				}
			}
			return cArray;
		}

		private void initializeControlVariables() //ok
		{
			//maxIterations = 1000;
			iMin = 0.0;
			iMax = 1.0;
			sMin = 0.0;
			sMax = 1.0;
			deltaMax = maxSeqLength/6;
			deltaMin = -deltaMax;
		}

		private void initializeParticles() //ok
		{
			int [] len = new int[dim];
			int [] pos = new int[dim];
			double [] vel = new double[dim];
			p = new Particle[qtyParticles];

			for (int i = 0; i < qtyParticles; i++)
			{
				for (int d = 0; d < dim; d++)
				{
					len[d] = myDB.Sequences[d].Length;
					pos[d] = rand.Next(0,len[d] - myMotifLength);
					vel[d] = rand.NextDouble() * (deltaMax-deltaMin) + deltaMin;
				}
			
				p[i] = new Particle(pos,vel,len);
			}
		}

		private void initializeGlobalBest(Particle p)
		{
			this.globalBestParticle = p.Copy();
			this.globalBestScore = Double.MinValue/2;
		}

		public double IWt
		{
			get
			{
				return this.iWeight;
			}
		}
		public double IMin
		{
			get
			{
				return this.iMin;
			}
		}
		public double IMax
		{
			get
			{
				return this.iMax;
			}
		}
		public double SWt
		{
			get
			{
				return this.sWeight;
			}
		}
		public double SMin
		{
			get
			{
				return this.sMin;
			}
		}
		public double SMax
		{
			get
			{
				return this.sMax;
			}
		}
		public double iWt
		{
			get
			{
				return this.iWeight;
			}
		}
		public double DeltaMin
		{
			get
			{
				return this.deltaMin;
			}
		}
		
		public double DeltaMax
		{
			get
			{
				return this.deltaMax;
			}
		}
		public Particle gBest
		{
			get
			{
				return this.globalBestParticle;
			}
		}
		public int MotifLength
		{
			get
			{
				return this.myMotifLength;
			}
		}
	}
}
