using System;

namespace SeqAlign
{
	/// <summary>
	/// Summary description for Particle.
	/// </summary>
	public class Particle
	{
		private int[] myMotif;
		private double[] myVel;
		private int [] mySeqLength;
		private int[] myBestMotif;
		private double myBestScore;
		private int dim;
		private Random rand;
		public Particle()
		{
		}
		public Particle( int [] Position, double [] Velocity, int [] SequenceLength)
		{
			dim = Position.Length;
			myVel = new double[dim];
			myMotif = new int[dim];
			mySeqLength = new int[dim];
			myBestMotif = new int[dim];
			Velocity.CopyTo( myVel, 0);
			Position.CopyTo( myMotif, 0);
			Position.CopyTo( myBestMotif, 0);
			SequenceLength.CopyTo( mySeqLength, 0);
			myBestScore = double.MinValue/2;
			rand = new Random();	// don't forget to change seed -------------------
		}
		public void updatePersonalBest( double fitness )
		{
			if (fitness >= myBestScore)
			{
				myBestScore = fitness;
				myMotif.CopyTo(myBestMotif, 0);
			}
		}
		public Particle Copy()
		{
			Particle aCopy =new Particle(myMotif, myVel, mySeqLength);
			aCopy.myBestMotif = myBestMotif;
			aCopy.myBestScore = myBestScore;
			aCopy.dim = dim;
			return aCopy;
		}

		public void Fly( Swarm sw )
		{
			double iFactor, sFactor, pDelta, gDelta, delta;
			int nextPos;
			for ( int d = 0; d < dim ; d++ )
			{
				iFactor = sw.iWt * rand.NextDouble() * (sw.IMax-sw.IMin) + sw.IMin;
				sFactor = sw.SWt * rand.NextDouble() * (sw.SMax-sw.SMin) + sw.SMin;
				pDelta = this.myBestMotif[d] - this.myMotif[d];
				gDelta = sw.gBest.Motif[d] - this.myMotif[d];
				delta = (iFactor * pDelta) + (sFactor * gDelta);
				delta = ( (double) myVel[d] ) + delta;
				// constrict movement
				if (delta > sw.DeltaMax) delta = sw.DeltaMax;	
				if (delta < sw.DeltaMax) delta = sw.DeltaMin;
				this.myVel[d] = delta;
				nextPos = this.myMotif[d] + (int)delta;
				// verify that position is feasible
				if (nextPos < 0) nextPos = 0;
				int rightmostPos = this.mySeqLength[d] - sw.MotifLength - 1;
				if (nextPos > rightmostPos) nextPos = rightmostPos; 
				this.myMotif[d] = nextPos;
			}
		}


		public int[] Motif
		{
			get 
			{
				return myMotif;
			}
		}

	

	}
}
