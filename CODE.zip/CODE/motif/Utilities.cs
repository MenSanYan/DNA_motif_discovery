using System;
using System.IO;
using System.Windows.Forms;

namespace SeqAlign
{
	public class Utilities
	{
		public Utilities()
		{
		}
		static public void DNAScore(int match, int mismatch, out int [,] matrix, out char[] headings)
		{
			headings = new char [4] {'A','T','C','G'};
			matrix = new int [4,4] 
				{
					{ match,	mismatch,	mismatch,	mismatch },
					{ mismatch, match,		mismatch,	mismatch },
					{ mismatch, mismatch,	match,		mismatch },
					{ mismatch, mismatch,	mismatch,	match } 
				};
		}

		static public void ImportScore(string scoreType, out int [,] matrix, out char[] headings)
		{
			//StreamReader myStream;
			string inputFile = null;
			OpenFileDialog openFileDialog1 = new OpenFileDialog();
			openFileDialog1.InitialDirectory = "c:\\" ;
			openFileDialog1.Title = "Import Scoring Matrix";
			openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*" ;
			openFileDialog1.FilterIndex = 2 ;
			openFileDialog1.RestoreDirectory = true ;
			headings = null;
			matrix = null;

			//if(openFileDialog1.ShowDialog() == DialogResult.OK)
			//{
				//inputFile = openFileDialog1.FileName;
			if (scoreType == "blosum60")
				inputFile = "blosum60.txt";
			else if (scoreType == "blosum80")
				inputFile = "blosum80.txt";
			else if (scoreType == "pam250")
				inputFile = "pam250.txt";
			else
				MessageBox.Show("ERROR: scoreType is not valid in\n Utilities.ImportScore");
				char [] delimiter = {' ', ','};

				if (inputFile != null)
				{
					try 
					{
						// Create an instance of StreamReader to read from a file.
						// The using statement also closes the StreamReader.
						using (StreamReader sr = new StreamReader(inputFile)) 
						{
							String line;
							int row = 0;
							 
							// Read and display lines from the file until the end of 
							// the file is reached.
							while ((line = sr.ReadLine()) != null) 
							{
								if (line.Substring(0,1) == "#") 
									continue;
								else if(line.Substring(0,1) == " ") // this is the header row
								{
									string temp = "";
									for (int i = 0; i < line.Length; i++)
									{
										if (line.Substring(i,1) != " ")
											temp += line.Substring(i,1);
									}
									headings = temp.ToCharArray();
									matrix = new int[headings.Length, headings.Length];
								}
								else // this is a scoring row
								{
									string temp = line.Substring(1,line.Length-1);	// removes the letter indentifier
									string[] charRow = temp.Split(delimiter);
									int col = 0;
									for (int i = 0; i < charRow.Length; i++)
									{
										if (charRow[i] != "")
										{
											matrix[row,col] = Int32.Parse(charRow[i]);
											col++;
										}										 
									}
									row++;
								}
							}
						}
					}
					catch (Exception e) 
					{
						// Let the user know what went wrong.
						Console.WriteLine("The file could not be read:");
						Console.WriteLine(e.Message);
					}
				}
			//}
		}

		static public void ImportScore(out int [,] matrix, out char[] headings, out string MatrixName)
		{
			//StreamReader myStream;
			string inputFile;
			OpenFileDialog openFileDialog1 = new OpenFileDialog();
			openFileDialog1.InitialDirectory = "c:\\" ;
			openFileDialog1.Title = "Import Scoring Matrix";
			openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*" ;
			openFileDialog1.FilterIndex = 2 ;
			openFileDialog1.RestoreDirectory = true ;
			headings = null;
			matrix = null;
			MatrixName = null;

			if(openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				inputFile = openFileDialog1.FileName;
				MatrixName = inputFile;
				//string strDelim = " ,";
				char [] delimiter = {' ', ','};
				if (inputFile != null)
				{
                    try 
					 {
						 // Create an instance of StreamReader to read from a file.
						 // The using statement also closes the StreamReader.
						 using (StreamReader sr = new StreamReader(inputFile)) 
						 {
							 String line;
							 int row = 0;
							 // Read and display lines from the file until the end of 
							 // the file is reached.
							 while ((line = sr.ReadLine()) != null) 
							 {
								 if (line.Substring(0,1) == "#") 
									 continue;
								 else if(line.Substring(0,1) == " ") // this is the header row
								 {
									 string temp = "";
									 for (int i = 0; i < line.Length; i++)
									 {
										 if (line.Substring(i,1) != " ")
										 temp += line.Substring(i,1);
									 }
									 headings = temp.ToCharArray();
									 matrix = new int[headings.Length, headings.Length];
								 }
								 else // this is a scoring row
								 {
									 string temp = line.Substring(1,line.Length-1);	// removes the letter indentifier
									 string[] charRow = temp.Split(delimiter);
									 int col = 0;
									 for (int i = 0; i < charRow.Length; i++)
									 {
										 if (charRow[i] != "")
										 {
											 matrix[row,col] = Int32.Parse(charRow[i]);
											 col++;
										 }										 
									 }
									 row++;
								 }
							 }
						 }
					 }
					 catch (Exception e) 
					 {
						 // Let the user know what went wrong.
						 Console.WriteLine("The file could not be read:");
						 Console.WriteLine(e.Message);
					 }
				}
			}
		}

		static public string HeaderOutput( string QueryID, string [] SeqId, int [] AlignScore, double [] SigScore, int SeqQty )
		{
			string strOut = "";
			if (SigScore[0] <= 0) // global alignment
			{
				strOut += "GLOBAL ALIGNMENT RESULTS:\n\n";
			}
			else // local alignment
			{
				strOut += "LOCAL ALIGNMENT RESULTS:\n\n";
			}
			if (SigScore[0] <= 0) // global alignment
			{
				strOut += "Query: " + QueryID + " Versus:\n";
				for (int i = 0; i < SeqQty; i++)
				{
					strOut += ( "     Seq" + (i+1).ToString("000") + ": " + SeqId[i] + ":\tScore = " + AlignScore[i].ToString() + "\n");
				}
			}
			else // local alignment
			{
				strOut += "Query: " + QueryID + " Versus:\n";
				for (int i = 0; i < SeqQty; i++)
				{
					strOut += ( "     Seq" + (i+1).ToString("000") + ": " + SeqId[i] + ":\tScore = " + AlignScore[i].ToString() );
					strOut += ( " (Sig level = " + SigScore[i].ToString("###0.00") );
					if (AlignScore[i] >= SigScore[i])
						strOut += ") ***SIG***\n";
					else
						strOut += ") not sigif\n";
				}
			}
			strOut += "\n\n";
			return strOut;
		}

		static public string AlignmentOutput( int dbSeqNumber, string Name1, string Sequence1, int beginLoc1, int length1,
			string Name2, string Sequence2, int beginLoc2, int length2, int AlignScore, double signifScore )
		// converts two alignment strings into a string single string suitable for display
		{
			string Compare = "";
			string strOut = "";
			string seqNbr = dbSeqNumber.ToString("000");
			strOut += "======================================================================\n\n";
			strOut += String.Format("Seq{0:000}: {1,15}", dbSeqNumber, Name1);
			if (signifScore > 0 ) // local alignment
			{
				strOut += String.Format(" (Beginning Locus: {0})", beginLoc1);
			}
			strOut += String.Format("\nQuery:  {0,15}", Name2);
			if (signifScore > 0 ) // local alignment
			{
				strOut += String.Format(" (Beginning Locus: {0})", beginLoc2);
			}
			strOut += String.Format("\nScore =  {0} \n\n",AlignScore);
			for (int i = 0; i < Sequence1.Length; i++)
			{
				if ( Sequence1.Substring(i,1) == Sequence2.Substring(i,1) )
					Compare += '|';
				else
					Compare += ' ';
			}
			Name1 = "Seq" + seqNbr + ": ";
			Name2 = " Query: ";
			for (int i = 0; i < Sequence1.Length; i+=50 )
			{
				int j = i;
				int max = i + 60;
				if (Sequence1.Length < max) max = Sequence1.Length;
				strOut = strOut + Name1;
				while ( j < max )
				{
					strOut += Sequence1.Substring(j,1);
					j++;
				}
				strOut += '\n';
				j = i;
				strOut += "      : ";
				while ( j < max )
				{
					strOut += Compare.Substring(j,1);
					j++;
				}
				strOut += '\n';
				j = i;
				strOut += Name2;
				while ( j < max )
				{
					strOut += Sequence2.Substring(j,1);
					j++;
				}
				strOut += "\n\n";
			}
			strOut += "======================================================================\n\n";
			return strOut;			
		}
	}
}
