using System;

namespace SeqAlign
{
	public class Sequence
	{
		private char [] mySequence;
		private int myLength;
		private string myType;
		private bool valid;
		public Sequence()
		{
		}
		public Sequence(string sequence, string type)
		{
			myType = type.ToUpper();
			string s = sequence.ToUpper();
			char[] tempArray = s.ToCharArray();
			string tempStr = "";
			for (int i = 0; i < tempArray.Length; i++)
			{
				if ( (tempArray[i] >= 'A') && ( tempArray[i] <= 'Z' ) )
					tempStr += tempArray[i];
			}
			mySequence = tempStr.ToCharArray();
			myLength = mySequence.Length;
			valid = Validate();
		}

		private bool Validate()
		{
			bool testValid = true;
			string validStr;
			if (myType == "DNA")
				validStr = "ACGTN";
			else if (myType == "RNA")
				validStr = "ACGUN";
			else if (myType == "AMINO")
				validStr = "ACDEFGHILKMNPQRSTVWXY";
			else return false;
			char[] validArray = validStr.ToCharArray();
			for (int i = 0; i < mySequence.Length; i++ )
			{
				for ( int j = 0; j < validArray.Length; j++)
				{
					testValid = false;
					if ( mySequence[i] == validArray[j] )
					{
						testValid = true;
						break;	
					}
				}
				if ( testValid == false )
					return false;		
			}
			return true;
		}

		public char Residue (int i)
		{
			return mySequence[i];
		}

		public int Length
		{
			get
			{
				return myLength;
			}
		}

		public bool IsValid
		{
			get
			{
				return valid;
			}
		}

	}
}
