using System;
using System.Text.RegularExpressions;

namespace SeqAlign
{
	public class ParseDatabase
	{

		public ParseDatabase()
		{
		}

		public ParseDatabase( string database, out int seqQty, out string [] seqArray, out string []seqID )
		{
			seqQty = 0;
			seqArray = null;
			seqID = null;
			char [] db = database.ToCharArray();
			int count = 0;

			// count number of sequences in database by conting number of '>' characters
			for ( int i = 0; i < db.Length; i++)
			{
				if (db[i] == '>')
					count ++;
			}
			
			if (db.Length == 0) return;
			else if ((db.Length > 0) && (count == 0)) // no id tags at all, therefore only 1 sequence in database
			{
				count = 1;	
				seqArray = new string[count];
				seqID = new string[count];
				seqID[0] = "";
				seqArray[0] = "";

			}
			seqArray = new string[count];
			seqID = new string[count];

                




		}

		private string parseSeq()
		{

			return "void";
		}



		private void parseID( string seqString, out string seq, out string ID)
		{
			
			seq = "";
			ID = "";
			char [] seqChar = seqString.ToCharArray();
			if (seqChar.Length == 0)
			{
				seq = "";
				ID = "";
				return;
			}


		}

	}
}
