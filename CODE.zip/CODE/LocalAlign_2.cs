using System;

namespace SeqAlign
{
	public class LocalAlign
	{
		public string Align1, Align2;
		public int AlignScore;
		private int [,] dynMatrix;
		private int [,,] affineMatrix;
		private ScoringMatrix myScore;
		private byte [,] trace_noAffine;
		private byte[,,] trace_withAffine;
		private int myGap;
		private int myGapOpen;
		private int myGapExtend;
		private int rows, cols;
		private Sequence seq1, seq2;
		private int begin1, begin2; // begin locations of alignments
		public LocalAlign()
		{
		}
		public LocalAlign(ScoringMatrix Score, Sequence Seq1, Sequence Seq2)
		{
			myScore = Score;
			cols = Seq1.Length + 1;
			rows = Seq2.Length + 1;
			seq1 = Seq1;
			seq2 = Seq2;
			myGap = Score.GapScore;
			myGapOpen = Score.GapOpen;
			myGapExtend = Score.GapExtend;
			if ( myGap == 0 ) // using affine gaps
			{
				BuildMatrix_withAffine();
				BuildTraceStrings_withAffine();
			}
			else
			{
				BuildMatrix_noAffine();
				BuildTraceStrings_noAffine();
			}
		}

		private void BuildMatrix_withAffine()
		{
			affineMatrix = new int[3,rows,cols];
			byte trace;
			byte	upM = 1, 
				upIy = 2, 
				upIx = 3, 
				diagM = 4, 
				diagIy = 5,
				diagIx = 6,
				leftM = 7,
				leftIy = 8,
				leftIx =9;
			trace_withAffine = new byte[3,rows,cols];
			affineMatrix[0,0,0] = 0;
			affineMatrix[1,0,0] = 0;
			affineMatrix[2,0,0] = 0;
			for (int c = 1; c < cols; c++ )
			{
				affineMatrix[0,0,c] = 0;
				affineMatrix[1,0,c] = 0;
				affineMatrix[2,0,c] = 0;
			}
			for (int r = 1; r < rows; r++)
			{
				affineMatrix[0,r,0] = 0;
				affineMatrix[1,r,0] = 0;
				affineMatrix[2,r,0] = 0;
			}
			int M, Ix, Iy; // M = match, Ix = insert on x axis, Iy = insert on Y axis
			int val, matchScore;
			for ( int i = 1; i < rows; i++)
			{
				for ( int j = 1; j < cols; j++)
				{
					Iy = affineMatrix[0,i,j-1] + myGapExtend;
					trace = leftIy;
					val = affineMatrix[1,i,j-1] + myGapOpen;
					if ( val > Iy )
					{
						Iy = val;
						trace = leftM;
					}
					if (Iy < 0)
					{
						Iy = 0;
					}
					affineMatrix[0,i,j] = Iy;
					trace_withAffine[0,i,j] = trace;

					matchScore = myScore.Score(seq1.Residue(j-1),seq2.Residue(i-1));
					M = affineMatrix[2,i-1,j-1] + matchScore;
					trace = diagIx;
					val = affineMatrix[1,i-1,j-1] + matchScore;
					if ( val > M )
					{
						M = val;
						trace = diagM;
					}
					val = affineMatrix[0,i-1,j-1] + matchScore;
					if ( val > M )
					{
						M = val;
						trace = diagIy;
					}
					if ( M < 0 )
					{
						M = 0;
					}
					affineMatrix[1,i,j] = M;
					trace_withAffine[1,i,j] = trace;

					Ix = affineMatrix[2,i-1,j] + myGapExtend;
					trace = upIx;
					val = affineMatrix[1,i-1,j] + myGapOpen;
					if ( val > Ix )
					{
						Ix = val;
						trace = upM;
					}
					if ( Ix < 0 )
					{
						Ix = 0;
					}
					affineMatrix[2,i,j] = Ix;
					trace_withAffine[2,i,j] = trace;
				}
			}
		}

		private void BuildTraceStrings_withAffine()
		{
			string s1 = "";
			string s2 = "";
			int m;
			int mMax, rMax, cMax;
			int c = cols-1;
			int r = rows-1;
			byte trace;
			byte	upM = 1, 
				upIy = 2, 
				upIx = 3, 
				diagM = 4, 
				diagIy = 5,
				diagIx = 6,
				leftM = 7,
				leftIy = 8,
				leftIx =9;

			// find the largest value in the lower entire matrix
			int max = -1;
			mMax = rMax = cMax = -1;

			for ( m = 0; m < 2; m++)
			{
				for ( int i = 0; i < rows; i++)
				{
					for ( int j = 0; j < cols; j++)
					{
						if ( affineMatrix[m,i,j] > max )
						{
							max = affineMatrix [m,i,j];
							mMax = m;
							rMax = i;
							cMax = j;
						}
					}
				}
			}

			if ( ( max < 0 ) || ( mMax < 0 ) || ( rMax < 0 ) || ( cMax < 0 ) ) //error
				return;

			AlignScore = max;

			m = mMax;
			r = rMax;
			c = cMax;

			int score = max;

			while ( affineMatrix[m, r, c] > 0 )
			{
				begin1 = c;
				begin2 = r;
				trace = trace_withAffine[m, r, c];
				if (trace == diagM) // move diag to M
				{
					s1 += seq1.Residue(--c);
					s2 += seq2.Residue(--r);
					m=1;
				}	
				else if (trace == diagIy) // move diag to Iy
				{
					s1 += seq1.Residue(--c);
					s2 += seq2.Residue(--r);
					m=0;
				}
				else if (trace == diagIx) // move diag to Ix
				{
					s1 += seq1.Residue(--c);
					s2 += seq2.Residue(--r);
					m=2;
				}
				else if ( trace == leftIy) // move left to Iy
				{
					s1 += seq1.Residue(--c);
					s2 += '-';
					m = 0;
				}
				else if ( trace == leftM) // move left to M
				{
					s1 += seq1.Residue(--c);
					s2 += '-';
					m = 1;
				}
				else if ( trace == leftIx) // move left to Ix
				{
					s1 += seq1.Residue(--c);
					s2 += '-';
					m = 2;
				}
				else if (trace == upIy ) // move up to Iy
				{
					s1 += '-';
					s2 += seq2.Residue(--r);
					m = 0;
				}
				else if (trace == upM ) // move up to M
				{
					s1 += '-';
					s2 += seq2.Residue(--r);
					m = 1;
				}
				else if (trace == upIx ) // move up to Iy
				{
					s1 += '-';
					s2 += seq2.Residue(--r);
					m = 2;
				}
				else 
				{
					if (r == 0) // move left
					{
						s1 += seq1.Residue(--c);
						s2 += '-';
						m = 2;
					}
					else if (c == 0) // move up
					{
						s1 += '-';
						s2 += seq2.Residue(--r);
						m = 0;
					}
					else // error
					{
						s1 += "?";
						s2 += "?";
						return;
					}
				}
			}
			// alignment strings are in reverse order. need to reverse them
			char[] cArr;
			Align1 = "";
			cArr = s1.ToCharArray();
			for (int i = cArr.Length-1; i>=0; i--)
				Align1 += cArr[i];
				
			Align2 = "";
			cArr = s2.ToCharArray();
			for (int i = cArr.Length-1; i>=0; i--)
				Align2 += cArr[i];
		}

		private void BuildMatrix_noAffine()
		{
			dynMatrix = new int [ rows, cols ];
			trace_noAffine = new byte [ rows, cols ];
			int up, left, diag, max;
			int trace;
			for (int i = 0; i < cols; i++ )
			{
				dynMatrix[0,i] = 0;
				trace_noAffine[0,i] = 2;
			}
			for (int i = 0; i < rows; i++ )
			{
				dynMatrix[i,0] = 0;
				trace_noAffine[i,0] = 1;
			}
			trace_noAffine[0,0] = 0;
			for (int i = 1; i < rows; i++)
			{
				for (int j = 1; j < cols; j++)
				{
					left =	dynMatrix[i,j-1] + myGap;
					up =	dynMatrix[i-1,j] + myGap;
					diag =	dynMatrix[i-1,j-1] + myScore.Score(seq1.Residue(j-1),seq2.Residue(i-1));

					max = Int32.MinValue;
					if (left > max)		max = left;
					if (up > max)		max = up;
					if (diag > max)		max = diag;
					if (max < 0)		max = 0;
					dynMatrix[i,j] = max;

					// up =		binary 0001 = 0x01 
					// left =	binary 0010 = 0x02
					// diag =	bianry 0100 = 0x08

					trace = 0x00;	// hex 0
					if ( up == max )	trace = ( trace | 0x01 ); // turn on ones bit
					if ( left == max )	trace = ( trace | 0x02 ); // turn on twos bit
					if ( diag == max )	trace = ( trace | 0x04 ); // turn on fours bit

					trace_noAffine[i,j] = (byte) trace;
				}
			}
		}

		private void BuildTraceStrings_noAffine()
		{
			string s1 = "";
			string s2 = "";
			int c = cols;
			int r = rows;
			byte trace;

			// find max cell value for the starting point
			int maxVal = Int32.MinValue;
			int r_max = 0, c_max = 0;
			for (int i = 0; i < r; i++)
			{
				for (int j = 0; j < c; j++)
				{
					if ( dynMatrix [i,j] > maxVal )
					{
						maxVal = dynMatrix[i,j];
						r_max = i;
						c_max = j;
					}
				}
			}

			r = r_max;
			c = c_max;
			AlignScore = maxVal;

			while ( dynMatrix[r,c] > 0 )
			{
				begin1 = c;
				begin2 = r;
				trace = trace_noAffine[r,c];
				if ( (trace & 0x04) > 0) // move diag
				{
					s1 += seq1.Residue(--c);
					s2 += seq2.Residue(--r);
				}
				
				else if ( (trace & 0x02) > 0) // move left
				{
					s1 += seq1.Residue(--c);
					s2 += '-';
				}

				else // move up
				{
					s1 += '-';
					s2 += seq2.Residue(--r);
				}
			}

			// alignment strings are in reverse order. need to reverse them

			char[] cArr;
			Align1 = "";
			cArr = s1.ToCharArray();
			for (int i = cArr.Length-1; i>=0; i--)
				Align1 += cArr[i];
				
			Align2 = "";
			cArr = s2.ToCharArray();
			for (int i = cArr.Length-1; i>=0; i--)
				Align2 += cArr[i];
		}

		public string DisplayTraceMatrix()
		{
			string msg = "";
			msg += "TRACE-BACK MATRIX\n\t";
			for (int i = 0; i < cols-1; i++)
				msg += ( "\t" + seq1.Residue(i) );
			msg += "\n";
			for (int i = 0; i < cols; i++)
			{
				msg += ("\t" + trace_noAffine[0,i]);
			}
			msg += "\n";
			for (int i = 1; i < rows; i++)
			{
				msg+= seq2.Residue(i-1);
				for (int j = 0; j < cols; j++)
				{
					msg+= ( "\t" + trace_noAffine[i,j] ) ;
				}
				msg += "\n";
			}
			return msg;
		}

		public string DisplayDPMatrix()
		{
			if (myGap == 0) // display affine gap matrix
			{
				string msg = "";
				msg += "DYNAMIC PROGRAMMING MATRIX with affine gaps\n\t";
				for (int i = 0; i < cols-1; i++)
					msg += ( "\t" + seq1.Residue(i) );
				msg += "\n";
				for (int m = 0; m < 3; m++)
				{
					for (int c = 0; c < cols; c++)
					{
						string temp = "-inf";
						if (affineMatrix[m,0,c] > -2000 ) temp = affineMatrix[m,0,c].ToString();
						msg += ( "\t" + temp );
					}
					msg += "\n";
				}
				msg +="\n";
				for (int r = 1; r < rows; r++)
				{
					msg += seq2.Residue(r-1);
					for (int m = 0; m < 3; m++)
					{
						for (int c = 0; c < cols; c++)
						{
							string temp = "-inf";
							if (affineMatrix[m,r,c] > -2000 ) temp = affineMatrix[m,r,c].ToString();
							msg += ( "\t" + temp );
						}
						msg += "\n";
					}
					msg += "\n";
				}
				return msg;
			}
			else
			{
				string msg = "";
				msg += "DYNAMIC PROGRAMMING MATRIX\n\t";
				for (int i = 0; i < cols-1; i++)
					msg += ( "\t" + seq1.Residue(i) );
				msg += "\n";
				for (int i = 0; i < cols; i++)
				{
					msg += ("\t" + dynMatrix[0,i]);
				}
				msg += "\n";
				for (int i = 1; i < rows; i++)
				{
					msg+= seq2.Residue(i-1);
					for (int j = 0; j < cols; j++)
					{
						msg+= ( "\t" + dynMatrix[i,j] ) ;
					}
					msg += "\n";
				}
			return msg;
			}
		}

		public int Locus1
		{
			get
			{
				return begin1;
			}
		}
		
		public int Locus2
		{
			get
			{
				return begin2;
			}
		}

		public double Significance
		{
			get
			{
				return Math.Log( (double)rows * cols , 2 );
			}
		}
	}
}
